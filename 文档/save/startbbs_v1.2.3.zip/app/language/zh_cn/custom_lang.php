<?php

$lang['front_home'] = "首页";


/* End of file custom_lang.php */
/* Location: ./system/language/english/custom_lang.php */