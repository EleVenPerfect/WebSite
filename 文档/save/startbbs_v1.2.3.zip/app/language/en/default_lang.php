<?php

$lang['front_home'] = "Home";


/* End of file front_lang.php */
/* Location: ./system/language/english/front_lang.php */