<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta content='width=device-width, initial-scale=1.0' name='viewport'>
<link href='http://www.startbbs.com' rel='canonical'>
<link href="<?php echo base_url('static/common/css/bootstrap.min.css');?>" media="screen" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url('static/common/css/style.css');?>" media="screen" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo base_url('static/common/js/jquery-1.10.2.min.js');?>"></script>
<script src="<?php echo base_url('static/common/js/global.js');?>" type="text/javascript"></script>
<script type="text/javascript">
var baseurl='<?php echo base_url()?>';
var siteurl='<?php echo site_url()?>';
</script>