<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">联系管理员</h3>
    </div>
    <div class="panel-body">
        管理员邮箱：atime2008@atime.org.cn，<a target="_blank" href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=atime2008@atime.org.cn">点我</a>
    </div>
</div>