<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?
include('geturl.php');
?>

<title><? echo "$yourdomain" ;?> Free Web Hosting Service</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/easySlider1.5.js"></script>
<script type="text/javascript" charset="utf-8">

// <![CDATA[
$(document).ready(function(){	
	$("#slider").easySlider({
		controlsBefore:	'<p id="controls">',
		controlsAfter:	'</p>',
		auto: true, 
		continuous: true
	});	
});
// ]]>
</script>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="block_header">
      <div class="title"><a href="index.php"><h1><? echo "$yourdomain" ;?> Web Hosting Service</h1></a></div>
<?include ('nav.php'); ?>

      <div class="clr"> </div>
    </div>
  </div>
  <div class="slider">
    <div class="slice1">
      <div class="slice2" id="slider">
        <ul>
          <li class="slide">
            <div>
              <p class="img"><img src="images/free-hosting1.png" alt="screen 2" width="483" height="306" /></p>
              <h2>Create your own website for free!</h2>
              <p><font color = white>We provide a domain name and webhosting completely free for life, packed with hundreds of features including website builder and automatic script installer. </p></font>
              <p><a href="free-hosting-signup.php" class="classname">Signup for free hosting</a>
              <br><bR><a href="premium-hosting.php" class="premiumbutton">View premium hosting offers</a></p>
            </div>
          </li>
          <li class="slide">
            <div>
              <p class="img"><img src="images/free-hosting2.png" alt="screen 2" width="453" height="306" /></p>
              <h2>Create your own beautiful website design </h2>
              <p><font color = white>Using FTP or the online file manager, you can design your own beautiful website, our free hosting is fully compatible with all website templates aswell as dynamic websites such as a forum or content management system (CMS). </p></font>
<p><a href="free-hosting-signup.php" class="classname">Signup for free hosting</a>
              <br><bR><a href="premium-hosting.php" class="premiumbutton">View premium hosting offers</a></p>
            </div>
          </li>
          <li class="slide">
            <div>
              <p class="img"><img src="images/free-hosting3.png" alt="screen 2" width="443" height="306" /></p>
              <h2>Ready for search engines</h2>
              <p><font color = white>We fully support all search engines on our servers, this drives visitors to your website making it popular online. </p></font>
<p><a href="free-hosting-signup.php" class="classname">Signup for free hosting</a>
              <br><bR><a href="premium-hosting.php" class="premiumbutton">View premium hosting offers</a></p>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <div class="clr"></div>
  <div class="bloga_resize">
    <div class="bloga_resizee">
      <div class="bloga">
        <h2>Free Hosting</h2>
        <img src="images/img_top_1.png" alt="picture" width="51" height="89" />
        <p>Instant activation free hosting with PHP, MySQL, FTP, File manager, Website Builder, automatic script installer and much more!</p>
        <p><a href="about-free-hosting.php"><strong>Free hosting</strong></a></p>
      </div>
      <div class="bloga">
        <h2>Premium Hosting</h2>
        <img src="images/img_top_2.png" alt="picture" width="51" height="89" />
        <p>Unlimited disk space, no daily hit limits, 256 Softiculious script installer and many more features not included in free hosting</p>
        <p><a href="premium-hosting.php"><strong>Premium hosting</strong></a></p>
      </div>
      <div class="bloga">
        <h2>Domain Registration</h2>
        <img src="images/img_top_3.png" alt="picture" width="51" height="89" />
        <p>Get your own domain name such as a .COM .NET .ORG .BIZ .US .EU .INFO with free WHOIS privacy included.</p>
        <p><a href="registerdomain.php"><strong>Search for a domain</strong></a></p>
      </div>
    </div>
    <div class="clr"></div>
  </div>
  <div class="clr"></div>
  <div class="body">
    <div class="body_resize">
<table style="background: #ebebeb; border: none;"><tr><td valign="top">
        <h2>Welcome to <? echo "$yourdomain" ;?> Free hosting services</h2>
        <p>We are specialists in free hosting services using clustered technology powered by one of the largest hosting organisations on the internet. Sign up here for fast free PHP & MySQL hosting including a free sub domain.
A powerful Vista Panel control panel is provided to manage your website, packed with hundreds of great features including Email, FTP add-on domain and much more,.</p>
        <h2>Why use our hosting service?</h2>
        <p>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightening fast website speeds. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run normally using the working servers!</p>
<img src ="images/datacenter.jpg">
</td><td>&nbsp;</td><td valign="top">
        <div class="twitter">
          <div class="twitter_footer">
            <div class="twitter_top">
              <p>“Follow us on twitter to keep in touch with our hosting team” </p>
              <p><strong>Follow us on Twitter</strong><br />
              <a href="twitter.com/yourusername">twitter.com/yourusername</a></p><br><br>
            </div>
          </div>
        </div><br><br>
        <h2>Free Hosting</h2>
        <p>Welcome to our free hosting service.
We are providing professional, fast PHP & MySQL hosting, powered by ifastnet.com's world-famous clustered hosting technology.
<img  src="images/ssnetlogo.png" width = "150px"><br>
We invite you to sign up for a free hosting account and get your own website on the internet in seconds!
Accounts are activated instantly so you don't need to wait around for an account..<br>
<a href="http://www.free-webhosts.com/"><img src="images/free-webhosts-170x60.gif"></a></p>
        <div class="bg"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
</td></tr></table>
<div class="footer">
  <div class="footer_resize">
    <p class="leftt">Copyright © <? echo "$yourdomain" ;?>. All Rights Reserved</p>
    <p class="rightt">&nbsp;</p>
    <div class="clr"></div>
  </div>
  <div class="clr"></div>
</div>
</body>
</html>
