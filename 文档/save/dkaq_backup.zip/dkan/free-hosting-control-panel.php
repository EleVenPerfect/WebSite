<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?
include('geturl.php');    
?>
<head>
<title>Free Web Hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="main">
  <div class="header">
    <div class="block_header">
      <div class="title"><a href="index.php"><h1><? echo "$yourdomain" ;?> Web Hosting Service</h1></a></div>
<? include ('nav.php'); ?>
      <div class="clr"> </div>
    </div>
  </div>
  <div class="slider2">
    <div class="slider2_resize">
      <h2>Control Panel</h2>
      <p><font color = white>The VistaPanel is packed with all the features you need to build your website including a file manager, PHPMyAdmin, MySQL databases, addon domains, free sub domain names and much more!</font></p>
    </div>
    <div class="clr"></div>
  </div>
  <div class="clr"></div>
  <div class="bloga_resize2">
    <div class="bloga_resizee">
   <div class="menu_sub">
        <ul>
          <li><a href="free-hosting-signup.php">Signup For Free Hosting</a></li>
          <li><a href="about-free-hosting.php">Free Hosting Plan</a></li>
          <li><a href="free-hosting-control-panel.php" class="active" >View Free Control Panel</a></li>
        </ul>
      </div>

    </div>
    <div class="clr"></div>
  </div>
  <div class="clr"></div>
  <div class="body">
    <div class="body_resize">
<h2>
Below you can see a preview of the two great themes in the free hosting control panel:
</h2>
<center>
<h2>x3 cPanel Theme</h2>
<img src = "images/x3-free.png">
<br>
<br><h2>VistaPanel Theme</h2>
<img src = "images/vista-free.png">
<br>
</center>

      <div class="clr"></div>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    </div>
  </div>
</div>
<div class="footer">
  <div class="footer_resize">
    <p class="leftt">Copyright © <? echo "$yourdomain" ;?>. All Rights Reserved</p>
    <p class="rightt">&nbsp;</p>
    <div class="clr"></div>
  </div>
  <div class="clr"></div>
</div>
</body>
</html>
