<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?
include('geturl.php');    
?>
<head>
<title>Signup for Free Hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="main">
  <div class="header">
    <div class="block_header">
      <div class="title"><a href="index.php"><h1><? echo "$yourdomain" ;?> Web Hosting Service</h1></a></div>
<? include ('nav.php'); ?>
      <div class="clr"> </div>
    </div>
  </div>
  <div class="slider2">
    <div class="slider2_resize">
      <h2>Signup</h2>
      <p><font color = white>You are just a few minutes away from getting your own free hosting account and free sub domain name!</font></p>
    </div>
    <div class="clr"></div>
  </div>
  <div class="clr"></div>
  <div class="bloga_resize2">
    <div class="bloga_resizee">
      <div class="menu_sub">
        <ul>
          <li><a href="free-hosting-signup.php"  class="active">Signup For Free Hosting</a></li>
          <li><a href="about-free-hosting.php" >About Free Hosting</a></li>
          <li><a href="free-hosting-control-panel.php" >View Free Control Panel</a></li>
        </ul>
      </div>
    </div>
    <div class="clr"></div>
  </div>
  <div class="clr"></div>
  <div class="body">
    <div class="body_resize">
<h1>Complete the registration form below to apply for free hosting, accounts are activated instantly</h1>


<iframe  src="signup.php" frameborder="0" scrolling="auto" width="1000" height="2080" marginwidth="0" marginheight="0" ></iframe>

      <div class="clr"></div>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    </div>
  </div>
</div>
<div class="footer">
  <div class="footer_resize">
    <p class="leftt">Copyright © <? echo "$yourdomain" ;?>. All Rights Reserved</p>
    <p class="rightt">&nbsp;</p>
    <div class="clr"></div>
  </div>
  <div class="clr"></div>
</div>
</body>
</html>
