@if (!isset($hide_title))
    <div class="page-header">
        <h1>
            @section('title')
            @show
        </h1>
    </div>
@endif
