$(document).ready(function() {
    cmsCommentEdit();
    cmsCommentModel();
    cmsCommentDelete();
    cmsCommentCreate();
    cmsCommentFetch();
    cmsCommentLock = false;
});
