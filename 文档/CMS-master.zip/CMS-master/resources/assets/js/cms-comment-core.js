var cmsCommentLock = true;
