$(document).ready(function() {
    $('#datetimepicker1').datetimepicker({
        format: js_datetime_format
    });
});
