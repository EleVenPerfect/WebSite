# My talks about Techniques

### no record