# Life, just take it easy

## [blog上线](#/tweet/blog-launch)
> 博客上线的一些事一些情



