# Projects that I work in

## [演讲家app](#/project/yjjapp)
> 一个连接讲端和听端，催化各类互动环节的演讲应用

## [freeblog](#/project/freeblog)
> 面向开发者的简易博客框架

## [邑大赏金猎人](#/project/bounty-hunter)
> 针对邑大学子的一个可发布,接受任务的平台

## [邑大书库管理系统](#/project/book-sale-management)
> 邑大教材采购中心管理系统

## [小游戏](#/project/canvas-games)
> 学习canvas时做的小游戏

