# 演讲家app

### coming soon
you can get it [here](https://github.com/3dobe/yjjapp)