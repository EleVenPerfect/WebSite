<!DOCTYPE html>
<html lang="en">
<head>
<title><? echo "$yourdomain" ;?>web hosting| Sign up</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<script src="js/jquery-1.7.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/FF-cash.js"></script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>

  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<!--==============================header=================================-->
<header>
  <div class="main">
    <div class="wrap">
      <h1><a href="index.php"><img src="images/logo.png" alt=""></a><? echo "$yourdomain" ;?></h1>
      <div class="slogan">for free or premium!</div>
      <div class="tooltips"> <a href="/index.php"><img src="images/icon-1.png" alt=""></a><a href="/index.php"><img src="images/icon-2.png" alt=""></a><a href="/index.php"><img src="images/icon-3.png" alt=""></a> </div>
    </div>
    <div class="nav-shadow">
      <div>
        <nav>
          <ul class="menu">
            <li><a href="index.php">Home</a></li>
<li class="current"><a href="signup.php">Sign up</a></li>
            <li><a href="services.php">Services</a></li>
            <li><a href="products.php">Product news</a></li>
            <li><a href="contact.php">Contact us</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
  <div class="header-content header-subpages"></div>
</header>
<!--==============================content================================-->
<section id="content" class="content-subpages">
  <div>
    <div class="wrap">
      <div class="col-1 border-2 block-2">

          <h2><span>Sign Up For Free Hosting</span></h2>
          <div class="clr"></div>
          <p class="post-data">Fill out the form below and your free hosting account will be created.</p>
          
<td style="text-align: left;" colspan="21">
<font size="-1"><span style="font-family: Helvetica,Arial,sans-serif;">
<form method=post action="http://securesignup.net/register.php">
<table>
<tr><th style="text-align: left;">Username<td><input type=text name=username size=20 value="<?PHP if (isset($_GET['username'])) { echo $_GET['username']; }?>">
<tr><th>&nbsp;<td>&nbsp;
<tr><th style="text-align: left;">Password<td><input type=password name=password size=20>
<tr><th>&nbsp;<td>&nbsp;
<tr><th style="text-align: left;">Email Address<td><input type=text name=email size=20 value="<?PHP if (isset($_GET['email'])) { echo $_GET['email']; }?>">

<tr><th style="text-align: left;">Site Category<td><select size="1" name="website_category">
<option>Choose from Below</option>
<option>Personal</option>
<option>Business</option>
<option>Hobby</option>
<option>Forum</option>
<option>Adult</option>
<option>Dating</option>
<option>Software / Download</option>
</select>
</td>

<tr><th style="text-align: left;"><td>
</td>

<tr><th style="text-align: left;">Site Language<td>
<select size="1" name="website_language">
<option>Choose from Below</option>
<option>English</option>
<option>Non-English</option>
</select>
</td>

<tr><th>&nbsp;<td>&nbsp;
<?PHP 
$id = md5(rand(6000,99999999999999991000));
?>
<input type=hidden name=id value="<?PHP echo $id; ?>">
<tr><th style="text-align: left;">Security Code<td><img width="250px" height="90px" src="http://byet.org/image.php?id=<?PHP echo $id; ?>">
<tr><th>&nbsp;<td>&nbsp;
<tr><th style="text-align: left;">Enter Security Code<td><input type=text name=number size=20>
<tr><th>&nbsp;<td>&nbsp;

<tr><th colspan=2><input type=submit value="Register" name=submit>
</table>
</form>		
</span>
<br style="font-family: Helvetica,Arial,sans-serif;">
      </font>
      <br style="font-family: Helvetica,Arial,sans-serif;">
      </span></font>
By signing up for <? echo "$yourdomain" ;?> free hosting, you accept and agree to our <a href="terms.php">Terms of Service</a>
</td>

</div>
      <div class="col-2">
        <h2 class="p2">We Provide</h2>
        <p class="p4">Our custom built, designed and managed network is one of the most powerful networks in the world dedicated solely to free hosting, and all accounts include:</p>
        <ul class="list-1">
<li>1000 MB Disk Space</li>
<li>FTP account and File Manager</li>
<li>MySQL databases &amp; PHP Support</li>
<li>Free tech support</li>
<li>Addon domain, Parked Domains, Sub-Domains</li>
<li>Free Community Access (Forums)</li>
<li>Clustered Servers</li>
<li>Softaculous</li>
<li>Cron Jobs</li>
<li>SPF Records</li>
<li> Automatic Self Signed SSL</li>
          <li><a href="/index.php">phpmyadmin</a></li>
          <li><a href="/index.php">Domain manager</a></li>
          <li><a href="/index.php">ftp account</a></li>
          <li><a href="/index.php">Webmail account</a></li>
          <li><a href="/index.php">cron jobs</a></li>
          <li><a href="/index.php">80 SEO tools</a></li>
          <li><a href="/index.php">Search Engine Submitter</a></li>
          <li><a href="/index.php">Vista panel and cPanel x3 theme</a></li>

        </ul>
        <a href="/index.php" class="button-1 top-3">Read More</a> </div>
    </div>
  </div>
</section>
<!--==============================footer=================================-->
<? include ("footer.php"); ?>

</body>
</html>
