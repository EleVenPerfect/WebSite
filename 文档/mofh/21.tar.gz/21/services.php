<!DOCTYPE html>
<html lang="en">
<head>
<title><? echo "$yourdomain" ;?>web hosting| Services</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<script src="js/jquery-1.7.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/FF-cash.js"></script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<!--==============================header=================================-->
<header>
  <div class="main">
    <div class="wrap">
      <h1><a href="index.php"><img src="images/logo.png" alt=""></a><? echo "$yourdomain" ;?></h1>
      <div class="slogan">for free or premium!</div>
      <div class="tooltips"> <a href="#"><img src="images/icon-1.png" alt=""></a><a href="#"><img src="images/icon-2.png" alt=""></a><a href="#"><img src="images/icon-3.png" alt=""></a> </div>
    </div>
    <div class="nav-shadow">
      <div>
        <nav>
          <ul class="menu">
            <li><a href="index.php">Home</a></li>
<li><a href="signup.php">Sign up</a></li>
            <li class="current"><a href="services.php">Services</a></li>
            <li><a href="products.php">Product news</a></li>
            <li><a href="contact.php">Contact us</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
  <div class="header-content header-subpages"></div>
</header>
<!--==============================content================================-->
<section id="content" class="content-subpages">
  <div>
    <div class="wrap">
      <div class="col-1 border-2 block-2">
        <h2 class="p5">Services</h2>
        <a href="/signup.php" class="button-2">Free accounts Service</a>
        <p class="color-2"><strong>In the Latest news we proudly announce the new features on all free hosting accounts!</strong></p>
        <p>Free hosting accounts are activated instantly, no need to wait for manual approval, you can start building your pages immediately! A powerful Vista Panel control panel is provided to manage your website, packed with hundreds of great features including Email, FTP add-on domain and much more.
</p>
        <a href="https://ifastnet.com/portal/sharedhosting.php" class="button-2 top-1">Premium accounts Service</a>
        <p class="color-2"><strong>You can have a premium account with much more included using cpanel</strong></p>
        <p>We are using a powerful cluster of webservers that are all interconnected to act as one giant super computer. This technology is years ahead of other hosting companies. Combining the power of lots of server simultaneously creates lightening fast website speeds.</p>
        <a href="https://ifastnet.com/portal/vpshosting.php" class="button-2 top-1">VPS server Service</a>
        <p class="color-2"><strong>If you need more resources for your website please consider a VPS.</strong></p>
        <p>A VPS is a contained server of your own with full root SSH access which allows you to see all the servers settings.</p>
</div>

      <div class="col-2">
        <h2 class="p2">Latest News</h2>
        <a href="#" class="link-2">cPanel x3 theme</a>
        <p class="p4">The popular and professional x3 theme is now available for all free hosting accounts.</p>
        <a href="#" class="link-2">80 SEO tools</a>
        <p class="p4">From keyword checkers to page optimization utilities, this huge selection of completely free tools helps you grow a successful website.</p>
        <a href="#" class="link-2">Search Engine Submitter</a>
        <p>All free hosting customers can now submit their websites for free to over 100 search engines from one location in your control panel.  Every free hosting control panel now has the cPanel x3 theme provided as the default theme.</p>
</div>
    </div>
  </div>
</section>
<!--==============================footer=================================-->
<? include ("footer.php"); ?>

</body>
</html>
