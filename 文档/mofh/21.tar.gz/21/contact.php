<!DOCTYPE html>
<html lang="en">
<head>
<title><? echo "$yourdomain" ;?>web hosting | Contact us</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<script src="js/jquery-1.7.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/FF-cash.js"></script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<!--==============================header=================================-->
<header>
  <div class="main">
    <div class="wrap">
      <h1><a href="index.php"><img src="images/logo.png" alt=""></a><? echo "$yourdomain" ;?></h1>
      <div class="slogan">for free or premium!</div>
      <div class="tooltips"> <a href="#"><img src="images/icon-1.png" alt=""></a><a href="#"><img src="images/icon-2.png" alt=""></a><a href="#"><img src="images/icon-3.png" alt=""></a> </div>
    </div>
    <div class="nav-shadow">
      <div>
        <nav>
          <ul class="menu">
            <li><a href="index.php">Home</a></li>
<li><a href="signup.php">Sign up</a></li>
            <li><a href="services.php">Services</a></li>
            <li><a href="products.php">Product news</a></li>
            <li class="current"><a href="contact.php">Contact us</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
  <div class="header-content header-subpages"></div>
</header>
<!--==============================content================================-->
<section id="content">
  <div>
    <div class="wrap">
      <div class="col-1 border-2">

        <h2 class="p3">Contact us</h2>
        <div class="wrap"> 

  <p>If you have any problems or have the need to contact us to ask a question,<br />
      you can use the <span>integrated support system</span> in your control panel to create a support ticket.<br />
   
      We will reply to your question as soon as possible.<br><br />
        </div>
        <div class="wrap top-2">

      For technical support please look at the knowledge base at:<br />
      <a href="http://byet.net/forumdisplay.php?f=28">Knowledge Base</a></p>
        </div>
        <a href="/products.php" class="button-1 top-3">Read More</a> </div>

      <div class="col-2">
        <h2 class="p2">We Provide</h2>
        <p class="p4">Our custom built, designed and managed network is one of the most powerful networks in the world dedicated solely to free hosting, and all accounts include:</p>
        <ul class="list-1">
<li>1000 MB Disk Space</li>
<li>FTP account and File Manager</li>
<li>MySQL databases &amp; PHP Support</li>
<li>Free tech support</li>
<li>Addon domain, Parked Domains, Sub-Domains</li>
<li>Free Community Access (Forums)</li>
<li>Clustered Servers</li>
<li>Softaculous</li>
<li>Cron Jobs</li>
<li>SPF Records</li>
<li> Automatic Self Signed SSL</li>
          <li><a href="/index.php">phpmyadmin</a></li>
          <li><a href="/index.php">Domain manager</a></li>
          <li><a href="/index.php">ftp account</a></li>
          <li><a href="/index.php">Webmail account</a></li>
          <li><a href="/index.php">cron jobs</a></li>
          <li><a href="/index.php">80 SEO tools</a></li>
          <li><a href="/index.php">Search Engine Submitter</a></li>
          <li><a href="/index.php">Vista panel and cPanel x3 theme</a></li>

        </ul>
        <a href="/index.php" class="button-1 top-3">Read More</a> </div>
    </div>
  </div>
</section>
<!--==============================footer=================================-->
<? include ("footer.php"); ?>

</body>
</html>
