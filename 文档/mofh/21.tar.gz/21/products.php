<!DOCTYPE html>
<html lang="en">
<head>
<title><? echo "$yourdomain" ;?>web hosting| Product news</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<script src="js/jquery-1.7.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/FF-cash.js"></script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<!--==============================header=================================-->
<header>
  <div class="main">
    <div class="wrap">
      <h1><a href="index.php"><img src="images/logo.png" alt=""></a><? echo "$yourdomain" ;?></h1>
      <div class="slogan">for free or premium!</div>
      <div class="tooltips"> <a href="#"><img src="images/icon-1.png" alt=""></a><a href="#"><img src="images/icon-2.png" alt=""></a><a href="#"><img src="images/icon-3.png" alt=""></a> </div>
    </div>
    <div class="nav-shadow">
      <div>
        <nav>
          <ul class="menu">
            <li><a href="index.php">Home</a></li>
<li><a href="signup.php">Sign up</a></li>
            <li><a href="services.php">Services</a></li>
            <li class="current"><a href="products.php">Product news</a></li>
            <li><a href="contact.php">Contact us</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
  <div class="header-content header-subpages"></div>
</header>
<!--==============================content================================-->
<section id="content" class="content-subpages">
  <div>
    <div class="wrap">
      <div class="col-1 border-2 block-2">
        <h2 class="p5">Products:</h2>

        <p class="color-2"><strong>We have developed a wide range of Internet solutions including...</strong></p>
        <p>
    Virtual Private Server (VPS) hosting<br>
    Shared Server Premium hosting<br>
    Free Web Hosting<br>
    Domain Registration<br>
    E-mail hosting
<br></br>
And much more both available and in the kettle!</p>
        <a href="https://ifastnet.com/portal/sharedhosting.php" class="button-2 top-1">Premium accounts Service</a>
        <p class="color-2"><strong>Our platform consists of separate sub-GRID networks dedicated to such functions such as MySQL databases</strong></p>
        <p>We provide FTP management and numerous other functions normally hosted on a handful of machines in other hosting services. This doesn't of course go to mention the fact that our platform includes multiple redundancy protections such as power protection, backup systems, load balancing hardware, and a very large and expansive Storage Area Network (SAN) with interconnecting fiber optic change distribution servers.
<br>
All of this combined allows us and our network itself to seamlessly spread traffic demand across multiple servers simultaneously which gives your sites superior performance in turn, ensuring that your sites stay online and running quickly at all times which is important to you, us and your viewers! Our platform handles millions of requests every day but, has the capability to process hundreds of millions of requests or even billions to service you and more importantly, your viewers and Internet users all over the world..</p>
</div>
      <div class="col-2">
        <h2 class="p2">We Provide</h2>
        <p class="p4">Our custom built, designed and managed network is one of the most powerful networks in the world dedicated solely to free hosting, and all accounts include:</p>
        <ul class="list-1">
<li>1000 MB Disk Space</li>
<li>FTP account and File Manager</li>
<li>MySQL databases &amp; PHP Support</li>
<li>Free tech support</li>
<li>Addon domain, Parked Domains, Sub-Domains</li>
<li>Free Community Access (Forums)</li>
<li>Clustered Servers</li>
<li>Softaculous</li>
<li>Cron Jobs</li>
<li>SPF Records</li>
<li> Automatic Self Signed SSL</li>
          <li><a href="/index.php">phpmyadmin</a></li>
          <li><a href="/index.php">Domain manager</a></li>
          <li><a href="/index.php">ftp account</a></li>
          <li><a href="/index.php">Webmail account</a></li>
          <li><a href="/index.php">cron jobs</a></li>
          <li><a href="/index.php">80 SEO tools</a></li>
          <li><a href="/index.php">Search Engine Submitter</a></li>
          <li><a href="/index.php">Vista panel and cPanel x3 theme</a></li>
        </ul>
        <a href="/index.php" class="button-1 top-3">Read More</a> </div>
    </div>
  </div>
</section>

<!--==============================footer=================================-->
<? include ("footer.php"); ?>

</body>
</html>
