<!DOCTYPE html>
<html lang="en">
<head>
<title><? echo "$yourdomain" ;?>web hosting</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<script src="js/jquery-1.7.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/FF-cash.js"></script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<!--==============================header=================================-->
<header>
  <div class="main">
    <div class="wrap">
      <h1><a href="index.php"><img src="images/logo.png" alt=""></a><? echo "$yourdomain" ;?></h1>
      <div class="slogan">for free or premium!</div>
      <div class="tooltips"> <a href="#"><img src="images/icon-1.png" alt=""></a><a href="#"><img src="images/icon-2.png" alt=""></a><a href="#"><img src="images/icon-3.png" alt=""></a> </div>
    </div>
    <div class="nav-shadow">
      <div>
        <nav>
          <ul class="menu">
            <li class="current"><a href="index.php">Home</a></li>
<li><a href="signup.php">Sign up</a></li>
            <li><a href="services.php">Services</a></li>
            <li><a href="products.php">Product news</a></li>
            <li><a href="contact.php">Contact us</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
  <div class="header-content header-subpages"></div>
</header>
<!--==============================content================================-->
<section id="content">
  <div>
    <div class="wrap">
      <div class="col-1 border-2">
        <h2 class="p3">Who We Are?</h2>
        <div class="wrap"> <img src="images/page1-img4.jpg" alt="" class="img-indent img-radius">
          <p class="extra-wrap">We are a friendly, accessible team of engineers, support professionals, business developers and more based all around the world focused on the continued market and technological success of our company while adding value to our services to benefit our users, clients and customers.</p>
        </div>
        <div class="wrap top-2">
          <ul class="list-1 fleft">
            <li><a href="https://ifastnet.com/portal/vpshosting.php"> Virtual Private Server (VPS) hosting</a></li>
            <li><a href="https://ifastnet.com/portal/sharedhosting.php">Shared Server Premium hosting</a></li>
            <li><a href="signup.php">Free Web Hosting</a></li>
            <li><a href="#">Automatic script installer</a></li>
          </ul>
          <ul class="list-1 fleft">
<h2>Free Hosting</h2>
<ul>
<li>1000 MB Disk Space</li>
<li>FTP account and File Manager</li>
<li>Control Panel</li>
<li>MySQL databases &amp; PHP Support</li>
<li>Free tech support</li>
<li>Addon domain, Parked Domains, Sub-Domains</li>
<li>Free Community Access (Forums)</li>
<li>Clustered Servers</li>
<li>Webmail email Accounts</li>
<li>Softaculous</li>
<li>Cron Jobs</li>
<li>SPF Records</li>
<li> Automatic Self Signed SSL</li>
</ul>
        </div>
        <a href="/products.php" class="button-1 top-3">Read More</a> </div>
      <div class="col-2">
        <h2 class="p2">Latest News</h2>
        <a href="#" class="link-2">cPanel x3 theme</a>
        <p class="p4">The popular and professional x3 theme is now available for all free hosting accounts.</p>
        <a href="#" class="link-2">80 SEO tools</a>
        <p class="p4">From keyword checkers to page optimization utilities, this huge selection of completely free tools helps you grow a successful website.</p>
        <a href="#" class="link-2">Search Engine Submitter</a>
        <p>All free hosting customers can now submit their websites for free to over 100 search engines from one location in your control panel.  Every free hosting control panel now has the cPanel x3 theme provided as the default theme.</p>
        <a href="/products.php" class="button-1 top-1">Read More</a> </div>
    </div>
  </div>
</section>
<!--==============================footer=================================-->
<? include ("footer.php"); ?>

</body>
</html>
