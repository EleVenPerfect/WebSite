<footer>
  <p>© 2013 <a href="/index.php" class="link"><? echo "$yourdomain" ;?>web hosting services</a>
</p>
</footer>
