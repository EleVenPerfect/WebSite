  <div id="bottomMainPan">
    <div id="bottomBorderPan">
      <h2>more tips</h2>
      <h3>more links</h3>
      <h4>announcements </h4>
      <ul>
        <li><a href="http://www.free-css.com/">Lorem Ipsum has been the</a></li>
        <li><a href="http://www.free-css.com/">industry's standard dum</a></li>
        <li><a href="http://www.free-css.com/">text ever since the 1500s, </a></li>
        <li><a href="http://www.free-css.com/">when an unknown printer</a></li>
        <li><a href="http://www.free-css.com/">galley of type and</a></li>
        <li><a href="http://www.free-css.com/">especimen </a></li>
        <li><a href="http://www.free-css.com/">has survived</a></li>
      </ul>
      <ul>
        <li><a href="http://www.free-css.com/">Lorem Ipsum has been the</a></li>
        <li><a href="http://www.free-css.com/">industry's standard dum</a></li>
        <li><a href="http://www.free-css.com/">text ever since the 1500s, </a></li>
        <li><a href="http://www.free-css.com/">when an unknown printer</a></li>
        <li><a href="http://www.free-css.com/">galley of type and</a></li>
        <li><a href="http://www.free-css.com/">scrambled make a typ</a></li>
        <li><a href="http://www.free-css.com/">has survived</a></li>
      </ul>
      <ul>
        <li><a href="http://www.free-css.com/">Lorem Ipsum has been the</a></li>
        <li><a href="http://www.free-css.com/">industry's standard dum</a></li>
        <li><a href="http://www.free-css.com/">text ever since the 1500s, </a></li>
        <li><a href="http://www.free-css.com/">when an unknown printer</a></li>
        <li><a href="http://www.free-css.com/">scrambled make a typ</a></li>
        <li><a href="http://www.free-css.com/">especimen </a></li>
        <li><a href="http://www.free-css.com/">has survived</a></li>
      </ul>
    </div>
  </div>
