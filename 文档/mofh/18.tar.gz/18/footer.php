<div id="footerPan">


    <ul>

      <li><a href="index.php">Home</a> </li>
      <li><a href="signup.php">signup</a></li>
      <li><a href="hostingnews.php">hosting news</a></li>
      <li><a href="https://ifastnet.com/portal/terms.php">terms</a></li>
      <li><a href="contact.php">Contact</a> </li>
    </ul>

</div>
