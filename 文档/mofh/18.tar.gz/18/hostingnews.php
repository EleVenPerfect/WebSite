<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><? echo "$yourdomain" ;?>web hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>

<div id="header_container">
 <? include ("header.php"); ?>

<div id="bodymiddlePan">
  <h2>about <? echo "$yourdomain" ;?></h2>
  <p>We are specialists in free hosting services using clustered technology powered by a one of the largest hosting orgainisations on the internet. You can sign up here for fast free PHP & MySQL hosting including a free sub domain. A powerful Vista Panel control panel is provided to manage your website, packed with hundreds of great features including Email, FTP add-on domain and much more.</p><br>
  <p class="lasttext">We are using a powerful cluster of webservers that are all interconnected to act as one giant super computer. This technology is years ahead of other hosting companies. Combining the power of lots of server simultaneously creates lightening fast website speeds. Not only is the service extremely fast, it is resistant to common failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run as fast as ever while the working servers deliver your
    pages.</p>
</div>

<div id="bodyBottomPan">
<? include ("infopan.php"); ?>
</div>

<div id="footermainPan">
<? include ("footer.php"); ?>
</div>
</body>
</html>
