<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><? echo "$yourdomain" ;?>web hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>

<div id="header_container">
 <? include ("header.php"); ?>
</div>

<div id="bodymiddlePan">

<h2>The Main Hosting Features on all our free accounts!
</h2>

<p>
<li>1000 MB Disk Space</li>
<li>FTP account and File Manager</li>
<li>Control Panel</li>
<li>MySQL databases &amp; PHP Support</li>
<li>Free tech support</li>
<li>Addon domain, Parked Domains, Sub-Domains</li>
<li>Free Community Access (Forums)</li>
<li>Clustered Servers</li>
<li>Webmail email Accounts</li>
<li>Softaculous</li>
<li>Cron Jobs</li>
<li>SPF Records</li>
<li> Automatic Self Signed SSL</li>
  </p>
</div>


<div id="bodyBottomPan">
<? include ("infopan.php"); ?>
</div>

<div id="footermainPan">
<? include ("footer.php"); ?>
</div>
</body>
</html>
