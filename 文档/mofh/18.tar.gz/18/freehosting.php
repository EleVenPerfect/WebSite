<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><? echo "$yourdomain" ;?>web hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>

<div id="header_container">
  <div id="header"> <a href="http://www.free-css.com/"><img src="images/logo.gif" alt="Total Management" title="Total Management" border="0" /></a>
<h1>Welcome to <? echo "$yourdomain" ;?> Hosting</h1>
    <ul>
      <li><a href="index.php">Home</a> </li>
      <li><a href="signup.php">signup</a></li>
      <li><a href="freehostingnews.php">Whats new</a></li>
      <li class="contact"><a href="http://www.free-css.com/">Contact</a></li>
    </ul>  

  </div>
</div>
<div id="body1">
  <form action="http://www.free-css.com/" method="post" >
    <label>members login:</label>
    <input name="Your name" type="text" id="yourname" value="Your name" />
    <input name="emailid" type="text" id="emailid" value="Email Id" />
    <input name="" type="submit" class="botton" value="GO" />
  </form>
</div>
<div id="bodymiddlePan">
  <h2>about total management?</h2>
  <p>Total Management is a free, tableless, W3C-compliant web design layout by Template World. This template has been tested and proven compatible with all major browser environments and operating systems. You are free to modify the design to suit your tastes in any way you like.</p>
  <p>We only ask you to not remove <span>"Design by Template World"</span> and the link http://www.templateworld.com from the footer of the template.</p>
  <p class="lasttext">If you are interested in seeing more of our free web template designs feel free to visit our website, Template World. We intend to add at least 25 new free templates in the coming month.</p>
</div>

<div id="bodyBottomPan">
<? include ("infopan.php"); ?>
</div>


<div id="bottomPan">
 <? include ("bottompan.php"); ?>
</div>

<div id="footermainPan">
<? include ("footer.php"); ?>
</div>
</body>
</html>
