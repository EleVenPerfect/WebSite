<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><? echo "$yourdomain" ;?>web hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>

<div id="header_container">

 <? include ("header.php"); ?>

</div>

<div id="bodymiddlePan">
<h2>Sign Up For Free Hosting</h2>
<p>
Fill out the form below and your free hosting account will be created. <br>

<? include ("signupform.php"); ?>

</p>

</div>

<div id="bodyBottomPan">
<? include ("infopan.php"); ?>
</div>

<div id="footermainPan">
<? include ("footer.php"); ?>
</div>
</body>
</html>
