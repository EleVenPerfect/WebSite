<div id="header"> 
<h1>Free Hosting Solution</h1>
<a href="index.php"><img src="images/logo.gif" alt="Total Management" title="Total Management" border="0" /></a>
    <ul>
      <li><a href="index.php">Home</a> </li>
      <li><a href="signup.php">signup</a></li>
      <li><a href="hostingnews.php">hosting news</a></li>
      <li><a href="https://ifastnet.com/portal/terms.php">terms</a></li>
      <li class="contact"><a href="contact.php">Contact</a></li>
    </ul>  
<h2><? echo "$yourdomain" ;?></h2>
</div>
