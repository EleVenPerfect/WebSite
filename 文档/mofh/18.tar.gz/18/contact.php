<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><? echo "$yourdomain" ;?>web hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>

<div id="header_container">
 <? include ("header.php"); ?>

<div id="bodymiddlePan">
  <h2>contact <? echo "$yourdomain" ;?></h2>
<a href="signup.php"><b>click here to sign up for free hosting</b></a>
<p>
If you have any problems or have the need to contact us, you can use the integrated support system in your control panel to create a support ticket.  We will reply to your question as soon as possible.
<br>For additional technical support and an extensive knowledge base checkout our <a href="http://byet.net/forumdisplay.php?f=28"><b>forum</b></p></a>
</div>

<div id="bodyBottomPan">
<? include ("infopan.php"); ?>
</div>


<div id="bottomPan">
 <? include ("bottompan.php"); ?>
</div>

<div id="footermainPan">
<? include ("footer.php"); ?>
</div>
</body>
</html>
