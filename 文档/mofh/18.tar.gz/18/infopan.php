  <div id="infoPan">
    <h2>premium</h2>
    <p>great premium plans</p>
    <p class="view"><a href="https://ifastnet.com/portal/">view</a></p>
  </div>

  <div id="servicesPan">
    <h2>vps server</h2>
    <p>upgrade to a vps</p>
  <p class="view"><a href="https://ifastnet.com/portal/vpshosting.php">view</a></p>
  </div>

  <div id="schedulePan">
    <h2>dedicated</h2>
    <p>dedicated servers</p>
  <p class="view"><a href="https://ifastnet.com/portal/dedicatedserver.php">view</a></p>
  </div>



