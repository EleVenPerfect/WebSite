<!DOCTYPE php>
<php lang="en">
<head>
<title><? echo "$yourdomain" ;?> web hosting</title>
<meta name="description" content="Place your description here">
<meta name="keywords" content="put, your, keyword, here">
<meta name="author" content="Templates.com - website templates provider">
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/maxheight.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/jquery.faded.js"></script>
<script type="text/javascript" src="js/jquery.jqtransform.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript">
	$(function(){
		$("#faded").faded({
			speed: 500,
			crossfade: true,
			autoplay: 10000,
			autopagination:false
		});
		
		$('#domain-form').jqTransform({imgPath:'jqtransformplugin/img/'});
	});
</script>
<!--[if lt IE 7]>
<script type="text/javascript" src="http://info.template-help.com/files/ie6_warning/ie6_script_other.js"></script>
<![endif]-->
<!--[if lt IE 9]>
<script type="text/javascript" src="js/php5.js"></script>
<![endif]-->
</head>
<body id="page1" onLoad="new ElementMaxHeight();">
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<div class="tail-top">
<!-- header -->
	<header>
		<div class="container">
			<div class="header-box">
				<div class="left">
					<div class="right">
						<nav>
							<ul>
								<li class="current"><a href="index.php">Home</a></li>
								<li><a href="signup.php">Sign up</a></li>
								<li><a href="news.php">News</a></li>
								<li><a href="contact.php">Contact</a></li>
							</ul>
						</nav>
			<h1><a href="index.php"><span><? echo "$yourdomain" ;?></span> Hosting</a></h1>
					</div>
				</div>
			</div>
			<span class="top-info">24/7 Sales &amp; Support  &nbsp; l  &nbsp; <a href="#">Hot Deals</a> </span>
			<form action="" id="login-form">
				<fieldset>
					<a href="http://cpanel.<? echo "$yourdomain" ;?>" class="login" onClick="document.getElementById('login-form').submit()"><span><span>Login</span></span></a>
					<span class="links"><a href="http://cpanel.<? echo "$yourdomain" ;?>/lostpassword.php">Forgot Password?</a><br/><a href="signup.php">Register</a></span>
				</fieldset>
			</form>
		</div>
	</header>
<!-- content -->
	<section id="content"><div class="ic"></div>
		<div class="container">
			<div id="faded">
				<ul class="slides">
					<li><img src="images/slide-title1.gif"><a href="#"><span><span>Learn More</span></span></a></li>
					<li><img src="images/slide-title4.gif"><a href="#"><span><span>Learn More</span></span></a></li>
					<li><img src="images/slide-title3.gif"><a href="#"><span><span>Learn More</span></span></a></li>
					<li><img src="images/slide-title2.gif"><a href="#"><span><span>Learn More</span></span></a></li>
				</ul>
				<ul class="pagination">
					<li><a href="#" rel="0"><span>Premium Plans</span><small>Get more information</small></a></li>
					<li><a href="#" rel="1"><span>Free Hosting</span><small>Get more information</small></a></li>
					<li><a href="#" rel="2"><span>VPS Hosting</span><small>Get more information</small></a></li>
					<li><a href="#" rel="3"><span>Dedicated</span><small>Get more information</small></a></li>
				</ul>
			</div>
			<div class="inside">
				<div class="wrapper row-1">
					<div class="box col-1 maxheight">
						<div class="border-right maxheight">
							<div class="border-bot maxheight">
								<div class="border-left maxheight">
									<div class="left-top-corner maxheight">
										<div class="right-top-corner maxheight">
											<div class="right-bot-corner maxheight">
												<div class="left-bot-corner maxheight">
													<div class="inner">
														<h3>Free accounts</h3>
														<ul class="info-list">
<li>1000 MB Disk Space</li>
<li>FTP account and File Manager</li>
<li>Control Panel</li>
<li>MySQL databases &amp; PHP Support</li>
<li>Free tech support</li>
<li>Addon domain, Parked Domains, Sub-Domains</li>
<li>Free Community Access (Forums)</li>
<li>Clustered Servers</li>
<li>No ads!</li>
<li>SSL on all free hosting domains</li>
														</ul>
														<span class="price">$ 0.00 p/m</span>
														<div class="aligncenter"><a href="signup.php" class="link1"><span><span>Learn More</span></span></a></div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="box col-2 maxheight">
						<div class="border-right maxheight">
							<div class="border-bot maxheight">
								<div class="border-left maxheight">
									<div class="left-top-corner maxheight">
										<div class="right-top-corner maxheight">
											<div class="right-bot-corner maxheight">
												<div class="left-bot-corner maxheight">
													<div class="inner">
														<h3>Premium Plan</h3>
														<ul class="info-list">
															<li><span>Disk space</span>unlimited</li>
															<li><span>Monthly transfer</span>5000 Gb</li>
															<li><span>FTP accounts</span>20</li>
															<li><span>Email boxes</span>20</li>
															<li><span>Free domains</span>6</li>
														</ul>
														<span class="price">$ 3.99 p/m</span>
														<div class="aligncenter"><a href="https://ifastnet.com/portal/sharedhosting.php" class="link1"><span><span>Learn More</span></span></a></div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="box col-3 maxheight">
						<div class="border-right maxheight">
							<div class="border-bot maxheight">
								<div class="border-left maxheight">
									<div class="left-top-corner maxheight">
										<div class="right-top-corner maxheight">
											<div class="right-bot-corner maxheight">
												<div class="left-bot-corner maxheight">
													<div class="inner">
														<h3>VPS Plan</h3>
														<ul class="info-list">
															<li><span>Disk space</span>see plans</li>
															<li><span>Monthly transfer</span>unlimitrd</li>
															<li><span>FTP accounts</span>n/a</li>
															<li><span>Email boxes</span>n/a</li>
															<li><span>Free domains</span>n/a</li>
														</ul>
														<span class="price">$ 9.99 p/m</span>
														<div class="aligncenter"><a href="https://ifastnet.com/portal/vpshosting.php" class="link1"><span><span>Learn More</span></span></a></div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="box col-4 maxheight">
						<div class="border-right maxheight">
							<div class="border-bot maxheight">
								<div class="border-left maxheight">
									<div class="left-top-corner maxheight">
										<div class="right-top-corner maxheight">
											<div class="right-bot-corner maxheight">
												<div class="left-bot-corner maxheight">
													<div class="inner">
														<h3>Dedicated</h3>
														<ul class="info-list">
															<li><span>Disk space</span>see plans</li>
															<li><span>Monthly transfer</span>see plans</li>
															<li><span>FTP accounts</span>Unlimited</li>
															<li><span>Email boxes</span>Unlimited</li>
															<li><span>Free domains</span>n/a</li>
														</ul>
														<span class="price">$ 89.99 p/m</span>
														<div class="aligncenter"><a href="https://ifastnet.com/portal/dedicatedserver.php" class="link1"><span><span>Learn More</span></span></a></div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="inside1">
					<div class="wrap row-2">
						<article class="col-1">
							<h2>Solutions</h2>
							<ul class="solutions">
								<li><img src="images/icon1.gif"><p>Quickly and easily create a Web Page</p><a href="#"><b>Read More</b></a></li>
								<li><img src="images/icon2.gif"><p>Share documents any time, any where</p><a href="#"><b>Read More</b></a></li>
								<li><img src="images/icon3.gif"><p>24/7 Real Person Customer Support</p><a href="#"><b>Read More</b></a></li>
								<li><img src="images/icon4.gif"><p>Online Account Management Tools</p><a href="#"><b>Read More</b></a></li>
							</ul>
						</article>
						<article class="col-2">
							<h2>Register Domain Name</h2>
							<form action="" id="domain-form">
								<div class="img-box"><img src="images/1page-img.jpg">
									<div class="extra-wrap">
										<fieldset>
											<span class="text">
												<input type="text" value="enter domain name" onFocus="if(this.value=='enter domain name'){this.value=''}" onBlur="if(this.value==''){this.value='enter domain name'}">
											</span>
											<ul class="checkboxes wrapper">
												<li><input type="checkbox"><label>.mx</label></li>
												<li><input type="checkbox"><label>.net</label></li>
												<li><input type="checkbox"><label>.com</label></li>
												<li><input type="checkbox"><label>.eu</label></li>
												<li class="alt"><input type="checkbox"><label>.us.com</label></li>
												<li><input type="checkbox"><label>.us.com</label></li>
												<li><input type="checkbox"><label>.info</label></li>
												<li><input type="checkbox"><label>.mobi</label></li>
												<li><input type="checkbox"><label>.co.uk</label></li>
												<li class="alt"><input type="checkbox"><label>.tv</label></li>
											</ul>
										</fieldset>
									</div>
								</div>
								<div class="wrapper">
									<a href="#" class="link2 fleft" onClick="document.getElementById('domain-form').submit()"><span><span>Check  Domain</span></span></a>
									<ul class="links fleft">
										<li><a href="#">Renew a domain</a></li>
										<li><a href="#">Transfer a domain</a></li>
										<li><a href="#">WHOIS</a></li>
									</ul>
								</div>
							</form>
							<h2>Your Domain Name Helps the World  to Find You</h2>
							<p>Premium Hosting features cPanel 11 with Fantastico on 16 core Intel Xeon servers!</p>
							<p>Our Premium Hosting solutions are powered by the industry standard cPanel control panel system featuring the easy to use Softiculious Automatic Script installer for easy script installation and deployment (256 scripts!).  ..</p>
							<a href="#" class="link2"><span><span>Read More</span></span></a>
						</article>
						<div class="clear"></div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<!-- aside -->
<aside>
	<div class="container">
		<div class="inside">
			<div class="line-ver1">
				<div class="line-ver2">
					<div class="line-ver3">
						<div class="wrapper line-ver4">
							<ul class="list col-1">
								<li>Account Manager</li>
								<li><a href="#">My Account</a></li>
								<li><a href="#">Account Settings</a></li>
								<li><a href="#">Customer Information</a></li>
								<li><a href="#">Order History</a></li>
							</ul>
							<ul class="list col-2">
								<li>Shopping</li>
								<li><a href="#">Offer Disclaimers</a></li>
								<li><a href="#">Domain Search</a></li>
								<li><a href="#">Gift Cards</a></li>
								<li><a href="#">Mobile</a></li>
							</ul>
							<ul class="list col-3">
								<li>Resources</li>
								<li><a href="#">Webmail</a></li>
								<li><a href="#">WHOIS search</a></li>
								<li><a href="#">ICANN Confirmation</a></li>
								<li><a href="#">Affiliates</a></li>
							</ul>
							<ul class="list col-4">
								<li>Help and Support</li>
								<li><a href="#">Support &amp; Sales</a></li>
								<li><a href="#">Billing Support</a></li>
								<li><a href="#">FAQ’s</a></li>
								<li><a href="#">User’s Guides</a></li>

							</ul>
							<ul class="list col-5">
								<li>About</li>
								<li><a href="#">Security Center</a></li>
								<li><a href="#">Company Info</a></li>
								<li><a href="#">News Center</a></li>
								<li><a href="#">What’s New</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</aside>
<!-- footer -->
<footer>
	<div class="container">
		<div class="inside">
			<a rel="nofollow" href="index.php" class="new_window"><? echo "$yourdomain" ;?></a>
		</div>
	</div>
</footer>
<script type="text/javascript"> Cufon.now(); </script>
</body>
</php>
