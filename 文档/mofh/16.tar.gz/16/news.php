<!DOCTYPE html>
<html lang="en">
<head>
<title>news <? echo "$yourdomain" ;?></title>
<meta name="description" content="Place your description here">
<meta name="keywords" content="put, your, keyword, here">
<meta name="author" content="Templates.com - website templates provider">
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/maxheight.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<!--[if lt IE 7]>
	<script type="text/javascript" src="http://info.template-help.com/files/ie6_warning/ie6_script_other.js"></script>
 <![endif]-->
<!--[if lt IE 9]>
  	<script type="text/javascript" src="js/html5.js"></script>
  <![endif]-->
</head>
<body id="page4" onLoad="new ElementMaxHeight();">
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<div class="tail-top3">
	<!-- header -->
	<header>
		<div class="container">
			<div class="header-box">
				<div class="left">
					<div class="right">
						<nav>
							<ul>
									<li><a href="index.php">Home</a></li>
								<li><a href="signup.php">Sign up</a></li>
								<li class="current"><a href="news.php">News</a></li>
								<li><a href="contact.php">Contact</a></li>
							</ul>
						</nav>
			<h1><a href="index.php"><span><? echo "$yourdomain" ;?></span> Hosting</a></h1>
					</div>
				</div>
			</div>
<span class="top-info">24/7 Sales &amp; Support  &nbsp; l  &nbsp; <a href="#">Hot Deals</a> </span>
                        <form action="" id="login-form">
                                <fieldset>
                                        <a href="http://cpanel.<? echo "$yourdomain" ;?>" class="login" onClick="document.getElementById('login-form').submit()"><span><span>Login</span></span></a>
                                        <span class="links"><a href="http://cpanel.<? echo "$yourdomain" ;?>/lostpassword.php">Forgot Password?</a><br/><a href="signup.php">Register</a></span>
                                </fieldset>
                        </form>

		</div>
	</header>
	<!-- content -->
	<section id="content"><div class="ic">More Website Templates at TemplateMonster.com!</div>
		<div class="container">
			<div class="inside">
				<div id="slogan" class="bot-indent1">
					<div class="inside">
						<h2><span>Your Domain Name</span> Helps the World  to Find You</h2>
						<p>Combined with our high bandwidth, space provisions and excellent sub-domain options, make us the optimal option. Our very popular Community Forums has been taken up excellently and active members are growing steadily, hence resulting in a better hosting and friendly experience..</p>
					</div>
				</div>
				<div class="wrapper row-1">
					<div class="box col-1 maxheight">
						<div class="border-right maxheight">
							<div class="border-bot maxheight">
								<div class="border-left maxheight">
									<div class="left-top-corner maxheight">
										<div class="right-top-corner maxheight">
											<div class="right-bot-corner maxheight">
												<div class="left-bot-corner maxheight">
													<div class="inner">
														<h3>Basic Free Plan</h3>
														<ul class="info-list">
															<li><span>Disk space</span>300 Gb</li>
															<li><span>Monthly transfer</span>300 Gb</li>
															<li><span>FTP accounts</span>5</li>
															<li><span>Email boxes</span>1</li>
															<li><span>Free sub domains</span>5</li>
														</ul>
														<span class="price">$ 0.00 p/m</span>
														<div class="aligncenter"><a href="signup.php" class="link1"><span><span>Learn More</span></span></a></div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="box col-2 maxheight">
						<div class="border-right maxheight">
							<div class="border-bot maxheight">
								<div class="border-left maxheight">
									<div class="left-top-corner maxheight">
										<div class="right-top-corner maxheight">
											<div class="right-bot-corner maxheight">
												<div class="left-bot-corner maxheight">
													<div class="inner">
														<h3>Premium Plan</h3>
														<ul class="info-list">
															<li><span>Disk space</span>unlimited</li>
															<li><span>Monthly transfer</span>5000 Gb</li>
															<li><span>FTP accounts</span>20</li>
															<li><span>Email boxes</span>20</li>
															<li><span>Free domains</span>6</li>
														</ul>
														<span class="price">$ 3.99 p/m</span>
														<div class="aligncenter"><a href="https://ifastnet.com/portal/sharedhosting.php" class="link1"><span><span>Learn More</span></span></a></div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="box col-3 maxheight">
						<div class="border-right maxheight">
							<div class="border-bot maxheight">
								<div class="border-left maxheight">
									<div class="left-top-corner maxheight">
										<div class="right-top-corner maxheight">
											<div class="right-bot-corner maxheight">
												<div class="left-bot-corner maxheight">
													<div class="inner">
														<h3>VPS Plan</h3>
														<ul class="info-list">
															<li><span>Disk space</span>see plans</li>
															<li><span>Monthly transfer</span>see plans</li>
															<li><span>FTP accounts</span>n/a</li>
															<li><span>Email boxes</span>n/a</li>
															<li><span>Free domains</span>n/a</li>
														</ul>
														<span class="price">$ 9.99 p/m</span>
														<div class="aligncenter"><a href="https://ifastnet.com/portal/vpshosting.php" class="link1"><span><span>Learn More</span></span></a></div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="box col-4 maxheight">
						<div class="border-right maxheight">
							<div class="border-bot maxheight">
								<div class="border-left maxheight">
									<div class="left-top-corner maxheight">
										<div class="right-top-corner maxheight">
											<div class="right-bot-corner maxheight">
												<div class="left-bot-corner maxheight">
													<div class="inner">
														<h3>Dedicated</h3>
														<ul class="info-list">
															<li><span>Disk space</span>see plans</li>
															<li><span>Monthly transfer</span>see plans</li>
															<li><span>FTP accounts</span>Unlimited</li>
															<li><span>Email boxes</span>Unlimited</li>
															<li><span>Free domains</span>n/a</li>
														</ul>
														<span class="price">$ 89.99 p/m</span>
														<div class="aligncenter"><a href="https://ifastnet.com/portal/dedicatedserver.php" class="link1"><span><span>Learn More</span></span></a></div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="inside1">
					<div class="wrap row-2">
						<article class="col-1">
							<h2>Solutions</h2>
							<ul class="solutions">
								<li><img src="images/icon1.gif">
									<p>Quickly and easily create a Web Page</p>
									<a href="#"><b>Read More</b></a></li>
								<li><img src="images/icon2.gif">
									<p>Share documents any time, any where</p>
									<a href="#"><b>Read More</b></a></li>
								<li><img src="images/icon3.gif">
									<p>24/7 Real Person Customer Support</p>
									<a href="#"><b>Read More</b></a></li>
								<li><img src="images/icon4.gif">
									<p>Online Account Management Tools</p>
									<a href="#"><b>Read More</b></a></li>
							</ul>
						</article>
						<article class="col-2">
							<h2>Ideal Solutions</h2>
							<div class="img-box"><img src="images/4page-img.jpg"><strong>We are specialists</strong> in free hosting services using clustered technology powered by a one of the largest hosting orgainisations on the internet. Combined with our high bandwidth, space provisions and excellent sub-domain options, make us the optimal option.</div>
							<p>

Our network seamlessly spreads the traffic demand across multiple servers simultaneously, which gives your sites superior performance and ensuring they stay online and running quickly at all times!  Our platform has the capability to process hundreds of millions of requests or even billions to service you and more importantly, your viewers and Internet users all over the world.</p>
<p class="p1">
You can sign up here for fast free PHP & MySQL hosting including a free sub domain. A powerful Vista Panel control panel is provided to manage your website, packed with hundreds of great features including Email, FTP add-on domain and much more.<br>

You can find our Automatic Script Installer in the Vistapanel which deploys your website files and folders in seconds!. No need to wait a long time uploading files. <br>We provide free FTP, PHP 5.3, MySQL and our very popular feature: The Automatic Script Installer (Like Fantastico) You can install many popular scripts such as PHPbb2 and PHPbb3, Wordpress, Zen-Cart, osCommerce, MyBB, UseBB, MyLittle Forum, 4images, Coppermine, SMF, Joomla, e107, XOOPS, PHP Wind, CuteNews, Mambo, WikiWig and many more!</p>
<p class="p1">

We are using a powerful cluster of webservers that are all interconnected to act as one giant super computer. This technology is years ahead of other hosting companies. Combining the power of lots of server simultaneously creates lightening fast website speeds. Not only is the service extremely fast, it is resistant to common failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run as fast as ever while the working servers deliver your pages.<br></p>

        <li><a href="/signup.php">Sign up for Free Hosting</a></li>
        <li><a href="https://ifastnet.com/portal/sharedhosting.php">Sign up for Premium Hosting</a></li>
        <li><a href="https://ifastnet.com/portal/vpshosting.php">Sign up for a VPS Server</a></li>


							<a href="#" class="link2"><span><span>Read More</span></span></a> </article>
						<article class="col-3">
							<h2>Showcase</h2>
							<ul class="list1">
								<li><a href="#">Sed ut perspiciatis unde</a></li>
								<li><a href="#">Omnis iste natus error sit volupta</a></li>
								<li><a href="#">Tem accusantium doloreque</a></li>
								<li><a href="#">Laudantiumtotam rem aperiam</a></li>
								<li><a href="#">Eaque ipsa quae</a></li>
								<li><a href="#">Lnventore veritatis et quasi</a></li>
								<li><a href="#">Architecto beatae vitae</a></li>
								<li><a href="#">Dicta sunt explicabo</a></li>
								<li><a href="#">Nemo enim ipsam voluptatem</a></li>
								<li><a href="#">Quia voluptas sit aspernatur</a></li>
								<li><a href="#">Aut odit aut fugit, sed quia</a></li>
								<li><a href="#">Consequuntur magni</a></li>
							</ul>
							<a href="#" class="link2"><span><span>More Solutions</span></span></a> </article>
						<div class="clear"></div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<!-- aside -->
<aside>
	<div class="container">
		<div class="inside">
			<div class="line-ver1">
				<div class="line-ver2">
					<div class="line-ver3">
						<div class="wrapper line-ver4">
							<ul class="list col-1">
								<li>Account Manager</li>
								<li><a href="#">My Account</a></li>
								<li><a href="#">Account Settings</a></li>
								<li><a href="#">Customer Information</a></li>
								<li><a href="#">Order History</a></li>
							</ul>
							<ul class="list col-2">
								<li>Shopping</li>
								<li><a href="#">Offer Disclaimers</a></li>
								<li><a href="#">Domain Search</a></li>
								<li><a href="#">Gift Cards</a></li>
								<li><a href="#">Mobile</a></li>
							</ul>
							<ul class="list col-3">
								<li>Resources</li>
								<li><a href="#">Webmail</a></li>
								<li><a href="#">WHOIS search</a></li>
								<li><a href="#">ICANN Confirmation</a></li>
								<li><a href="#">Affiliates</a></li>
							</ul>
							<ul class="list col-4">
								<li>Help and Support</li>
								<li><a href="#">Support &amp; Sales</a></li>
								<li><a href="#">Billing Support</a></li>
								<li><a href="#">FAQ’s</a></li>
								<li><a href="#">User’s Guides</a></li>

							</ul>
							<ul class="list col-5">
								<li>About</li>
								<li><a href="#">Security Center</a></li>
								<li><a href="#">Company Info</a></li>
								<li><a href="#">News Center</a></li>
								<li><a href="#">What’s New</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</aside>
<!-- footer -->
<footer>
	<div class="container">
		<div class="inside">
			<a rel="nofollow" href="index.php" class="new_window"><? echo "$yourdomain" ;?></a>
		</div>
	</div>
</footer>
<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>
