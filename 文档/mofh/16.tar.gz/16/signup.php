<!DOCTYPE html>
<html lang="en">
<head>
<title>sign up <? echo "$yourdomain" ;?></title>
<meta name="description" content="Place your description here">
<meta name="keywords" content="put, your, keyword, here">
<meta name="author" content="Templates.com - website templates provider">
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_600.font.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<!--[if lt IE 7]>
	<script type="text/javascript" src="http://info.template-help.com/files/ie6_warning/ie6_script_other.js"></script>
 <![endif]-->
<!--[if lt IE 9]>
  	<script type="text/javascript" src="js/html5.js"></script>
  <![endif]-->
</head>
<body id="page2">
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<div class="tail-top1">
	<!-- header -->
	<header>
		<div class="container">
			<div class="header-box">
				<div class="left">
					<div class="right">
						<nav>
							<ul>
								<li><a href="index.php">Home</a></li>
								<li class="current"><a href="signup.php">Sign up</a></li>
								<li><a href="news.php">News</a></li>
								<li><a href="contact.php">Contact</a></li>
							</ul>
						</nav>
			<h1><a href="index.php"><span><? echo "$yourdomain" ;?></span> Hosting</a></h1>
					</div>
				</div>
			</div>
<span class="top-info">24/7 Sales &amp; Support  &nbsp; l  &nbsp; <a href="#">Hot Deals</a> </span>
                        <form action="" id="login-form">
                                <fieldset>
                                        <a href="http://cpanel.<? echo "$yourdomain" ;?>" class="login" onClick="document.getElementById('login-form').submit()"><span><span>Login</span></span></a>
                                        <span class="links"><a href="http://cpanel.<? echo "$yourdomain" ;?>/lostpassword.php">Forgot Password?</a><br/><a href="signup.php">Register</a></span>
                                </fieldset>
                        </form>

		</div>
	</header>
	<!-- content -->
	<section id="content"><div class="ic"></div>
		<div class="container">
			<div class="inside">
				<div id="slogan">
					<div class="inside">
						<h2><span>Your Domain Name</span> Helps the World  to Find You</h2>
						<p>You can sign up here for fast free PHP & MySQL hosting including a free sub domain. A powerful Vista Panel control panel is provided to manage your website, packed with hundreds of great features including Email, FTP add-on domain and much more..</p>
					</div>
				</div>
				<ul class="banners wrapper">
					<li><a href="/signup.php">Free  &nbsp; <b>$0.00</b></a></li>
					<li><a href="https://ifastnet.com/portal/sharedhosting.php">Premium  &nbsp; <b>$3.99</b></a></li>
					<li><a href="https://ifastnet.com/portal/vpshosting.php">VPS  &nbsp; <b>$9.99</b></a></li>
					<li><a href="https://ifastnet.com/portal/dedicatedserver.php">Dedicated  &nbsp; <b>$89.99</b></a></li>
				</ul>
				<div class="inside1">
					<div class="wrap row-2">
						<article class="col-1">
							<ul class="solutions">
								<li><img src="images/icon1.gif">
									<p>Quickly and easily create a Web Page</p>
									<a href="index.php"><b>Read More</b></a></li>
								<li><img src="images/icon2.gif">
									<p>Instant activation</p>
									<a href="news.php"><b>Read More</b></a></li>
								<li><img src="images/icon3.gif">
									<p>24/7 Customer Support</p>
									<a href="contact.php"><b>Read More</b></a></li>
								<li><img src="images/icon4.gif">
									<p>Online Account Management Tools</p>
									<a href="index.php"><b>Read More</b></a></li>
							</ul>
						</article>
						<article class="col-2">

<h2>Sign Up For Free Hosting</h2>

<ul class="list1">
<li>10GB Disk Space</li>
<li>100GB Bandwidth</li>
<li>10 Domains Hosting</li>
<li>Webmail email Accounts</li>
<li>Professional Website Builder</li>
<li>Softaculous</li>
<li>Easy-to-use Control Panel</li>
<li>Cron Jobs</li>
<li>SPF Records</li>
<li> Install your own SSL certificate</li> 
					<li>Automatic Self Signed SSL</li>
					<li>Search Engine Submitter</li>
					</ul>

          <div class="clr"></div>

Fill out the form below and your free hosting account will be created.</p>
          

<td style="text-align: left;" colspan="21">
<font size="-1"><span style="font-family: Helvetica,Arial,sans-serif;">
<form method=post action="http://order.<? echo "$yourdomain" ;?>/register.php">
<table>
<tr><th style="text-align: left;">Username<td><input type=text name=username size=20 value="<?PHP if (isset($_GET['username'])) { echo $_GET['username']; }?>">
<tr><th>&nbsp;<td>&nbsp;
<tr><th style="text-align: left;">Password<td><input type=password name=password size=20>
<tr><th>&nbsp;<td>&nbsp;
<tr><th style="text-align: left;">Email Address<td><input type=text name=email size=20 value="<?PHP if (isset($_GET['email'])) { echo $_GET['email']; }?>">

<tr><th style="text-align: left;">Site Category<td><select size="1" name="website_category">
<option>Choose from Below</option>
<option>Personal</option>
<option>Business</option>
<option>Hobby</option>
<option>Forum</option>
<option>Adult</option>
<option>Dating</option>
<option>Software / Download</option>
</select>
</td>

<tr><th style="text-align: left;"><td>
</td>

<tr><th style="text-align: left;">Site Language<td>
<select size="1" name="website_language">
<option>Choose from Below</option>
<option>English</option>
<option>Non-English</option>
</select>
</td>

<tr><th>&nbsp;<td>&nbsp;
<?PHP 
$id = md5(rand(6000,99999999999999991000));
?>
<input type=hidden name=id value="<?PHP echo $id; ?>">
<tr><th style="text-align: left;">Security Code<td><img width="250px" height="90px" src="http://order.<? echo "$yourdomain" ;?>/image.php?id=<?PHP echo $id; ?>">
<tr><th>&nbsp;<td>&nbsp;
<tr><th style="text-align: left;">Enter Security Code<td><input type=text name=number size=20>
<tr><th>&nbsp;<td>&nbsp;

<tr><th colspan=2><input type=submit value="Register" name=submit>
</table>
</form>		
</span>
<br style="font-family: Helvetica,Arial,sans-serif;">
      </font>
      <br style="font-family: Helvetica,Arial,sans-serif;">
      </span></font>
By signing up for our free hosting, you accept and agree to our <a href="https://ifastnet.com/portal/terms.php">Terms of Service</a>
   <p class="p1">Free hosting accounts are activated instantly, no need to wait for manual approval, you can start building your pages immediately!</p>

</td>

</p>
							<a href="#" class="link2"><span><span>Read More</span></span></a> </article>
						<div class="clear"></div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<!-- aside -->
<aside>
	<div class="container">
		<div class="inside">
			<div class="line-ver1">
				<div class="line-ver2">
					<div class="line-ver3">
						<div class="wrapper line-ver4">
							<ul class="list col-1">
								<li>Account Manager</li>
								<li><a href="#">My Account</a></li>
								<li><a href="#">Account Settings</a></li>
								<li><a href="#">Customer Information</a></li>
								<li><a href="#">Order History</a></li>
							</ul>
							<ul class="list col-2">
								<li>Shopping</li>
								<li><a href="#">Offer Disclaimers</a></li>
								<li><a href="#">Domain Search</a></li>
								<li><a href="#">Gift Cards</a></li>
								<li><a href="#">Mobile</a></li>
							</ul>
							<ul class="list col-3">
								<li>Resources</li>
								<li><a href="#">Webmail</a></li>
								<li><a href="#">WHOIS search</a></li>
								<li><a href="#">ICANN Confirmation</a></li>
								<li><a href="#">Affiliates</a></li>
							</ul>
							<ul class="list col-4">
								<li>Help and Support</li>
								<li><a href="#">Support &amp; Sales</a></li>
								<li><a href="#">Billing Support</a></li>
								<li><a href="#">FAQ’s</a></li>
								<li><a href="#">User’s Guides</a></li>

							</ul>
							<ul class="list col-5">
								<li>About</li>
								<li><a href="#">Security Center</a></li>
								<li><a href="#">Company Info</a></li>
								<li><a href="#">News Center</a></li>
								<li><a href="#">What’s New</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</aside>
<!-- footer -->
<footer>
	<div class="container">
		<div class="inside">
			<a rel="nofollow" href="index.php" class="new_window"><? echo "$yourdomain" ;?></a>
		</div>
	</div>
</footer>
<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>
