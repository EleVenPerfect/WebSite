<!DOCTYPE html>
<html lang="en">
<head>
<title>Contact <? echo "$yourdomain" ;?></title>
<meta name="description" content="Place your description here">
<meta name="keywords" content="put, your, keyword, here">
<meta name="author" content="Templates.com - website templates provider">
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_300.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_400.font.js"></script>
<script type="text/javascript" src="js/Myriad_Pro_600.font.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<!--[if lt IE 7]>
<script type="text/javascript" src="http://info.template-help.com/files/ie6_warning/ie6_script_other.js"></script>
<![endif]-->
<!--[if lt IE 9]>
<script type="text/javascript" src="js/html5.js"></script>
<![endif]-->
</head>
<body id="page6">
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<div class="tail-top1">
<!-- header -->
	<header>
		<div class="container">
			<div class="header-box">
				<div class="left">
					<div class="right">
						<nav>
							<ul>
								<li><a href="index.php">Home</a></li>
								<li><a href="signup.php">Sign up</a></li>
								<li><a href="news.php">News</a></li>
								<li class="current"><a href="contact.php">Contact</a></li>
							</ul>
						</nav>
			<h1><a href="index.php"><span><? echo "$yourdomain" ;?></span> Hosting</a></h1>>
					</div>
				</div>
			</div>
<span class="top-info">24/7 Sales &amp; Support  &nbsp; l  &nbsp; <a href="#">Hot Deals</a> </span>
                        <form action="" id="login-form">
                                <fieldset>
                                        <a href="http://cpanel.<? echo "$yourdomain" ;?>" class="login" onClick="document.getElementById('login-form').submit()"><span><span>Login</span></span></a>
                                        <span class="links"><a href="http://cpanel.<? echo "$yourdomain" ;?>/lostpassword.php">Forgot Password?</a><br/><a href="signup.php">Register</a></span>
                                </fieldset>
                        </form>
		</div>
	</header>
<!-- content -->
	<section id="content"><div class="ic"></div>
		<div class="container">
			<div class="inside">
				<div id="slogan">
					<div class="inside">
						<h2><span>Your Domain Name</span> Helps the World  to Find You</h2><p class="p0">
					  If you have any problems or have the need to contact us to ask a question,  you can use the <span>integrated support system</span> in your control panel to create a support ticket.<br />We will reply to your question as soon as possible.
      
     </p>
					</div>
				</div>
				<ul class="banners wrapper">
					<li><a href="/signup.php">Free  &nbsp; <b>$0.00</b></a></li>
					<li><a href="https://ifastnet.com/portal/sharedhosting.php">Premium  &nbsp; <b>$3.99</b></a></li>
					<li><a href="https://ifastnet.com/portal/vpshosting.php">VPS  &nbsp; <b>$9.99</b></a></li>
					<li><a href="https://ifastnet.com/portal/dedicatedserver.php">Dedicated  &nbsp; <b>$89.99</b></a></li>
				</ul>
				<div class="inside1">
					<div class="wrap">
						<article class="col-1">
							<h2>Postal Address</h2>
							<address>
								<b>Zip Code:</b>50122<br />
								<b>Country:</b>USA<br />
								<b>State:</b>California<br />
								<b>City:</b>San Diego<br />
								<b>Telephone:</b>+354 5xxxxx<br />
								<b>Fax:</b>+354 56xxxxx<br />
								<b>Email:</b><a href="#">smartnet@mail.com</a>
							</address>
							<h5>Contact us</h5>
							<p class="p0">
 For technical support please look at the knowledge base at:<br />
      <a href="http://byet.net/forumdisplay.php?f=28">Knowledge Base</a></p>
   
						</article>
						<article class="col-2">
							<h2>Contact Form</h2>
Add your contact form here such as one from here: www.tectite.com/ or cloudcontactforms.com/
						</article>
						<div class="clear"></div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<!-- aside -->
<aside>
	<div class="container">
		<div class="inside">
			<div class="line-ver1">
				<div class="line-ver2">
					<div class="line-ver3">
						<div class="wrapper line-ver4">
							<ul class="list col-1">
								<li>Account Manager</li>
								<li><a href="#">My Account</a></li>
								<li><a href="#">Account Settings</a></li>
								<li><a href="#">Customer Information</a></li>
								<li><a href="#">Order History</a></li>
							</ul>
							<ul class="list col-2">
								<li>Shopping</li>
								<li><a href="#">Offer Disclaimers</a></li>
								<li><a href="#">Domain Search</a></li>
								<li><a href="#">Gift Cards</a></li>
								<li><a href="#">Mobile</a></li>
							</ul>
							<ul class="list col-3">
								<li>Resources</li>
								<li><a href="#">Webmail</a></li>
								<li><a href="#">WHOIS search</a></li>
								<li><a href="#">ICANN Confirmation</a></li>
								<li><a href="#">Affiliates</a></li>
							</ul>
							<ul class="list col-4">
								<li>Help and Support</li>
								<li><a href="#">Support &amp; Sales</a></li>
								<li><a href="#">Billing Support</a></li>
								<li><a href="#">FAQ’s</a></li>
								<li><a href="#">User’s Guides</a></li>

							</ul>
							<ul class="list col-5">
								<li>About</li>
								<li><a href="#">Security Center</a></li>
								<li><a href="#">Company Info</a></li>
								<li><a href="#">News Center</a></li>
								<li><a href="#">What’s New</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</aside>
<!-- footer -->
<footer>
	<div class="container">
		<div class="inside">
			<a rel="nofollow" href="index.php" class="new_window"><? echo "$yourdomain" ;?></a>
		</div>
	</div>
</footer>
<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>
