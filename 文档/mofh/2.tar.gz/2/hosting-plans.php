<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Hosting Plans</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<meta name="description" content="Hosting Plans page - free hosting website template available at TemplateMonster.com for free download."/>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="layout.css" rel="stylesheet" type="text/css" />
</head>
<body id="page2">
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<div id="main">
<!-- header -->
	<div id="header">
		<div class="row-1">
			<div class="logo"><a href="index.php"><img alt="" src="images/logo.jpg" /></a><strong><? echo "$yourdomain" ;?></strong></div>
			<form action="" id="search-form">
			  	<fieldset>
					Check Domain Name:<br />
					<input type="text" value="" class="text" /><select><option>.com</option></select><input type="submit" value="Start!" class="submit" />
				</fieldset>
			</form>
		</div>
		<div class="row-2">
			<ul class="nav">
				<li><a href="index.php" class="first"><em><b>Home</b></em></a></li>
				<li><a href="hosting-plans.php" class="current"><b>About us</b></a></li>
				<li><a href="signup.php"><b>Signup</b></a></li>
				<li><a href="contacts.php"><b>Contacts</b></a></li>
<li><a href="index.php"><b>Premium Plans</b></a></li>
			        <li><a href="privacy-policy.php" class="last"><b>Privacy policy</b></a></li>
			</ul>
		</div>
		<div class="row-3">
<!-- main-box begin -->
			<div class="main-box">
				<div class="inner">
					<img alt="" src="images/slogan.jpg" />
					<ul>
						<li><a href="#">UNLIMITED space!</a></li>
						<li><a href="#">UNLIMITED bandwidth!</a></li>
						<li><a href="#">UNLIMITED MySQL databases!</a></li>
						<li><a href="#">Softaculous Script Installer   </a></li>
						<li><a href="#">Automatic Self Signed SSL</a></li>
						<li><a href="#">MX Record Entry</a></li>
						<li><a href="#">Cron Jobs</a></li>
					</ul>
					<div class="extra-banner">
						<img alt="" src="images/extra-banner.jpg" />
						<a href="#">Learn More</a>
					</div>
				</div>
			</div>
<!-- main-box end -->
		</div>
	</div>
<!-- content -->
	<div id="content">
		<div class="indent">
			<h2>About us</h2>
			<h3>Reseller Plans</h3>
			<p>We allow you to create your own prices and and plans! Becoming a Reseller is easy just take a look at our demo control panels.</p>
			
      <p>We are specialists in free hosting services using clustered technology powered by a one of the largest hosting orgainisations on the internet. Combined with our high bandwidth, space provisions and excellent sub-domain options, make us the optimal option.<br>

Our network seamlessly spreads the traffic demand across multiple servers simultaneously, which gives your sites superior performance and ensuring they stay online and running quickly at all times!  Our platform has the capability to process hundreds of millions of requests or even billions to service you and more importantly, your viewers and Internet users all over the world.<br></br>

You can sign up here for fast free PHP & MySQL hosting including a free sub domain. A powerful Vista Panel control panel is provided to manage your website, packed with hundreds of great features including Email, FTP add-on domain and much more.<br>

You can find our Automatic Script Installer in the Vistapanel which deploys your website files and folders in seconds!. No need to wait a long time uploading files. <br>We provide free FTP, PHP 5.3, MySQL and our very popular feature: The Automatic Script Installer (Like Fantastico) You can install many popular scripts such as PHPbb2 and PHPbb3, Wordpress, Zen-Cart, osCommerce, MyBB, UseBB, MyLittle Forum, 4images, Coppermine, SMF, Joomla, e107, XOOPS, PHP Wind, CuteNews, Mambo, WikiWig and many more!<br>

Combined with our high bandwidth, space provisions and excellent sub-domain options, make us the optimal option. Our very popular Community Forums has been taken up excellently and active members are growing steadily, hence resulting in a better hosting and friendly experience.<br>

We are using a powerful cluster of webservers that are all interconnected to act as one giant super computer. This technology is years ahead of other hosting companies. Combining the power of lots of server simultaneously creates lightening fast website speeds. Not only is the service extremely fast, it is resistant to common failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run as fast as ever while the working servers deliver your pages.<br></p>

        <li><a href="/signup.php">Sign up for Free Hosting</a></li>
        <li><a href="https://ifastnet.com/portal/sharedhosting.php">Sign up for Premium Hosting</a></li>
        <li><a href="https://ifastnet.com/portal/vpshosting.php">Sign up for a VPS Server</a></li>
		</div>
		<table>
			<thead><tr><td class="cell-1">Plans</td><td class="cell-2">Free hosting</td><td class="cell-3">Premium</td><td class="cell-4">Vps servers</td></tr></thead>
			<tbody>
				<tr><td class="alignleft">Disk Space</td><td>2,xxx MB</td><td>3,xxx MB</td><td>4,xxx MB</td></tr>
				<tr><td class="alignleft">Bandwidth</td><td>0,xxx mb</td><td>6,xxxmb</td><td>10,xxxmb</td><
				<tr><td class="alignleft">Monthly Price</td><td>$</td><td>$</td><td>$</td></tr>
				<tr><td class="alignleft">99.9% uptime</td><td>yes</td><td>yes</td><td>yes</td></tr>
				<tr><td class="alignleft">24/7 support</td><td>yes</td><td>yes</td><td>yes</td></tr>
				<tr><td class="alignleft">Daily backups</td><td>yes</td><td>yes</td><td>yes</td></tr>
				<tr><td class="alignleft">No Contract</td><td>yes</td><td>yes</td><td>yes</td></tr>
				<tr><td class="alignleft">30 day money back guarantee</td><td>yes</td><td>yes</td><td>yes</td></tr>
				<tr><td class="alignleft">Free Setup</td><td>yes</td><td>yes</td><td>yes</td></tr>
				<tr><td class="alignleft last">Order</td><td class="last"><a href="/signup.php">Order</a></td><td class="last"><a href="https://ifastnet.com/portal/sharedhosting.php">Order</a></td><td class="last"><a href="https://ifastnet.com/portal/vpshosting.php">Order</a></td></tr>
			</tbody>
		</table>
	</div>
<!-- footer -->
	<div id="footer">
	   	<ul class="nav">
			<li><a href="index.php">Home</a>|</li>
			<li><a href="hosting-plans.php">Hosting plans</a>|</li>
			<li><a href="signup.php"><b>Signup</b></a></li>
			<li><a href="contacts.php">Contacts</a>|</li>
			<li><a href="privacy-policy.php">Privacy policy</a></li>
		</ul>
		<div class="wrapper">
			<div class="fleft">Copyright (c) 2009 GrandHost Inc.</div>
			<div class="fright">Killer <a rel="nofollow" href="http://www.templatemonster.com/flash-templates.php">Flash Templates</a> from TemplateMonster.</div>
		</div>
	</div>
</div>
</body>
</html>
