<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>sign up</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<meta name="description" content="Testimonials page - free website template from Template Monster is awating for you to download."/>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="layout.css" rel="stylesheet" type="text/css" />
</head>
<body id="page4">
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<div id="main">
<!-- header -->
	<div id="header">
		<div class="row-1">
			<div class="logo"><a href="index.php"><img alt="" src="images/logo.jpg" /></a><strong><? echo "$yourdomain" ;?></strong></div>
<form action="https://ifastnet.com/portal/domainchecker.php" method="post" id="search-form">
                                <fieldset>
                                        Check Domain Name:<br />
                                        <input name="domain" type="text" value="" class="text" /><select><option>.com</option></select><input type="submit" value="Start!" class="submit" />
                                </fieldset>
                        </form>


		</div>
		<div class="row-2">
			<ul class="nav">
				<li><a href="index.php" class="first"><em><b>Home</b></em></a></li>
				<li><a href="hosting-plans.php"><b>About us</b></a></li>
				<li><a href="signup.php" class="current"><b>Signup</b></a></li>
				<li><a href="contacts.php"><b>Contacts</b></a></li>
<li><a href="index.php"><b>Premium Plans</b></a></li>
			        <li><a href="privacy-policy.php"class="last"><b>Privacy policy</b></a></li>

			</ul>
		</div>
		<div class="row-3">
<!-- main-box begin -->
			<div class="main-box">
				<div class="inner">
					<img alt="" src="images/slogan.jpg" />
					<ul>
						<li><a href="#">UNLIMITED space!</a></li>
						<li><a href="#">UNLIMITED bandwidth!</a></li>
						<li><a href="#">UNLIMITED MySQL databases!</a></li>
						<li><a href="#">Softaculous Script Installer   </a></li>
						<li><a href="#">Automatic Self Signed SSL</a></li>
						<li><a href="#">MX Record Entry</a></li>
						<li><a href="#">Cron Jobs</a></li>
					</ul>
					<div class="extra-banner">
						<img alt="" src="images/extra-banner.jpg" />
					</div>
				</div>
			</div>
<!-- main-box end -->
		</div>
	</div>
<!-- content -->
	<div id="content"><div class="ic">Strikingly awesome Flash templates  from TemplateMonster - they really rule!</div>
		<div class="indent">
			<h2>Signup for free hosting</h2>


<p>Free hosting accounts are activated instantly, no need to wait for manual approval, you can start building your pages immediately!</p>

          <div class="clr"></div>

          <p>Fill out the form below and your free hosting account will be created.</p>
          

<td border="1" style="text-align: left;" colspan="21">
<font size="-1"><span style="font-family: Helvetica,Arial,sans-serif;">
<form method=post action="http://order.<? echo "$yourdomain" ;?>/register.php">
<table>
<tr><th style="text-align: left;">Username<td><input type=text name=username size=20 value="<?PHP if (isset($_GET['username'])) { echo $_GET['username']; }?>">
<tr><th>&nbsp;<td>&nbsp;
<tr><th style="text-align: left;">Password<td><input type=password name=password size=20>
<tr><th>&nbsp;<td>&nbsp;
<tr><th style="text-align: left;">Email Address<td><input type=text name=email size=20 value="<?PHP if (isset($_GET['email'])) { echo $_GET['email']; }?>">

<tr><th style="text-align: left;">Site Category<td><select size="1" name="website_category">
<option>Choose from Below</option>
<option>Personal</option>
<option>Business</option>
<option>Hobby</option>
<option>Forum</option>
<option>Adult</option>
<option>Dating</option>
<option>Software / Download</option>
</select>
</td>

<tr><th style="text-align: left;"><td>
</td>

<tr><th style="text-align: left;">Site Language<td>
<select size="1" name="website_language">
<option>Choose from Below</option>
<option>English</option>
<option>Non-English</option>
</select>
</td>

<tr><th>&nbsp;<td>&nbsp;
<?PHP 
$id = md5(rand(6000,99999999999999991000));
?>
<input type=hidden name=id value="<?PHP echo $id; ?>">
<tr><th style="text-align: left;">Security Code<td><img width="250px" height="90px" src="http://order.<? echo "$yourdomain" ;?>/image.php?id=<?PHP echo $id; ?>">
<tr><th>&nbsp;<td>&nbsp;
<tr><th style="text-align: left;">Enter Security Code<td><input type=text name=number size=20>
<tr><th>&nbsp;<td>&nbsp;

<tr><th colspan=2><input type=submit value="Register" name=submit>
</table>
</form>		
</span>
<br style="font-family: Helvetica,Arial,sans-serif;">
      </font>
      <br style="font-family: Helvetica,Arial,sans-serif;">
      </span></font>
By signing up for our free hosting, you accept and agree to our <a href="https://ifastnet.com/portal/terms.php">Terms of Service</a>
</td>




		</div>
	</div>
<!-- footer -->
	<div id="footer">
	   	<ul class="nav">
			<li><a href="index.php">Home</a>|</li>
			<li><a href="hosting-plans.php">Hosting plans</a>|</li>
			<li><a href="signup.php"><b>Signup</b></a></li>
			<li><a href="contacts.php">Contacts</a>|</li>
			<li><a href="privacy-policy.php">Privacy policy</a></li>
		</ul>
		<div class="wrapper">
			<div class="fleft">Copyright (c) 2009 GrandHost Inc.</div>
			<div class="fright">Killer <a rel="nofollow" href="http://www.templatemonster.com/flash-templates.php">Flash Templates</a> from TemplateMonster.</div>
		</div>
	</div>
</div>
</body>
</html>
