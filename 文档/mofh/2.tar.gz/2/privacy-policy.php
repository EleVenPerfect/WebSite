<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Privacy Policy</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<meta name="description" content="Privacy Policy page - free web template from Template Monster."/>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="layout.css" rel="stylesheet" type="text/css" />
</head>
<body id="page6">
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<div id="main">
<!-- header -->
	<div id="header">
		<div class="row-1">
			<div class="logo"><a href="index.php"><img alt="" src="images/logo.jpg" /></a><strong><? echo "$yourdomain" ;?></strong></div>
<form action="https://ifastnet.com/portal/domainchecker.php" method="post" id="search-form">
                                <fieldset>
                                        Check Domain Name:<br />
                                        <input name="domain" type="text" value="" class="text" /><select><option>.com</option></select><input type="submit" value="Start!" class="submit" />
                                </fieldset>
                        </form>

		</div>
		<div class="row-2">
			<ul class="nav">
				<li><a href="index.php"class="first"><em><b>Home</b></em></a></li>
				<li><a href="hosting-plans.php"><b>About us</b></a></li>
				<li><a href="signup.php"><b>Signup</b></a></li>
				<li><a href="contacts.php"><b>Contacts</b></a></li>
<li><a href="index.php"><b>Premium Plans</b></a></li>
				<li><a href="privacy-policy.php" class="last-current"><b>Privacy policy</b></a></li>
			</ul>
		</div>
		<div class="row-3">
<!-- main-box begin -->
			<div class="main-box">
				<div class="inner">
					<img alt="" src="images/slogan.jpg" />
					<ul>
						<li><a href="#">UNLIMITED space!</a></li>
						<li><a href="#">UNLIMITED bandwidth!</a></li>
						<li><a href="#">UNLIMITED MySQL databases!</a></li>
						<li><a href="#">Softaculous Script Installer   </a></li>
						<li><a href="#">Automatic Self Signed SSL</a></li>
						<li><a href="#">MX Record Entry</a></li>
						<li><a href="#">Cron Jobs</a></li>
					</ul>
					<div class="extra-banner">
						<img alt="" src="images/extra-banner.jpg" />
						<a href="#">Learn More</a>
					</div>
				</div>
			</div>
<!-- main-box end -->
		</div>
	</div>
<!-- content -->
	<div id="content"><div class="ic">Strikingly awesome Flash templates  from TemplateMonster - they really rule!</div>
		<div class="indent">
			<h2>Privacy Policy</h2>
<p>
The following discloses our information gathering and dissemination practices for this Web site.  We use your IP address to help diagnose problems with our server, and to administer our Web site. Your IP address is used to help identify you and your ISP and to gather broad demographic information. We use cookies to save your password so you don't have to re-enter it each time you visit our site and for other purposes.  Contact information from the order form is used to send information about our company and promotional material from some of our partners to our customers. The customer's contact information is also used to get in touch with the visitor when necessary and shared with other companies who may want to contact our visitors. Users may opt-out of receiving future mailings.
<br></br>
Demographic and profile data is also collected at our site. We use this data to tailor our visitor's experience at our site, showing them content that we think they might be interested in, and displaying the content according to their preferences. This information is shared with advertisers on an aggregate basis.  We use an outside ad company to display ads on our site. These ads may contain cookies.  While we use cookies in other parts of our Web site, cookies received with banner ads are collected by our ad company, and we do not have access to this information. Some customer data is shared with the advertising companies.
<br></br>
<b>SECURITY</b><br>
This site contains links to other sites. template7demo.0lx.net Web Hosting is not responsible for the privacy practices or the content of such Web sites. Our site uses an order form for customers to request information, products, and services. We collect visitor's contact information, financial information, and demographic information (like their zip code, age, or income level).  This site has security measures in place to protect the loss, misuse and alteration of the information under our control.
<br></br>
<b>ADVERTISING</b><br>
We may use third-party advertising companies to serve ads when you use our service, this may change without prior notification being served. Our third-party advertising company also separately places or recognizes a cookie file on your browser when delivering advertisements to this Site. These companies may use information (not including your name, address, email address or telephone number) about your visits to this and other Web sites, in order to provide adverts about goods and services of interest to you. 
<br></br>
<b>PUBLIC FORUMS</b><br>
This site makes chat rooms, forums, message boards, and news groups available to its users. Any information in these areas becomes public, and you should
exercise caution when deciding to disclose your personal information.
</p>
		</div>
	</div>
<!-- footer -->
	<div id="footer">
	   	<ul class="nav">
			<li><a href="index.php">Home</a>|</li>
			<li><a href="hosting-plans.php">Hosting plans</a>|</li>
			<li><a href="signup.php"><b>Signup</b></a></li>
			<li><a href="contacts.php">Contacts</a>|</li>
			<li><a href="privacy-policy.php">Privacy policy</a></li>
		</ul>
		<div class="wrapper">
			<div class="fleft">Copyright (c) 2009 GrandHost Inc.</div>
			<div class="fright">Killer <a rel="nofollow" href="http://www.templatemonster.com/flash-templates.php">Flash Templates</a> from TemplateMonster.</div>
		</div>
	</div>
</div>
</body>
</html>
