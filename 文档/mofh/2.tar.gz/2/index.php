﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title><? echo "$yourdomain" ;?>web hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="layout.css" rel="stylesheet" type="text/css" />
</head>
<body id="page1">
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<div id="main">
<!-- header -->
	<div id="header">
		<div class="row-1">
			<div class="logo"><a href="index.php"><img alt="" src="images/logo.jpg" /></a><strong><? echo "$yourdomain" ;?></strong></div>
			<form action="https://ifastnet.com/portal/domainchecker.php" method="post" id="search-form">
			  	<fieldset>
					Check Domain Name:<br />
					<input name="domain" type="text" value="" class="text" /><select><option>.com</option></select><input type="submit" value="Start!" class="submit" />
				</fieldset>
			</form>
		</div>
		<div class="row-2">
			<ul class="nav">
				<li><a href="index.php" class="first-current"><em><b>Home</b></em></a></li>
				<li><a href="hosting-plans.php"><b>About us</b></a></li>
				<li><a href="signup.php"><b>Signup</b></a></li>
				<li><a href="contacts.php"><b>Contacts</b></a></li>
<li><a href="index.php"><b>Premium Plans</b></a></li>
			        <li><a href="privacy-policy.php" class="last"><b>Privacy policy</b></a></li>
			</ul>
		</div>
		<div class="row-3">
<!-- main-box begin -->
			<div class="main-box">
				<div class="inner">
					<img alt="" src="images/slogan.jpg" />
					<ul>
						<li><a href="#">unlimited space!</a></li>
						<li><a href="#">unlimited bandwidth!</a></li>
						<li><a href="#">unlimited databases!</a></li>
						<li><a href="#">Softaculous Script Installer   </a></li>
						<li><a href="#">Automatic Self Signed SSL</a></li>
						<li><a href="#">MX Record Entry</a></li>
						<li><a href="#">Cron Jobs</a></li>
					</ul>
					<div class="extra-banner">
						<img alt="" src="images/extra-banner.jpg" />
						<a href="https://ifastnet.com/portal/sharedhosting.php">Learn More</a>
					</div>
				</div>
			</div>
<!-- main-box end -->
		</div>
	</div>
<!-- content -->
	<div id="content"><div class="ic">Strikingly awesome Flash templates  from TemplateMonster - they really rule!</div>
		<ul class="banners">
			<li><a href="/signup.php"><img alt="" src="images/banner1.jpg" /></a></li>
			<li><a href="https://ifastnet.com/portal/sharedhosting.php"><img alt="" src="images/banner2.jpg" /></a></li>
			<li class="last"><a href="https://ifastnet.com/portal/dedicatedserver.php"><img alt="" src="images/banner3.jpg" /></a></li>
		</ul>
		<div class="indent">
			<div class="wrapper line-ver">
				<div class="col-1">
					<h2>Free Hosting now Offers!</h2>
					<ul class="list1">

<li>1000 MB Disk Space</li>
<li>FTP account and File Manager</li>
<li>Control Panel</li>
<li>MySQL databases &amp; PHP Support</li>
<li>Free tech support</li>
<li>Addon domain, Parked Domains, Sub-Domains</li>
<li>Free Community Access (Forums)</li>
<li>Clustered Servers</li>
<li>Webmail email Accounts</li>
<li>Softaculous</li>
<li>Cron Jobs</li>
<li>SPF Records</li>
<li> Automatic Self Signed SSL</li>
					<li class="last"><a href="#">Learn More</a></li>
					</ul>
				</div>
				<div class="col-2">
					<h2>Transfer Domain - <span>FREE!</span></h2>
					<img class="img-indent fright" alt="" src="images/1page-img1.jpg" />
					<p class="p1">With our company you may transfer the domain from other hosting.</p>
					<p class="p1">In addition to that we will provide a free technical assistance during the transfer process.</p>
					<a href="#">Learn More</a>
				</div>
			</div>
		</div>
<!-- box begin -->
		<div class="box">
			<div class="border-top">
				<div class="border-right">
					<div class="border-left">
						<div class="left-top-corner">
							<div class="right-top-corner">
								<div class="right-bot-corner">
									<div class="left-bot-corner">
										<div class="inner">
											<h2>Our Awards</h2>
											<ul class="awards">
											  	<li><a href="#"><img alt="" src="images/award1.jpg" /></a></li>
												<li><a href="#"><img alt="" src="images/award2.jpg" /></a></li>
												<li><a href="#"><img alt="" src="images/award3.jpg" /></a></li>
												<li><a href="#"><img alt="" src="images/award4.jpg" /></a></li>
												<li><a href="#"><img alt="" src="images/award5.jpg" /></a></li>
												<li class="last"><a href="#"><img alt="" src="images/award6.jpg" /></a></li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<!-- box end -->
	</div>
<!-- footer -->
	<div id="footer">
		<ul class="nav">
			<li><a href="index.php">Home</a>|</li>
			<li><a href="hosting-plans.php">Hosting plans</a>|</li>
			<li><a href="signup.php"><b>Signup</b></a></li>
			<li><a href="contacts.php">Contacts</a>|</li>
			<li><a href="privacy-policy.php">Privacy policy</a></li>
		</ul>
		<div class="wrapper">
			<div class="fleft">Copyright (c) 2014 <? echo "$yourdomain" ;?>.</div>
		</div>
	</div>
</div>
</body>
</html>
