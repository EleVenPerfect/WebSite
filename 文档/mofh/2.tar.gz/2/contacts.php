<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Contacts</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<meta name="description" content="Contacts page - free hosting website template available at TemplateMonster.com for free download."/>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="layout.css" rel="stylesheet" type="text/css" />
</head>
<body id="page5">
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<div id="main">
<div id="main">
<!-- header -->
	<div id="header">
		<div class="row-1">
			<div class="logo"><a href="index.php"><img alt="" src="images/logo.jpg" /></a><strong><? echo "$yourdomain" ;?></strong></div>
<form action="https://ifastnet.com/portal/domainchecker.php" method="post" id="search-form">
                                <fieldset>
                                        Check Domain Name:<br />
                                        <input name="domain" type="text" value="" class="text" /><select><option>.com</option></select><input type="submit" value="Start!" class="submit" />
                                </fieldset>
                        </form>

		</div>
		<div class="row-2">
			<ul class="nav">
				<li><a href="index.php" class="first"><em><b>Home</b></em></a></li>
				<li><a href="hosting-plans.php"><b>About us</b></a></li>
				<li><a href="signup.php"><b>Signup</b></a></li>
				<li><a href="contacts.php" class="current"><b>Contacts</b></a></li>
<li><a href="index.php"><b>Premium Plans</b></a></li>
			        <li><a href="privacy-policy.php"class="last"><b>Privacy policy</b></a></li>

			</ul>
		</div>
		<div class="row-3">
<!-- main-box begin -->
			<div class="main-box">
				<div class="inner">
					<img alt="" src="images/slogan.jpg" />
					<ul>
						<li><a href="#">UNLIMITED space!</a></li>
						<li><a href="#">UNLIMITED bandwidth!</a></li>
						<li><a href="#">UNLIMITED MySQL databases!</a></li>
						<li><a href="#">Softaculous Script Installer   </a></li>
						<li><a href="#">Automatic Self Signed SSL</a></li>
						<li><a href="#">MX Record Entry</a></li>
						<li><a href="#">Cron Jobs</a></li>
					</ul>
					<div class="extra-banner">
						<img alt="" src="images/extra-banner.jpg" />
						<a href="#">Learn More</a>
					</div>
				</div>
			</div>
<!-- main-box end -->
		</div>
	</div>
<!-- content -->
	<div id="content">
		<div class="indent">
			<div class="wrapper line-ver">
				<div class="col-1">
					<h2>Contact Us</h2>

					<dl class="contacts">
						<dt>E-mail:</dt>
						<dd><a href="#">sales@hostgator.com</a><br />
						<a href="#">support@hostgator.com</a></dd>
					</dl>
					<dl class="contacts">
						<dt>Online Chat:</dt>
						<dd><a href="#">AIM:youraimnamehere</a><br />
						<a href="#">YIM:youryimnamehere</a><br />
						<a href="#">ICQ: youricqhere</a></dd>
					</dl>
				</div>
				<div class="col-2">
					<h2>Support</h2>
					<dl>
					<p>We can be reached 24/7 to answer all of your support related needs. You can use the <span>integrated support system</span> in your control panel to create a support ticket.<br />
   </p>

						<dd>Search through our FAQ pages and quickly find answers to your pre-sales, and other common web hosting questions.</dd>
						<dt><a href="http://byet.net/vb">Knowledge Base</a></p>
						<dd>Our forum allows customers to interact with each other, discuss issues and share experiences. Want an unbiased opinion about our services? This is the place to get it!</dd>
					</dl>
				</div>
			</div>
		</div>
	</div>
<!-- footer -->
	<div id="footer">
	   	<ul class="nav">
			<li><a href="index.php">Home</a>|</li>
			<li><a href="hosting-plans.php">Hosting plans</a>|</li>
			<li><a href="signup.php"><b>Signup</b></a></li>
			<li><a href="contacts.php">Contacts</a>|</li>
			<li><a href="privacy-policy.php">Privacy policy</a></li>
		</ul>
		<div class="wrapper">
			<div class="fleft">Copyright (c) 2009 GrandHost Inc.</div>
			<div class="fright">Killer <a rel="nofollow" href="http://www.templatemonster.com/flash-templates.php">Flash Templates</a> from TemplateMonster.</div>
		</div>
   </div>
</div>
</body>
</html>
