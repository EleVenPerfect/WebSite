<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title><? echo "$yourdomain" ;?></title>

<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>

<div id="main_container">

  <div id="header">
<div class="logo">
<h2><? echo "$yourdomain" ;?></h2>
<h3>free and paid hosting services</h3>
</div>
  </div>
  <div class="menu">
    <ul>
    <li><a href="index.php"><b>H</b>omepage</a></li>
    <li><a href="signup.php"><b>S</b>ignup</a></li>
    <li><a href="https://ifastnet.com/portal/"><b>P</b>aid services</a></li>
    <li class="selected"><a href="contact.php">Contact <b>U</b>s</a></li>
    <li><a href="https://ifastnet.com/portal/terms.php"><b>T</b>erms of service</a></li>
    </ul>
  </div>

  <div class="center_content">
    <div class="center_left">
      <div class="title_welcome"><span class="red">FREE</span> Hosting Control Panel</div>
      <div class="welcome_box">
        <p class="welcome"> <span class="orange">We are specialists in free hosting services </span><br />
 using clustered technology powered by a one of the largest hosting organisations on the internet. You can sign up here for fast free PHP & MySQL hosting including a free sub domain. A powerful Vista control panel is packed with hundreds of great features including Email, FTP add-on domain and much more.. </p>
        <a href="/signup.php" class="read_more">sign up</a> </div>

      <div class="features">
        <div class="title">Contact us</div>
 
  <p>If you have any problems or have the need to contact us to ask a question,<br />
      you can use the <span>integrated support system</span> in your control panel to create <br>a support ticket.  We will reply to your question as soon as possible.<br
      For technical support please look at the knowledge base at:<br />
      <a href="http://byet.net/forumdisplay.php?f=28">Knowledge Base</a></p>
      </div>


      <div class="features">

        <div class="title">Latest News</div>
        <div class="news_box">
          <div class="news_icon"></div>
          <div class="news_content"> �We proudly announce the following new features on all free accounts!..<br>
<strong>1. cPanel x3 theme</strong> - The popular and professional x3 theme is now available for all free hosting accounts.<br>
<strong>2. 80 SEO tools</strong> - From keyword checkers to page optimization utilities, this huge selection of completely free tools helps you grow a successful website.<br>
<strong>3. Search Engine Submitter</strong> - All free hosting customers can now submit their websites for free to over 100 search engines from one location in your control panel.  Every free hosting control panel now has the cPanel x3 theme provided as the default theme.. </div>
        </div>
        <div class="news_box">
          <div class="news_icon"></div>
          <div class="news_content"> �For any web site from a small business brochure, pictures of a tropical holiday, to powerful dynamic websites for a gaming clan etc, Byet Internet has the right services for you and at the right price... $0.00! </div>
        </div>
      </div>
    </div>



<div class="center_right">
      <div class="software_box"><img src="images/3dbox.gif" alt="" />
</div>


<div class="text_box">
You can sign up here for fast free PHP & MySQL hosting including a free sub domain.<br></br>When your account is activated a powerful Vista Panel control panel is provided to manage your website, packed with hundreds of great features including Email, FTP add-on domains and more.<br><b>Log in here:</b>.

<a href="http://cpanel.<? echo "$yourdomain" ;?>/"><input type="image" src="images/login.gif" class="login" /></a>
</div>



      <div class="testimonials">
        <div class="title">Cluster servers</div>
        <div class="text_box">
          <p class="testimonial"> We are using a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of other hosting companies. Combining the power of lots of server simultaneously creates lightening fast website speeds.
           </p>
        </div>
      </div>
    </div>
    <div class="clear"></div>
  </div>

  <div id="footer">
<? include ("footer.php"); ?>

</div>

<!-- end of main_container -->
</body>
</html>
