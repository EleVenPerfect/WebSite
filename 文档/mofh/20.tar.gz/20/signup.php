<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title><? echo "$yourdomain" ;?></title>

<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>

<div id="main_container">

  <div id="header">
<div class="logo">
<h2><? echo "$yourdomain" ;?></h2>
<h3>free and paid hosting services</h3>
</div>
  </div>
  <div class="menu">
    <ul>
    <li><a href="index.php"><b>H</b>omepage</a></li>
    <li class="selected"><a href="signup.php"><b>S</b>ignup</a></li>
    <li><a href="https://ifastnet.com/portal/"><b>P</b>aid services</a></li>
    <li><a href="contact.php">Contact <b>U</b>s</a></li>
    <li><a href="https://ifastnet.com/portal/terms.php"><b>T</b>erms of service</a></li>
    </ul>
  </div>


  <div class="center_content">
    <div class="center_left">
      <div class="title_welcome"><span class="red">FREE</span> Hosting Control Panel</div>
<div>
<h2>Sign Up For Free Hosting</h2>
<p>
Fill out the form below and your free hosting account will be created.
<br>

</p>
<td style="text-align: left;" colspan="21">
<font size="-1"><span style="font-family: Helvetica,Arial,sans-serif;">
<form method=post action="http://order.<? echo "$yourdomain" ;?>/register.php">
<table>
<tr><th style="text-align: left;">Username<td><input type=text name=username size=20 value="<?PHP if (isset($_GET['username'])) { echo $_GET['username']; }?>">
<tr><th>&nbsp;<td>&nbsp;
<tr><th style="text-align: left;">Password<td><input type=password name=password size=20>
<tr><th>&nbsp;<td>&nbsp;
<tr><th style="text-align: left;">Email Address<td><input type=text name=email size=20 value="<?PHP if (isset($_GET['email'])) { echo $_GET['email']; }?>">

<tr><th style="text-align: left;">Site Category<td><select size="1" name="website_category">
<option>Choose from Below</option>
<option>Personal</option>
<option>Business</option>
<option>Hobby</option>
<option>Forum</option>
<option>Adult</option>
<option>Dating</option>
<option>Software / Download</option>
</select>
</td>

<tr><th style="text-align: left;"><td>
</td>

<tr><th style="text-align: left;">Site Language<td>
<select size="1" name="website_language">
<option>Choose from Below</option>
<option>English</option>
<option>Non-English</option>
</select>
</td>

<tr><th>&nbsp;<td>&nbsp;
<?PHP 
$id = md5(rand(6000,99999999999999991000));
?>
<input type=hidden name=id value="<?PHP echo $id; ?>">
<tr><th style="text-align: left;">Security Code<td><img width="250px" height="90px" src="http://order.<? echo "$yourdomain" ;?>/image.php?id=<?PHP echo $id; ?>">
<tr><th>&nbsp;<td>&nbsp;
<tr><th style="text-align: left;">Enter Security Code<td><input type=text name=number size=20>
<tr><th>&nbsp;<td>&nbsp;

<tr><th colspan=2><input type=submit value="Register" name=submit>
</table>
</form>		
</span>
<br style="font-family: Helvetica,Arial,sans-serif;"
      </font>
      <br style="font-family: Helvetica,Arial,sans-serif;">
      </span></font>
By signing up for our free hosting, you accept and agree to our <a href="https://ifastnet.com/portal/terms.php">Terms of Service</a>
    </td>
</div>

      <div class="features">
        <div class="title">Main features</div>
        <ul class="list">
          <li><span>1</span><a href="#">Free hosting accounts are activated instantly, no need to wait!.</a></li>
          <li><span>2</span><a href="#">We provide free FTP, PHP 5.3, MySQL</a></li>
          <li><span>3</span><a href="#">You can find our Automatic Script Installer in the Vistapanel.</a></li>
          <li><span>4</span><a href="#">Search Engine Submitter</strong> - For all free hosting customers</a></li>
        </ul>
      </div>


      <div class="features">
        <div class="title">Latest News</div>
        <div class="news_box">
          <div class="news_icon"></div>
          <div class="news_content"> �We proudly announce the following new features on all free accounts!..<br>
<strong>1. cPanel x3 theme</strong> - The popular and professional x3 theme is now available for all free hosting accounts.<br>
<strong>2. 80 SEO tools</strong> - From keyword checkers to page optimization utilities, this huge selection of completely free tools helps you grow a successful website.<br>
<strong>3. Search Engine Submitter</strong> - All free hosting customers can now submit their websites for free to over 100 search engines from one location in your control panel.  Every free hosting control panel now has the cPanel x3 theme provided as the default theme.. </div>
        </div>
        <div class="news_box">
          <div class="news_icon"></div>
          <div class="news_content"> �For any web site from a small business brochure, pictures of a tropical holiday, to powerful dynamic websites for a gaming clan etc, Byet Internet has the right services for you and at the right price... $0.00! </div>
        </div>
      </div>
    </div>



<div class="center_right">
      <div class="software_box"><img src="images/3dbox.gif" alt="" />
</div>


<div class="text_box">
You can sign up here for fast free PHP & MySQL hosting including a free sub domain.<br></br>When your account is activated a powerful Vista Panel control panel is provided to manage your website, packed with hundreds of great features including Email, FTP add-on domains and more.<br><b>Log in here:</b>.

<a href="http://cpanel.<? echo "$yourdomain" ;?>/"><input type="image" src="images/login.gif" class="login" /></a>
</div>



      <div class="testimonials">
        <div class="title">Cluster servers</div>
        <div class="text_box">
          <p class="testimonial"> We are using a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of other hosting companies. Combining the power of lots of server simultaneously creates lightening fast website speeds.
           </p>
        </div>
      </div>
    </div>
    <div class="clear"></div>
  </div>

  <div id="footer">
<? include ("footer.php"); ?>

</div>

<!-- end of main_container -->
</body>
</html>
