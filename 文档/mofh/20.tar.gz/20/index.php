<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title><? echo "$yourdomain" ;?></title>

<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>

<div id="main_container">

  <div id="header">
<div class="logo">
<h2><? echo "$yourdomain" ;?></h2>
<h3>free and paid hosting services</h3>
</div>
  </div>
  <div class="menu">
    <ul>
    <li class="selected"><a href="index.php"><b>H</b>omepage</a></li>
    <li><a href="signup.php"><b>S</b>ignup</a></li>
    <li><a href="https://ifastnet.com/portal/"><b>P</b>aid services</a></li>
    <li><a href="contact.php">Contact <b>U</b>s</a></li>
    <li><a href="https://ifastnet.com/portal/terms.php"><b>T</b>erms of service</a></li>
    </ul>
  </div>


  <div class="center_content">
    <div class="center_left">
      <div class="title_welcome"><span class="red">FREE</span> Hosting Control Panel</div>
      <div class="welcome_box">
        <p class="welcome"> <span class="orange">We are specialists in free hosting services </span><br />
 using clustered technology powered by a one of the largest hosting organisations on the internet. You can sign up here for fast free PHP & MySQL hosting including a free sub domain. A powerful Vista control panel is packed with hundreds of great features including Email, FTP add-on domain and much more.. </p>
        <a href="/signup.php" class="read_more">sign up</a> </div>
      <div class="features">
        <div class="title">Main features</div>
        <ul class="list">
          <li><span>1</span><a href="#">1000 MB Disk Space</a></li>
          <li><span>2</span><a href="#">Addon domain, Parked Domains, Sub-Domains</a></li>
          <li><span>3</span><a href="#">You can find the Automatic Script Installer Softaculous</a></li>
          <li><span>4</span><a href="#">Search Engine Submitter</strong> - For all free hosting customers</a></li></ul><ul>
<li>Free hosting accounts are activated instantly, no need to wait!.</li>
<li>FTP account and File Manager</li>
<li>Control Panel</li>
<li>MySQL databases &amp; PHP Support</li>
<li>Free tech support</li>
<li>Free Community Access (Forums)</li>
<li>Clustered Servers</li>
<li>Webmail email Accounts</li>
<li>Cron Jobs</li>
<li>SPF Records</li>
<li> Automatic Self Signed SSL</li>
        </ul>
      </div>


      <div class="features">
        <div class="title">Latest News</div>
        <div class="news_box">
          <div class="news_icon"></div>
          <div class="news_content"> �We proudly announce the following new features on all free accounts!..<br>
<strong>1. cPanel x3 theme</strong> - The popular and professional x3 theme is now available for all free hosting accounts.<br>
<strong>2. Automatic HTTP/SSL</strong> - We are the only webhost's in the world to offer automatic free SSL/HTTP's encryption on all free hosted domain names.  You can instantly browse any domain on our network on a https:// url.<br>
<strong>3. Softaculous 1 click script installer</strong> - Softaculous is an auto installer for cPanel.
Unlike other auto installers Softaculous is much faster, well designed and it installs all scripts in just ONE STEP. 
</div>
        </div>
        <div class="news_box">
          <div class="news_icon"></div>
          <div class="news_content"> �For any web site from a small business brochure, pictures of a tropical holiday, to powerful dynamic websites for a gaming clan etc, Byet Internet has the right services for you and at the right price... $0.00! </div>
        </div>
      </div>
    </div>



<div class="center_right">
      <div class="software_box"><img src="images/3dbox.gif" alt="" />
</div>


<div class="text_box">
You can sign up here for fast free PHP & MySQL hosting including a free sub domain.<br></br>When your account is activated a powerful Vista Panel control panel is provided to manage your website, packed with hundreds of great features including Email, FTP add-on domains and more.<br><b>Log in here:</b>.

<a href="http://cpanel.<? echo "$yourdomain" ;?>/"><input type="image" src="images/login.gif" class="login" /></a>
</div>



      <div class="testimonials">
        <div class="title">Cluster servers</div>
        <div class="text_box">
          <p class="testimonial"> We are using a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of other hosting companies. Combining the power of lots of server simultaneously creates lightening fast website speeds.
           </p>
        </div>
      </div>
    </div>
    <div class="clear"></div>
  </div>

  <div id="footer">
<? include ("footer.php"); ?>

</div>

<!-- end of main_container -->
</body>
</html>
