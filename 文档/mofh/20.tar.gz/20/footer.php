    <div class="left_footer">
<a href="index.php"><b>H</b>omepage</a>
<a href="signup.php"><b>S</b>ignup</a>
<a href="https://ifastnet.com/portal/"><b>P</b>aid services</a>
<a href="contact.php">Contact <b>U</b>s</a>
<a href="https://ifastnet.com/portal/terms.php"><b>T</b>erms of service</a>

</div>
