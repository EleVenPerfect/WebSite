<div class="logo">
<h2><? echo "$yourdomain" ;?></h2>
<h3>free and paid hosting servces</h3>
</div>
  </div>
  <div class="menu">
    <ul>
    <li class="selected"><a href="index.php"><b>H</b>omepage</a></li>
    <li><a href="signup.php"><b>S</b>ignup</a></li>
    <li><a href="https://ifastnet.com/portal/"><b>P</b>aid services</a></li>
    <li><a href="contact.php">Contact <b>U</b>s</a></li>
    <li><a href="https://ifastnet.com/portal/terms.php"><b>T</b>erms of service</a></li>
    </ul>
