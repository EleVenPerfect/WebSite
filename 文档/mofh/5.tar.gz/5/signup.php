<?PHP
// This is used to geneate a unique number for catchpa 
$id = md5(rand(6000,99999999999999991000));
?>
<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html>
<html>
<head>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
	<meta charset="utf-8">
	<meta name="viewport" content="initial-scale=1 width=device-width">
	<title>Free Hosting Sign Up</title>
	<meta name="description" content="Professional Free Hosting">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/reset.css">
	<link rel="stylesheet" href="css/style.css">
	<!-- The Famous html Shiv or Shim -->
	<!--[if lt IE 9]>
        <script src="js/html5shiv.js"></script>
    <![endif]-->
</head>
<body>
	<header>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<nav class="navbar navbar-default">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle Navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a href="index.php" class="navbar-brand"><?echo $yourdomain;?></a>
						</div>
							<? include ('navigation.php'); ?>
					</nav>
				</div>
			</div>
		</div>
	</header>
	<div class="intro-mini">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h1>Thank you!</h1>
					<h3>That was a good decision! Thank you for trusting us!</h3>
				</div>
			</div>
		</div>
	</div>
	</div>
	<div class="services">
		<div class="container">
				<form class="signupform" method=post action="http://order.<?echo $yourdomain;?>/register2.php">
					<table>
						<tr><th>Username<td><input class="signupipt" type=text name=username size=30 value=""  maxlength="16" onkeyup="return ismaxlength(this)"><td>
						<tr><th>Password<td><input class="signupipt" type=password name=password size=30 maxlength="8" onkeyup="return ismaxlength(this)"><td>
						<tr><th>Email Address<td><input class="signupipt" type=text name=email size=30 value=""><td>
						                                 </td>
						<tr><th>Site Category<td><select  class="signupiptsl" size="1" name="website_category">
						<option>Personal</option>
						<option>Business</option>
						<option>Hobby</option>
						<option>Forum</option>
						<option>Adult</option>
						<option>Dating</option>
						<option>Software / Download</option>
						</select>
						</td>
						<tr><th>Site Language<td>
						<select  class="signupiptsl"size="1" name="website_language">
						<option>English</option>
						<option>Non-English</option>
						</select>
						</td>
						<input type="hidden" name="id" value="<?PHP echo $id; ?>">
						<tr><th>Security Code<td><div class="captcha"><img width=200px; height=90px; src="http://order.<? echo "$yourdomain" ;?>/image.php?id=<?PHP echo $id; ?>"></div><td>
						<tr><th>Enter Security Code<td><input class="signupipt" type=text name=number size=30><td>
						<tr><th colspan=2><input type=submit class="signupbtn" value="Register" name=submit><td>
					</table>
				</form>
		</div>
	</div>
	<footer>
		<div class="container">
			<div class="row">
				<div class="latest-col col-md-4">
					<h3>Our Services</h3>
					<ul>
						<li class="clearfix">
							<a href="free-hosting.php">Free Hosting</a>
						</li>
						<li class="clearfix">
							<a href="premium-hosting.php">Premium Hosting</a>
						</li>
						<li  class="clearfix">
							<a href="https://ifastnet.com/portal/vpshosting.php">VPS Hosting</a>
						</li>
						<li class="clearfix">
							<a href="https://ifastnet.com/portal/dedicatedserver.php">Dedicated Servers</a>
						</li>
						<li  class="clearfix">
							<a href="domains.php">Domain Name Registration</a>
						</li>
					</ul>
				</div>
				<div class="latest-col col-md-8">
					<h3>Why us</h3>
					<ul>
    					<p>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run normally using the working servers!</p>    
					</ul>
				</div>
			</div>
		</div>
	</footer>
	<div class="copy">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<a>Terms of service</a> | <a>Privacy policy</a> | © HostName, Powered By <a href="https://ifastnet.com">iFastNet</a>.
				</div>
			</div>
		</div>
	</div>
	<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script> 
	<script src="js/bootstrap.min.js"></script>
</body>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
</html>
