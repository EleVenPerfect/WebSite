<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
<head>
<title>Free Hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="main">
  <div class="header_resize_index">
    <div class="header">
      <div class="logo"><a href="index.php"><?echo $yourdomain;?></a></div>
      <div class="social">
      <a href="#"><img class="social-roll" src="images/social/facebook.png"></a>
      <a href="#"><img class="social-roll" src="images/social/googleplus.png"></a>
      <a href="#"><img class="social-roll" src="images/social/twitter.png"></a>
      <a href="#"><img class="social-roll" src="images/social/rss.png"></a>
      </div>
      <div class="spacer"></div>
      <div class="menu_resize">
        <? include ('navigation.php'); ?>
        <div class="spacer"></div>
      </div>
      <div class="spacer"></div>
    </div>
    <div class="slider_resize2">
    <div class="head2">
		<h2>Free hosting features</h2>
		<p>We provide completely free hosting, includes a powerful control panel, FTP, site builder. automatic script installer and many more features...</p>
	</div>
    <img src="images/head-2.png">
      <div class="spacer"></div>
    </div>
  </div>
  <div class="spacer"></div>
  <div class="body">
    <div class="body_resize">
    <div class="htp"><h3>This is what we offer</h3></div>
	<table class="features-table">

			<tr>

				<td>Monthly Bandwidth</td>

				<td align="center"><span>100 GB</span></td>

			</tr>

			<tr>

				<td>Web Disk Space</td>

				<td align="center"><span>10 GB</span></td>

			</tr>

			<tr>

				<td>Price</td>

				<td align="center"><span>$0.00 /Month</span></td>

			</tr>

			<tr>

				<td>Addon Domains</td>

				<td align="center">10</td>

			</tr>

			<tr>

				<td>Parked Domains</td>

				<td align="center">10</td>

			</tr>

			<tr>

				<td>Sub Domains</td>

				<td align="center">10</td>

			</tr>

			<tr>

				<td>PHP Sendmail</td>

				<td align="center">Limited, for activation emails only</td>

			</tr>

			<tr>

				<td>MySQL Databases</td>

				<td align="center">10</td>

			</tr>

			<tr>

				<td>FTP Accounts</td>

				<td align="center">1</td>

			</tr>

			<tr>

				<td>Free Domain</td>

				<td align="center">yourdomain.<?echo $yourdomain;?></td>

			</tr>

			<tr>

				<td>SiteBuilder</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Site Statistics</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Automatic Softaculous Script Installer</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Custom Error Pages</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Cron Jobs</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>PHP Flags Manager</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Online Browser File Manager</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>IP Address Deny</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>10 MB Max File Size</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Custom CNAME Records</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Unmetered MySQL space</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td><h4>SCRIPTING FEATURES</h4></td>

				<td align="center"></td>

			</tr>

			<tr>

				<td>PHP</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>MySQL</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>PhpMyAdmin</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

                                <td><h4>EMAIL FEATURES</h4></td>

                                <td align="center"></td>

                        </tr>

                        <tr>

                                <td>Webmail</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>

                        <tr>

                                <td>Email Accounts (you@yourdomain.com)</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>

                        <tr>

                                <td>Email Forwarders</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>

                        <tr>

                                <td>MX Record Entry</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>

                        <tr>

                                <td>SPF Records</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>



				<td><h4>ECOMMERCE FEATURES</h4></td>

				<td align="center"></td>

			</tr>

			<tr>

				<td>PHP cart scripts install ability</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Password Protected Folders</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Bandwidth</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td><h4>SECURITY</h4></td>

				<td align="center"></td>

			</tr>

                        <tr>

                                <td>Automatic Self Signed SSL (https://)</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>

                        <tr>

                                <td>Install your own SSL certificate</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>

                        <tr>

                                <td>1-Click Cloudflare Enabler</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>





			<tr>

				<td>24/7 Monitoring</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Firewall Protection</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>UPS Power Back-up/Back-up</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Generator</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>			

			<tr>

				<td>Hotlink Protection</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td><h4>OUR TECHNOLOGY</h4></td>

				<td align="center"></td>

			</tr>

			<tr>

				<td>Cisco Powered Network</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Linux Clustered Server Network</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Intel Processors</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Apache Web Servers</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

		</table>
		<div class="fjholder">
		<a href="signup.php" class="features-join" >Join us now!</a>
		</div>
      <hr />
      <div class="bloga">
        <h2>Website Builder!</h2>
        <img src="images/sv-4.jpg" />
        <p> We offer an easy-to-use drag & drop free website builder tool that will help you create professional looking websites! </p>
	  </div>
      <div class="bloga">
        <h2>Softaculous Script installer!</h2>
        <img src="images/sv-5.jpg" />
        <p> It takes time & knowledge to install a forum, blog or an online store, not with our free One-click Softaculous script installer! </p>
	  </div>
      <div class="bloga">
        <h2>SEO Tools!</h2>
        <img src="images/sv-6.jpg" />
        <p> We have free SEO tools to submit and help your websites get higher ranking in the search engines! </p>
	  </div>
      <div class="spacer"></div>
      <hr />
      <img class="ifastnet" src="images/line.jpg" /> 
      <div class="spacer"></div>
    </div>
  </div>
  <div class="body2">
    <div class="body_resize">
      <div class="foot">
      	<div class="fleft">
        <h3>Whys choose us?</h3>
        <p><span>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers.</span></p>
      	</div>
      	<div class="fright">
      	<a class="reflected"><?echo $yourdomain;?></a>
      	</div>
      </div>    
      <div class="spacer"></div>
    </div>
  </div>
  <div class="spacer"></div>
  <div class="footer">
    <div class="footer_resize">
      <p class="rightt"><a href="#">Terms of service</a> | <a href="#">Privacy Policy</a> | © <?echo $yourdomain;?>, Powered By <a href="https://ifastnet.com">iFastNet</a>.</p>
      <div class="spacer"></div>
    </div>
  </div>
</div>
</body>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
</html>
