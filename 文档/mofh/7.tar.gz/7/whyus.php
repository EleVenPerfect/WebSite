<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
<head>
<title>Why Us?</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="main">
  <div class="header_resize_index">
    <div class="header">
      <div class="logo"><a href="index.php"><?echo $yourdomain;?></a></div>
      <div class="social">
      <a href="#"><img class="social-roll" src="images/social/facebook.png"></a>
      <a href="#"><img class="social-roll" src="images/social/googleplus.png"></a>
      <a href="#"><img class="social-roll" src="images/social/twitter.png"></a>
      <a href="#"><img class="social-roll" src="images/social/rss.png"></a>
      </div>
      <div class="spacer"></div>
      <div class="menu_resize">
        <? include ('navigation.php'); ?>
        <div class="spacer"></div>
      </div>
      <div class="spacer"></div>
    </div>
    <div class="slider_resize2">
    <div class="head2">
		<h2>Why Us</h2>
			<p>We no that it's hard to find a good free hosting provider. Here are some things you must know before making your decision!</p>
	</div>
    <img src="images/head-6.png">
      <div class="spacer"></div>
    </div>
  </div>
  <div class="spacer"></div>
  <div class="body">
    <div class="body_resize">
      <h2>The top 7 reasons</h2>
    <div id="links">
        <ul>
          <li>
          <a>1. Instant activation<img src="images/wu1.png">
            <em>You will get your account up and running within 3 minutes right after you submit your account information.</a></li> 
          <hr />
          <li>
          <a>2. Cloud Hosting<img src="images/wu2.png">
            <em>Our free hosting plan is based on Cloud, which means, our servers are integrated to share all resources providing high resource availability.</a></li> 
          <hr />
          <li>
          <a>3. Security<img src="images/wu3.png">
            <em>100% secure hosting with 24/7 monitoring, firewal & hotlink protection.</a></li> 
          <hr />
          <li>
          <a>4. Complete Solution<img src="images/wu4.png">
            <em>We provide a complete free hosting solution, easy-to-use tools for building, managing and tracking powered by quality technical support!</a></li> 
          <hr />
          <li>
          <a>5. Professional<img src="images/wu5.png">
            <em>You'll have access to VistaPanel, a control panel packed with all the features you'll ever need! Website builder, SEO tools, Script installer...</a></li> 
          <hr />
          <li>
          <a>6. Low-cost upgrades<img src="images/wu6.png">
            <em>After you're website becomes popular, and when you're ready to upgrade, we got the best shared, vps & dedicated plans for the lower prices!</a></li> 
          <hr />
          <li>
          <a>7. Professional Support<img src="images/wu7.png">
            <em>You hate waiting hours and maybe days to get an answer? So do we! That's why we provide 24/7 fast response support service.</a></li> 
        </ul>
        </div>
      <div class="spacer"></div>
      <hr />
      <img class="ifastnet" src="images/line.jpg" /> 
      <div class="spacer"></div>
    </div>
  </div>
  <div class="body2">
    <div class="body_resize">
      <div class="foot">
      	<div class="fleft">
        <h3>Whys choose us?</h3>
        <p><span>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers.</span></p>
      	</div>
      	<div class="fright">
      	<a class="reflected"><?echo $yourdomain;?></a>
      	</div>
      </div>    
      <div class="spacer"></div>
    </div>
  </div>
  <div class="spacer"></div>
  <div class="footer">
    <div class="footer_resize">
      <p class="rightt"><a href="#">Terms of service</a> | <a href="#">Privacy Policy</a> | © <?echo $yourdomain;?>, Powered By <a href="https://ifastnet.com">iFastNet</a>.</p>
      <div class="spacer"></div>
    </div>
  </div>
</div>
</body>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
</html>