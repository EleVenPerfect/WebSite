<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
<head>
<title>Professional Free Hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Exo' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="main">
  <div class="header_resize_index">
    <div class="header">
      <div class="logo"><a href="index.php"><?echo $yourdomain;?></a></div>
      <div class="social">
      <a href="#"><img class="social-roll" src="images/social/facebook.png"></a>
      <a href="#"><img class="social-roll" src="images/social/googleplus.png"></a>
      <a href="#"><img class="social-roll" src="images/social/twitter.png"></a>
      <a href="#"><img class="social-roll" src="images/social/rss.png"></a>
      </div>
      <div class="spacer"></div>
      <div class="menu_resize">
        <? include ('navigation.php'); ?>
        <div class="spacer"></div>
      </div>
      <div class="spacer"></div>
    </div>
    <div class="slider_resize">
    <div class="head">
		<h2>Free Professional Hosting</h2>
		<ul>
			<li>10GB Disk Space</li>
			<li>100GB Bandwidth</li>
			<li>10 Domains Hosting</li>
			<li>10 Email Accounts</li>
			<li>Professional Website Builder</li>
			<li>1-Click Softaculous</li>
			<li>Easy-to-use Control Panel</li>
		</ul>
	</div>
	<div class="join-pos"><a href="signup.php" class="join">Join Us Now</a></div>
    <img src="images/head.png">
      <div class="spacer"></div>
    </div>
  </div>
  <div class="spacer"></div>
  <div class="body">
    <div class="body_resize">
    <h2>Welcome to hosting</h2>
    <p>We are specialists in free hosting services using clustered technology powered by one of the largest hosting organizations on the internet. Sign up here for fast free PHP & MySQL hosting including a free sub domain. A powerful, easy-to-use control panel provided to manage your website, packed with hundreds of great features including website building tools, Email, FTP add-on domain <br>Our hosting platform is the only one in the world to automatically enable SSL HTTPS protection on every domain name.  This means all websites on our servers have https protection for added security and better Search Engine rankings!</p>
    <hr />
      <div class="bloga">
        <h2>Free Hosting</h2>
        <a href="free-hosting.php"><img class="cadre" src="images/sv-1.jpg" /></a>
        <p> We provide quality free hosting powered by one of the largest hosting organizations on the internet! </p>
        <a href="free-hosting.php" class="btn"><span>Learn More</span></a></div>
      <div class="bloga">
        <h2>Premium Hosting</h2>
        <a href="premium-hosting.php"><img class="cadre" src="images/sv-2.jpg" /></a>
        <p> Powerful premium cPanel hosting powered by iFastNet with multiple plans to match your needs! </p>
        <a href="premium-hosting.php" class="btn"><span>Learn More</span></a></div>
      <div class="bloga">
        <h2>Domain Names</h2>
        <a href="domains.php"><img class="cadre" src="images/sv-3.jpg" /></a>
        <p> Register your own premium domain name within few minutes, we support many extensions. </p>
        <a href="domains.php" class="btn"><span>Learn More</span></a></div>
      <div class="spacer"></div>
      <hr />     
    <h2>Domain Registration</h2>
    <p>Enter the domain with the extension (ex: yourname.com) tld you wish to use in the box below and click search to see whether the domain is available for purchase.</p>
		<form class="form-wrapper cf" method="post" action="https://ifastnet.com/portal/domainchecker.php" target="_blank">
	        <input type="text" placeholder="Ex: mydomain.com" name="domain" value="">
	        <button type="submit" id="Submit" value="Lookup">Search</button>
	    </form>  
	    <p class="undfrm">Domain name registration service is powered by iFastNet</p>  
    <hr />
      <img class="ifastnet" src="images/line.jpg" /> 
      <div class="spacer"></div>
    </div>
  </div>
  <div class="body2">
    <div class="body_resize">
      <div class="foot">
      	<div class="fleft">
        <h3>Whys choose us?</h3>
        <p><span>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers.</span></p>
      	</div>
      	<div class="fright">
      	<a class="reflected"><?echo $yourdomain;?></a>
      	</div>
      </div>    
      <div class="spacer"></div>
    </div>
  </div>
  <div class="spacer"></div>
  <div class="footer">
    <div class="footer_resize">
      <p class="rightt"><a href="#">Terms of service</a> | <a href="#">Privacy Policy</a> | © <?echo $yourdomain;?>, Powered By <a href="https://ifastnet.com">iFastNet</a>.</p>
      <div class="spacer"></div>
    </div>
  </div>
</div>
</body>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
</html>