<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
<head>
<title>Premium Hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="main">
  <div class="header_resize_index">
    <div class="header">
      <div class="logo"><a href="index.php"><?echo $yourdomain;?></a></div>
      <div class="social">
      <a href="#"><img class="social-roll" src="images/social/facebook.png"></a>
      <a href="#"><img class="social-roll" src="images/social/googleplus.png"></a>
      <a href="#"><img class="social-roll" src="images/social/twitter.png"></a>
      <a href="#"><img class="social-roll" src="images/social/rss.png"></a>
      </div>
      <div class="spacer"></div>
      <div class="menu_resize">
        <? include ('navigation.php'); ?>
        <div class="spacer"></div>
      </div>
      <div class="spacer"></div>
    </div>
    <div class="slider_resize2">
    <div class="head2">
		<h2>Premium Hosting</h2>
		<p>In partnership with iFastNet, we also provide reliable premium hosting, with no daily hit limits, unlimited disk space, no maximum file size...</p>
	</div>
    <img src="images/head-3.png">
      <div class="spacer"></div>
    </div>
  </div>
  <div class="spacer"></div>
  <div class="body">
    <div class="body_resize">
    <div class="htp"><h3>This is what we offer</h3></div>
<table class="features-table">
			<tr>
				<td>Monthly Bandwidth</td>
				<td align="center"><span>Up to Unlimited</span></td>
			</tr>
			<tr>
				<td>Web Disk Space</td>
				<td align="center"><span>Up to Unlimited</span></td>
			</tr>
			<tr>
				<td>Price</td>
				<td align="center"><span>Starting from $0.99/Month</span></td>
			</tr>
			<tr>
				<td>Addon Domains</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>Parked Domains</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>Sub Domains</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>Email Accounts</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>MySQL Databases</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>FTP Accounts</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>Free Domain</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>SiteBuilder</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Site Statistics</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Softaculous Script Installer</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Custom Error Pages</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Cron Jobs</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>PHP Flags Manager</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>IP Address Deny</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>File Size Limit</td>
				<td align="center">Unlimited</td>
			</tr>
			<tr>
				<td>Custom CNAME Records</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Unmetered MySQL space</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td><h4>SCRIPTING FEATURES</h4></td>
				<td align="center"></td>
			</tr>
			<tr>
				<td>PHP</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>MySQL</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>PhpMyAdmin</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Ruby On Rails</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Custom CRON Jobs</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Full .htaccess Control</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td><h4>ECOMMERCE FEATURES</h4></td>
				<td align="center"></td>
			</tr>
			<tr>
				<td>PHP cart scripts install ability</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Password Protected Folders</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Bandwidth</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td><h4>SECURITY MECHANISM</h4></td>
				<td align="center"></td>
			</tr>
			<tr>
				<td>24/7 Monitoring</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Firewall Protection</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>UPS Power Back-up/Back-up</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Spam Filter Spam Assassin</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>			
			<tr>
				<td>File Backup & Restore</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Generator</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>			
			<tr>
				<td>Hotlink Protection</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td><h4>OUR TECHNOLOGY</h4></td>
				<td align="center"></td>
			</tr>
			<tr>
				<td>Cisco Powered Network</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Linux Clustered Server Network</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Intel Processors</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Apache Web Servers</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Cloud Servers</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>	
			<tr>
				<td><h4>OUR GUARANTEES</h4></td>
				<td align="center"></td>
			</tr>
			<tr>
				<td>5 Day Money Back</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Price Freeze for the next year</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>99.9% Uptime Guarantee</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>No Hidden Charges</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>24/ 7 Technical Support</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr class="tablefoot">
			</tr>			
		</table>
		<div class="fjholder">
		<a href="https://ifastnet.com/portal/sharedhosting.php" class="features-join" >Join us now!</a>
		</div>
      <hr />
      <div class="bloga">
        <h2>Website Builder!</h2>
        <img src="images/sv-4.jpg" />
        <p> An easy-to-use drag & drop free website builder tool that will help you create professional looking websites! </p>
	  </div>
      <div class="bloga">
        <h2>Softaculous Script installer!</h2>
        <img src="images/sv-5.jpg" />
        <p> From Softaculous you'll get free access to over 250 free applications with an automatic update system! </p>
	  </div>
      <div class="bloga">
        <h2>SEO Tools!</h2>
        <img src="images/sv-6.jpg" />
        <p> We have free SEO tools to submit and help your websites get higher ranking in the search engines! </p>
	  </div>
      <div class="spacer"></div>
      <hr />
      <img class="ifastnet" src="images/line.jpg" /> 
      <div class="spacer"></div>
    </div>
  </div>
  <div class="body2">
    <div class="body_resize">
      <div class="foot">
      	<div class="fleft">
        <h3>Whys choose us?</h3>
        <p><span>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers.</span></p>
      	</div>
      	<div class="fright">
      	<a class="reflected"><?echo $yourdomain;?></a>
      	</div>
      </div>    
      <div class="spacer"></div>
    </div>
  </div>
  <div class="spacer"></div>
  <div class="footer">
    <div class="footer_resize">
      <p class="rightt"><a href="#">Terms of service</a> | <a href="#">Privacy Policy</a> | © <?echo $yourdomain;?>, Powered By <a href="https://ifastnet.com">iFastNet</a>.</p>
      <div class="spacer"></div>
    </div>
  </div>
</div>
</body>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
</html>