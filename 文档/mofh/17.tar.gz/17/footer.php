
  <div id="footerbodyPanel">
    <ul>
    <li><a href="contact.php">Contact</a></li>
    <li><a href="https://ifastnet.com/portal/terms.php">Terms</a></li>
    <li><a href="hostingnews.php">News</a></li>
    <li><a href="signup.php">Sign up</a></li>
    <li class="active">Home</a></li>
    </ul>

  </div>


