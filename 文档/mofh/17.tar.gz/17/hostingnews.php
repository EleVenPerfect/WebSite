<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><? echo "$yourdomain" ;?>web hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<div id="topPanel">
<h3><? echo "$yourdomain" ;?></h3>
  <ul>
    <li><a href="contact.php">Contact</a></li>
    <li><a href="https://ifastnet.com/portal/terms.php">Terms</a></li>
    <li class="active">News</a></li>
    <li><a href="signup.php">Sign up</a></li>
    <li><a href="index.php">Home</a></li>
  </ul>
  <a href="index.php"><img src="images/logo.jpg" title="free hosting Services" alt="hosting Services" width="230" height="80" border="0" /></a>

<div id="headerPanelfast">
<? include ("headerpanel.php"); ?>
</div>

<div id="bodyPanel">
  <h2>Free hosting news</h2>
  <p>We proudly announce the following new features on all free hosting accounts!..<br>
<strong>1. cPanel x3 theme</strong> - The popular and professional x3 theme is now available for all free hosting accounts.<br>
<strong>2. 80 SEO tools</strong> - From keyword checkers to page optimization utilities, this huge selection of completely free tools helps you grow a successful website.<br>
<strong>3. Search Engine Submitter</strong> - All free hosting customers can now submit their websites for free to over 100 search engines from one location in your control panel.  Every free hosting control panel now has the cPanel x3 theme provided as the default theme.



</p>
  <p class="dotline"><img src="images/blank.gif" alt="" width="1" height="1" /></p>
  <p class="capstext">free hosting for any website, from a personal to a more powerful dynamic website, <span><? echo "$yourdomain" ;?></span> has the right services for... $0.00!
</p>
  <p class="dotline"><img src="images/blank.gif" alt="" width="1" height="1" /></p>
  <p class="more"><a href="index.php">More</a></p>
  <h3>Testimonials</h3>

  <div id="testimonial">
    <p><span>Free hosting accounts are activated instantly,</span>  no need to wait for manual approval, you can start building your pages immediately!
We are specialists in free hosting services using clustered technology powered by a one of the largest hosting orgainisations on the internet.</p>
    <p class="moretwo"><a href="index.php">More</a></p>
  </div>
</div>
<div id="footerPanel">
<? include ("footer.php"); ?>
</div>
</body>
</html>
