<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><? echo "$yourdomain" ;?>web hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<div id="topPanel">
<h3><? echo "$yourdomain" ;?></h3>
  <ul>
    <li><a href="contact.php">Contact</a></li>
    <li><a href="https://ifastnet.com/portal/terms.php">Terms</a></li>
    <li><a href="hostingnews.php">News</a></li>
    <li class="active">Sign up</a></li>
    <li><a href="index.php">Home</a></li>
  </ul>
  <a href="index.php"><img src="images/logo.jpg" title="free hosting Services" alt="hosting Services" width="230" height="80" border="0" /></a>

<div id="headerPanelfast">
<? include ("headerpanel.php"); ?>
</div>

<div id="bodyPanel">
  <h2>Sign up</h2>

Fill out the form below and your free hosting account will be created. <br>

<? include ("signupform.php"); ?>

  <p class="dotline"><img src="images/blank.gif" alt="" width="1" height="1" /></p>
  <p class="capstext">
By signing up for our free hosting, you accept and agree to our <a href="https://ifastnet.com/portal/terms.php">Terms of Service</a>
</p>
  <p class="dotline"><img src="images/blank.gif" alt="" width="1" height="1" /></p>

</div>
<div id="footerPanel">
<? include ("footer.php"); ?>
</div>
</body>
</html>
