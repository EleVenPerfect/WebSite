<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><? echo "$yourdomain" ;?>web hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<div id="topPanel">
<h3><? echo "$yourdomain" ;?></h3>
  <ul>
    <li class="active">Contact</a></li>
    <li><a href="https://ifastnet.com/portal/terms.php">Terms</a></li>
    <li><a href="hostingnews.php">News</a></li>
    <li><a href="signup.php">Sign up</a></li>
    <li><a href="index.php">Home</a></li>
  </ul>
  <a href="index.php"><img src="images/logo.jpg" title="free hosting Services" alt="hosting Services" width="230" height="80" border="0" /></a>

<div id="headerPanelfast">
<? include ("headerpanel.php"); ?>
</div>

<div id="bodyPanel">
  <h2>Contact Us</h2>
  <p>If you have any problems or have the need to contact us to ask a question,<br />
      you can use the <span>integrated support system</span> in your control panel to create a support ticket.<br />
   
      We will reply to your question as soon as possible.<br />
      For technical support please look at the knowledge base at:<br />
      <a href="http://byet.net/forumdisplay.php?f=28">Knowledge Base</a>
</p>
  <p class="dotline"><img src="images/blank.gif" alt="" width="1" height="1" /></p>
  <p class="capstext">free hosting for any website, from a personal to a more powerful dynamic website, <span><? echo "$yourdomain" ;?></span> has the right services for... $0.00!
</p>
  <p class="dotline"><img src="images/blank.gif" alt="" width="1" height="1" /></p>
  <p class="more"><a href="index.php">More</a></p>
  <h3>Testimonials</h3>

  <div id="testimonial">
    <p><span>Free hosting accounts are activated instantly,</span>  no need to wait for manual approval, you can start building your pages immediately!
We are specialists in free hosting services using clustered technology powered by a one of the largest hosting orgainisations on the internet.</p>
    <p class="moretwo"><a href="index.php">More</a></p>
  </div>
</div>
<div id="footerPanel">
<? include ("footer.php"); ?>
</div>
</body>
</html>
