<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><? echo "$yourdomain" ;?>web hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<div id="topPanel">
<h3><? echo "$yourdomain" ;?></h3>
  <ul>
    <li><a href="contact.php">Contact</a></li>
    <li class="active">Terms</a></li>
    <li><a href="hostingnews.php">News</a></li>
    <li><a href="signup.php">Sign up</a></li>
    <li><a href="index.php">Home</a></li>
  </ul>
  <a href="index.php"><img src="images/logo.jpg" title="free hosting Services" alt="hosting Services" width="230" height="80" border="0" /></a>

<div id="headerPanelfast">
<? include ("headerpanel.php"); ?>
</div>

<div id="bodyPanel">
  <h2>About Us</h2>
  <p>Trial Services is a <span>free, tableless, W3C-compliant</span> web design layout by Template World. This template has been tested and proven compatible with all major browser environments and operating systems. You are free to modify the design to suit your tastes in any way you like. We only ask you to not remove "Design by Template World" and the link http://www.templateworld.com from the footer of the template.</p>
  <p class="dotline"><img src="images/blank.gif" alt="" width="1" height="1" /></p>
  <p class="capstext">If you are interested in seeing more of our free web template designs feel free to visit our website, Template World. We intend to add at least 25 new free templates in the coming month.</p>
  <p class="dotline"><img src="images/blank.gif" alt="" width="1" height="1" /></p>
  <p class="more"><a href="index.php">More</a></p>
  <h3>Testimonials</h3>

  <div id="testimonial">
    <p><span>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</span> Lorem Ipsum has been the.ing essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum</p>
    <p class="moretwo"><a href="index.php">More</a></p>
  </div>
</div>

<div id="footerPanel">
<? include ("footer.php"); ?>
</div>
</body>
</html>
