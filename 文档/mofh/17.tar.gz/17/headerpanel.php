    <h2>paid</h2>
    <p>Click here for premium hosting</p>
    <a href="https://ifastnet.com/portal/sharedhosting.php">&nbsp;</a></div>
  <div id="headerPanelsecond">
    <h2>free</h2>
    <p>Click here for free hosting</p>
    <a href="signup.php">&nbsp;</a></div>
  <div id="headerPanelthird">
    <h2>vps</h2>
    <p>Click here for our vps servers. </p>
    <a href="https://ifastnet.com/portal/vpshosting.php">&nbsp;</a></div>
