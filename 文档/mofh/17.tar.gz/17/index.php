<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><? echo "$yourdomain" ;?>web hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<body>
<div id="topPanel">
<h3><? echo "$yourdomain" ;?></h3>
  <ul>
    <li><a href="contact.php">Contact</a></li>
    <li><a href="https://ifastnet.com/portal/terms.php">Terms</a></li>
    <li><a href="hostingnews.php">News</a></li>
    <li><a href="signup.php">Sign up</a></li>
    <li class="active">Home</a></li>
  </ul>
  <a href="index.php"><img src="images/logo.jpg" title="free hosting Services" alt="hosting Services" width="230" height="80" border="0" /></a>

<div id="headerPanelfast">
<? include ("headerpanel.php"); ?>
</div>

<div id="bodyPanel">
  <h2>Free Hosting</h2>
  <p>Every free hosting control panel now has the <span>cPanel x3 theme</span> provided as the default theme.  This familiar standard theme gives you a more professional experience.  Free hosting is packed with 100's of features such as automatic HTTPS/SSL enabled on every free hosted domain, free webmail, Softaculious Script installer, File manager, MySQL databases and all the features you need to build an awesome website! 
</p>
  <p class="dotline"><img src="images/blank.gif" alt="" width="1" height="1" /></p>
  <p class="capstext">free hosting for any website, from a personal to a more powerful dynamic website, <span><? echo "$yourdomain" ;?></span> has the right services for... $0.00!
</p>
  <p class="dotline"><img src="images/blank.gif" alt="" width="1" height="1" /></p>

<ul>

<li>1000 MB Disk Space</li>
<li>FTP account and File Manager</li>
<li>Control Panel</li>
<li>MySQL databases &amp; PHP Support</li>
<li>Free tech support</li>
<li>Addon domain, Parked Domains, Sub-Domains</li>
<li>Free Community Access (Forums)</li>
<li>Clustered Servers</li>
<li>Webmail email Accounts</li>
<li>Softaculous</li>
<li>Cron Jobs</li>
<li>SPF Records</li>
<li> Automatic Self Signed SSL</li>
</ul>

  <div id="testimonial">  
    <p><span>Free hosting accounts are activated instantly,</span>  no need to wait for manual approval, you can start building your pages immediately!
We are specialists in free hosting services using clustered technology powered by a one of the largest hosting orgainisations on the internet.</p>
    <p class="moretwo"><a href="index.php">More</a></p>
  </div>
</div>
<div id="footerPanel">
<? include ("footer.php"); ?>
</div>
</body>
</html>
