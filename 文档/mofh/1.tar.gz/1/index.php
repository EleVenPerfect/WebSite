<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
<head>
<title>Professional Free Hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="http://fonts.googleapis.com/css?family=Oswald|Open+Sans:400,600" rel="stylesheet" type="text/css">
</head>
<body>
<div class="main">
  <div class="blok_header">
    <div class="header">
      <div class="logo"><a href="index.php"><?echo $yourdomain;?></a></div>
        <? include ('navigation.php'); ?>
      <div class="spacer"></div>
    </div>
    <div class="spacer"></div>
  </div>
  <div class="spacer"></div>
  <div class="header_text_bg">
    <div class="header_text">
      <div class="div">
        <div class="left1">
          <h2>Reliable & Professional<br />
            Free Web Hosting<br /></h2>
          <p><b>Sign up and get benefit of these features & more!</b></p>
          <ul>
            <li><b>10GB Cloud Storage & 100GB Bandwidth</b></li>
            <li><b>Host Up To 10 Websites On Each Account</b></li>
            <li><b>10 MySQL Databases, FTP & Email accounts</b></li>
            <li><b>24/7 Monitoring & Firewall Protection</b></li>
            <li><b>Free Website Builder & Softaculous</b></li>
            <li><b>vPanel Easy-To-Use Control Panel</b></li>
          </ul>
          <div class="spacer"></div><br/ >
          <p><a href="free-hosting.php" class="btn-large">Learn more</a><a href="signup.php" class="btn-large">Sign up now!</a></p>
        </div>
      </div>
      <div class="gallery">
        <div id="slider">
			<img src="images/server.png" alt="Free Hosting"/>
        </div>
      </div>
      <div class="spacer"></div>
    </div>
    <div class="menu_resize">
      <div class="spacer"></div>
    </div>
    <div class="spacer"></div>
  </div>
  <div class="header_panel">
    <div class="header_panel_resize">
      <div class="bloga">
        <h2>Free Hosting</h2>
        <img class="fade" src="images/1.png" alt="Free hosting" />
        <p>We provide quality free hosting powered by one of the largest hosting organizations on the internet!</p>
        <p><a href="free-hosting.php" class="btn-small">Learn more</a></p>
      </div>
      <div class="bloga">
        <h2>Premium Hosting</h2>
        <img class="fade" src="images/2.png" alt="Premium Hosting" />
        <p>Powerful premium cPanel hosting powered by iFastNet with multiple plans to match your needs!</p>
        <p><a href="premium-hosting.php" class="btn-small">Learn more</a></p>
      </div>
      <div class="bloga">
        <h2>Domain Names</h2>
        <img class="fade" src="images/3.png" alt="Domain Names" />
        <p>Register your own premium domain name within few minutes, we support many extensions (.com, .net, .org...).</p>
        <p><a href="domains.php" class="btn-small">Learn more</a></p>
      </div>
    </div>
    <div class="spacer"></div>
  </div>
  <div class="body_resize">
    <div class="body">
  <h2>Welcome to Hosting</h2>
  	<p>We are specialists in free hosting services using clustered technology powered by one of the largest hosting organizations on the internet. Sign up here for fast free PHP & MySQL hosting including a <a href="">free sub domain</a>. A powerful, easy-to-use control panel provided to manage your website, packed with hundreds of great features including website building tools, Email, FTP add-on domain <br>Our hosting platform is the only one in the world to automatically enable SSL HTTPS protection on every domain name.  This means all websites on our servers have https protection for added security and better Search Engine rankings!</p>
  <hr />
    <div class="domainbox">
      <form class="form-wrapper cf" id="searchbox" method="post" action="https://ifastnet.com/portal/domainchecker.php" target="_blank">
              <input type="text" placeholder="Ex: YourName.com" name="domain" value="" id="search">
              <button id="submit" type="submit">Search</button>
      </form>
    </div>
    <div class="spacer"></div>
  </div>      
</div>
<div class="foot">
<div class="foot_resize">
	<h2>Whys us?</h2>
	<p>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run normally using the working servers!</p>
  </div>
</div>
<div class="footer">
  <div class="footer_resize">
    <ul>
      <li><a href="#">Terms of service</a></li>
      <li><a href="#">Privacy Policy</a></li>
      <li><a href="whyus.php">Why Us</a></li>
      <li><a href="support.php">Support</a></li>
      <li><a href="http://cpanel.<? echo "$yourdomain" ;?>">Login to cPanel</a></li>
    </ul>
      <div class="social-popout"><a href="#" ><img src="images/rss.png" /></a></div>  
      <div class="social-popout"><a href="#"><img src="images/youtube.png" /></a></div>  
      <div class="social-popout"><a href="#"><img src="images/twitter.png" /></a></div>
      <div class="social-popout"><a href="#"><img src="images/googleplus.png" /></a></div>
      <div class="social-popout"><a href="#"><img src="images/facebook.png" /></a></div>  
     <p>© <?echo $yourdomain;?>, Powered By <a href="https://ifastnet.com">iFastNet</a>.</p>
    <div class="spacer"></div>
  </div>
</div>
</body>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
</html>
