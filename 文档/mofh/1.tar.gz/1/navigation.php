      <div class="menu">
        <ul>
          <li class="1"><a href="index.php" class="yellow">Home</a></li>
          <li class="2"><a href="free-hosting.php" class="green">Free Hosting</a></li>
          <li class="3"><a href="premium-hosting.php" class="red">Premium Hosting</a></li>
          <li class="4"><a href="domains.php" class="blue">Domain Names</a></li>
          <li class="5"><a href="whyus.php" class="purple">Why Us</a></li>
          <li class="6"><a href="support.php" class="grey">Support</a></li>
        </ul>
      </div>