<?PHP
// This is used to geneate a unique number for catchpa 
$id = md5(rand(6000,99999999999999991000));
?>
<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
<head>
<title>Free Hosting Sign Up</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="http://fonts.googleapis.com/css?family=Oswald|Open+Sans:400,600" rel="stylesheet" type="text/css">
</head>
<body>
<div class="main">
  <div class="blok_header">
    <div class="header">
      <div class="logo"><a href="index.php"><?echo $yourdomain;?></a></div>
		<? include ('navigation.php'); ?>
      <div class="spacer"></div>
    </div>
    <div class="spacer"></div>
  </div>
  <div class="spacer"></div>
  <div class="header_text_bg2">
    <div class="header_text2">
    <img src="images/server2.png" alt="Free hosting" />
    <h2>Thank you!</h2>
      <p>That was a good decision! Thank you for trusting us!</p>
      <div class="spacer"></div>
    </div>
    <div class="menu_resize">
      <div class="spacer"></div>
    </div>
    <div class="spacer"></div>
  </div>
  <div class="body_resize">
    <div class="body">
	<h2>Please fill out the form below</h2>
			<div class="body-left">
		<form class="signup" method=post action="http://order.<?echo $yourdomain;?>/register2.php">
			<table>
				<tr><th>Username<td><input class="signupipt" type=text name=username size=30 value=""  maxlength="16" onkeyup="return ismaxlength(this)"><td>
				<tr><th>Password<td><input class="signupipt" type=password name=password size=30 maxlength="8" onkeyup="return ismaxlength(this)"><td>
				<tr><th>Email Address<td><input class="signupipt" type=text name=email size=30 value=""><td>
				<tr><th style="text-align: left;">Auto-Install Script<td>
				<select class="signupiptsl" size="1" name="script">
				                                    <optgroup label="No script">
				                                       <option value="" selected="selected">Do not install a script</option>
				                                    </optgroup>
				                                    <optgroup label="Blog / CMS">
				                                       <option value="wordpress">WordPress Blog</option>
				                                       <option value="joomla">Joomla! CMS</option>
				                                       <option value="drupal">Drupal CMS</option>
				                                       <option value="bigace">BigAce CMS</option>
				                                       <option value="nucleus">Nucleus CMS</option>
				                                       <option value="typo3">Typo3 CMS</option>
				                                       <option value="b2evolution">B2Evolution Blog & CMS</option>
				                                       <option value="geeklog">GeekLog CMS</option>
				                                       <option value="kajona">Kajona CMS</option>
				                                       <option value="concrete5">Concrete5 CMS</option>
				                                       <option value="pivot">Pivot Blog & CMS</option>
				                                       <option value="textpattern">TextPattern CMS</option>
				                                       <option value="tikiwikigroup">Tiki Wiki CMS Groupware</option>
				                                       <option value="modxrevo">MODX Revolution CMS</option>
				                                       <option value="pligg">Pligg CMS</option>
				                                    </optgroup>
				                                    <optgroup label="Forum">
				                                       <option value="phpbb">phpBB Forum</option>
				                                       <option value="mybb">MyBB Forum</option>
				                                       <option value="vanilla">Vanilla Forum</option>
				                                    </optgroup>
				                                    <optgroup label="E-Commerce">
				                                       <option value="opencart">OpenCart E-commerce Shop</option>
				                                       <option value="oscommerce">OsCommerce E-commerce Shop</option>
				                                       <option value="zencart">ZebCart E-commerce Shop</option>
				                                       <option value="hhgmultistore">HHG MultiStore E-commerce Shop</option>
				                                       <option value="cubecart">CubeCard E-commerce Shop</option>
				                                    </optgroup>
				                                    <optgroup label="Others">
				                                        <option value="webauction">Web Auction</option>
				                                        <option value="faqmaster">FAQ Master</option>
				                                    </optgroup>
				                                 </select></td>
				<tr><th>Site Category<td><select  class="signupiptsl" size="1" name="website_category">
				<option>Personal</option>
				<option>Business</option>
				<option>Hobby</option>
				<option>Forum</option>
				<option>Adult</option>
				<option>Dating</option>
				<option>Software / Download</option>
				</select>
				</td>
				<tr><th>Site Language<td>
				<select  class="signupiptsl"size="1" name="website_language">
				<option>English</option>
				<option>Non-English</option>
				</select>
				</td>
				<input type="hidden" name="id" value="<?PHP echo $id; ?>">
				<tr><th>Security Code<td><div class="captcha"><img width=200px; height=90px; src="http://order.<? echo "$yourdomain" ;?>/image.php?id=<?PHP echo $id; ?>"></div><td>
				<tr><th>Enter Security Code<td><input class="signupipt" type=text name=number size=30><td>
				<tr><th colspan=2><input type=submit class="signupbtn" value="Register" name=submit><td>
			</table>
		</form>
	</div>
      <div class="body-right">
        <h2>Remember</h2>
        <p>You may not find the email confirmation, so please check your Spam inbox.</p>
		<h2>To use your own domain</h2>
        <p>If you want to use your own domain name from third parties (free or premium), please remember to set your domain nameservers to ours:<br /><span>ns1.<?echo $yourdomain;?></span><br /><span>ns2.<?echo $yourdomain;?></span></p>
      </div>
    <div class="spacer"></div>
  </div>      
</div>
<div class="foot">
<div class="foot_resize">
	<h2>Whys us?</h2>
	<p>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run normally using the working servers!</p>
    </div>
</div>
<div class="footer">
  <div class="footer_resize">
    <ul> 
      <li><a href="#">Terms of service</a></li>
      <li><a href="#">Privacy Policy</a></li>
      <li><a href="whyus.php">Why Us</a></li>
      <li><a href="support.php">Support</a></li>
      <li><a href="http://cpanel.<? echo "$yourdomain" ;?>">Login to cPanel</a></li>
    </ul>
      <div class="social-popout"><a href="#" ><img src="images/rss.png" /></a></div>  
      <div class="social-popout"><a href="#"><img src="images/youtube.png" /></a></div>  
      <div class="social-popout"><a href="#"><img src="images/twitter.png" /></a></div>
      <div class="social-popout"><a href="#"><img src="images/googleplus.png" /></a></div>
      <div class="social-popout"><a href="#"><img src="images/facebook.png" /></a></div>  
     <p>© <?echo $yourdomain;?>, Powered By <a href="https://ifastnet.com">iFastNet</a>.</p>
    <div class="spacer"></div>
  </div>
</div>
</body>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
</html>
