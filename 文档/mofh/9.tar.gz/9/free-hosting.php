<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- UltraSet Template designed by iFastNet exclusively for MyOwnFreeHost users | Please respect our terms of use -->
<head>
<title>Free Hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,400,300,600,700' rel='stylesheet' type='text/css'>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="js/go-top.js"></script>
</head>
<body>
<div id="top">
<div class="main">
  <div class="header">
    <div class="header-holder">
         <div class="header-login"><a href="signup.php">Sign up</a> | <a href="http://cpanel.<? echo "$yourdomain" ;?>">Login</a></div>
    <div class="ground"></div>
   <div class="header-holder-in">
   	<div class="logo"><a href="index.php"><?echo $yourdomain;?></a></div>
      <div style="float:right;">
        <? include ('navigation.php'); ?>
        </div>
        <div class="ground"></div>
      </div>
      <div class="head2">
      <div class="text">
      <h2>Free hosting features</h2>
      <p>We provide completely free hosting, includes a powerful control panel, FTP, site builder. automatic script installer and many more features...</p>
	  </div>
      </div>
      <div class="ground"></div>
		</div>
  	  </div>
    <div class="body">
    <div class="body-holder">
    <div class="body-large">
		<h2>This is what we offer</h2>
			<div class="body-left">
	<table class="features-table">

			<tr>

				<td>Monthly Bandwidth</td>

				<td align="center"><span>100 GB</span></td>

			</tr>

			<tr>

				<td>Web Disk Space</td>

				<td align="center"><span>10 GB</span></td>

			</tr>

			<tr>

				<td>Price</td>

				<td align="center"><span>$0.00 /Month</span></td>

			</tr>

			<tr>

				<td>Addon Domains</td>

				<td align="center">10</td>

			</tr>

			<tr>

				<td>Parked Domains</td>

				<td align="center">10</td>

			</tr>

			<tr>

				<td>Sub Domains</td>

				<td align="center">10</td>

			</tr>

			<tr>

				<td>PHP Sendmail</td>

				<td align="center">Limited, for activation emails only</td>

			</tr>

			<tr>

				<td>MySQL Databases</td>

				<td align="center">10</td>

			</tr>

			<tr>

				<td>FTP Accounts</td>

				<td align="center">1</td>

			</tr>

			<tr>

				<td>Free Domain</td>

				<td align="center">yourdomain.<?echo $yourdomain;?></td>

			</tr>

			<tr>

				<td>SiteBuilder</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Site Statistics</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Automatic Softaculous Script Installer</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Custom Error Pages</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Cron Jobs</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>PHP Flags Manager</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Online Browser File Manager</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>IP Address Deny</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>10 MB Max File Size</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Custom CNAME Records</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Unmetered MySQL space</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td><h4>SCRIPTING FEATURES</h4></td>

				<td align="center"></td>

			</tr>

			<tr>

				<td>PHP</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>MySQL</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>PhpMyAdmin</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

                                <td><h4>EMAIL FEATURES</h4></td>

                                <td align="center"></td>

                        </tr>

                        <tr>

                                <td>Webmail</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>

                        <tr>

                                <td>Email Accounts (you@yourdomain.com)</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>

                        <tr>

                                <td>Email Forwarders</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>

                        <tr>

                                <td>MX Record Entry</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>

                        <tr>

                                <td>SPF Records</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>



				<td><h4>ECOMMERCE FEATURES</h4></td>

				<td align="center"></td>

			</tr>

			<tr>

				<td>PHP cart scripts install ability</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Password Protected Folders</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Bandwidth</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td><h4>SECURITY</h4></td>

				<td align="center"></td>

			</tr>

                        <tr>

                                <td>Automatic Self Signed SSL (https://)</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>

                        <tr>

                                <td>Install your own SSL certificate</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>

                        <tr>

                                <td>1-Click Cloudflare Enabler</td>

                                <td align="center"><div class="check"><img src="images/check.png"></div></td>

                        </tr>





			<tr>

				<td>24/7 Monitoring</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Firewall Protection</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>UPS Power Back-up/Back-up</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Generator</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>			

			<tr>

				<td>Hotlink Protection</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td><h4>OUR TECHNOLOGY</h4></td>

				<td align="center"></td>

			</tr>

			<tr>

				<td>Cisco Powered Network</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Linux Clustered Server Network</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Intel Processors</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

			<tr>

				<td>Apache Web Servers</td>

				<td align="center"><div class="check"><img src="images/check.png"></div></td>

			</tr>

		</table>
	  <a class="bsubtn" href="signup.php">Sign up now!</a>	
	</div>
      <div class="body-right">
        <h2>And even more!</h2>
        <div class="mbox">
        <img src="images/feature-1.png">
        <h3>Website Builder!</h3>
        <p>We offer an easy-to-use drag & drop free website builder tool that will help you create professional looking websites!</p>
        </div>
        <div class="mbox">
        <img src="images/feature-2.png">
        <h3>Softaculous Script installer!</h3>
        <p>It takes time & knowledge to install a forum, blog or an online store, not with our free One-click Softaculous script installer!</p>
        </div>
        <div class="mbox">
        <img src="images/feature-4.png">
        <h3>SEO Tools!</h3>
        <p>We will also offering free SEO tools to submit and help your websites get better ranking in the social networks!</p>
        </div>
        <div class="mbox">
        <img src="images/feature-3.png">
        <h3>Professional Support!</h3>
        <p>We are providing fast response email support, you'll never need to look arround for answers!</p>
        </div>
      </div>
      <div class="ground"></div>
      <br/>
	<div class="hr"></div>    
    <h2>Why us</h2>
    <p>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run normally using the working servers!</p>    
    </div>
      <div class="ground"></div>
    </div>
    <div class="ground"></div>
  	</div>
    <div class="footer">
    <div class="footer_resize">
      <p class="copyright">© <?echo $yourdomain;?>, Powered By <a href="https://ifastnet.com">iFastNet</a>.</p>
    <div class="social">
	  <ul>
		<li class="youtube">
			<a href="" target="_blank">YouTube</a>
		</li>
		<li class="googleplus">
			<a href="" target="_blank">Google +r</a>
		</li>
		<li class="twitter">
			<a href="" target="_blank">Twitter</a>
		</li>
		<li class="facebook">
			<a href="" target="_blank">Facebook</a>
		</li>
	  </ul>
	</div>    
      <div class="ground"></div>
    </div>
    <div class="ground"></div>
  </div>
</div>
<a href="#" class="go-top">Go Top</a>
</body>
<!-- UltraSet Template designed by iFastNet exclusively for MyOwnFreeHost users | Please respect our terms of use -->
</html>
