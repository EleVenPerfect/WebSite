<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><? echo "$yourdomain" ;?>web hosting</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
</head>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<body>
<div id="header_wrapper">

  <div id="header">
    
   	<div id="site_logo"></div>
        
		<div id="menu">
      		<div id="menu_left"></div>
            <ul>
                  <li><a href="index.php" class="current">Home</a></li>
                  <li><a href="signup.php">Sign Up</a></li>
                  <li><a href="news.php">Product News</a></li>
                  <li><a href="about.php">About Us</a></li>
                  <li><a href="contact.php" class="last">Contact Us</a></li>
            </ul>    	
		</div> <!-- end of menu -->
    
    </div>  <!-- end of header -->
</div> <!-- end of header wrapper -->

<div id="banner_wrapper">
	<div id="banner">
    
    	<div id="banner_image">
        	<div id="banner_image_wrapper">
            	<img src="images/image_01.jpg" alt="image 1" />
            </div>
        </div>
        
        <div id="banner_content">
        	<div class="header_01"><? echo "$yourdomain" ;?></div>
            <p>Free and Premium web hosting</p>
            <div class="button_01"><a href="news.php">Read more</a></div>
        </div>	
    
    	<div class="cleaner"></div>
    </div> <!-- end of banner -->
</div> <!-- end of banner wrapper -->

<div id="content_wrapper">
	<div id="content">
    
    	<div id="column_w530">
        	
            <div class="header_02">Welcome to <? echo "$yourdomain" ;?></div>
            
            <p class="em_text"><strong>We are specialists</strong> in free hosting services using clustered technology powered by a one of the largest hosting organisations on the internet. Combined with our high bandwidth, space provisions and excellent sub-domain options, and all free accounts include:</p>
            
<li>1000 MB Disk Space</li>
<li>FTP account and File Manager</li>
<li>MySQL databases &amp; PHP Support</li>
<li>Addon domain, Parked Domains, Sub-Domains</li>
<li>Free Community Access (Forums)</li>
<li>Clustered Servers</li>
<li>Softaculous</li>
<li>Cron Jobs</li>
<li>SPF Records</li>
<li> Automatic Self Signed SSL</li>
<li>phpmyadmin</a></li>
<li>Webmail account</a></li>
<li>80 SEO tools</a></li>
<li>Search Engine Submitter</a></li>
<li>Control Panel x3 theme</a></li>
            
            <div class="margin_bottom_20"></div>
            
            <ul class="content_list_01">
                <li>You can find Softaculous Automatic Script Installer in the cpanel. We provide free FTP, PHP 5.4, MySQL and our very popular feature: You can install many popular scripts such as PHPbb2 and PHPbb3, Wordpress, Zen-Cart, osCommerce, MyBB, UseBB, MyLittle Forum, 4images, Coppermine, SMF, Joomla, e107, XOOPS, PHP Wind, CuteNews, Mambo, WikiWig and many more! No need to wait a long time uploading files, Our Automatic Script Installer deploys your files in seconds!</li>
            </ul>
            
            <div class="margin_bottom_20"></div>           
            
            <div class="content_section_01">
            	For any web site from a small business brochure, pictures of a tropical holiday, to powerful dynamic websites for a gaming clan etc, <? echo "$yourdomain" ;?> Internet has the right services for you and at the right price... $0.00!
            </div>
            
            <div class="cleaner"></div>
        </div>
        
        <div id="column_w300">

        	<div class="header_03">Latest Plans</div>
            
            <div class="column_w300_section_01">
            	<div class="news_image_wrapper">
                	<img src="images/image_02.jpg" alt="image" />
                </div>
                
                <div class="news_content">
                	<div class="news_date">Click here for</div>
                    <div class="header_04"><a href="signup.php">Free accounts</a></div>
                    <p>Accounts are activated instantly.</p>
				</div>
                                
                <div class="cleaner"></div>
            </div>
            
            <div class="column_w300_section_01 even_color">
            	<div class="news_image_wrapper">
                	<img src="images/image_03.jpg" alt="image" />
                </div>
                
                <div class="news_content">
                	<div class="news_date">Click here for</div>
                    <div class="header_04"><a href="https://ifastnet.com/portal/sharedhosting.php">Premium plans</a></div>
                    <p>we have a variety of premium plans to choose from.</p>
				</div>
                                
                <div class="cleaner"></div>
            </div>
            
            <div class="column_w300_section_01">
            	<div class="news_image_wrapper">
                	<img src="images/image_04.jpg" alt="image" />
                </div>
                
                <div class="news_content">
                	<div class="news_date">Click here for</div>
                    <div class="header_04"><a href="https://ifastnet.com/portal/vpshosting.php">VPS Servers</a></div>
                    <p>For the more advanced websites and webmasters.</p>
				</div>
                                
                <div class="cleaner"></div>
            </div>
            
            <div class="cleaner"></div>
        </div>
    
    	<div class="cleaner"></div>
    </div> <!-- end of content wrapper -->
</div> <!-- end of content wrapper -->

<div id="footer_wrapper">

	<div id="footer">
    	
        <div class="section_w180">
        	<div class="header_05">Product News</div>
            <div class="section_w180_content"> 
            	<ul class="footer_menu_list">
                    <li><a href="news.php">Our latest news</a></li>             
                </ul>
			</div>
        </div>
        
        <div class="section_w180">
        	<div class="header_05">About Us</div>
            <div class="section_w180_content">
                <ul class="footer_menu_list">
                    <li><a href="about.php">All about us</a></li>
                </ul>
            </div>
        </div>
          
        <div class="section_w180">
        	<div class="header_05">Premium Plans</div>
            <div class="section_w180_content"> 
                <ul class="footer_menu_list">
                    <li><a href="https://ifastnet.com/portal/sharedhosting.php">Our premium account plans</a></li>
                </ul>
			</div>
        </div>
        
        <div class="section_w180">
	        <div class="header_05">Contact us</div>
            
            <div class="section_w180_content">
            
                <ul class="footer_menu_list">
                    <li><a href="contact.php">How to contact us</a></li>
                </ul>
			</div>
        </div>
        
        <div class="section_w180">
			<div class="header_05">Free Hosting</div>  
            <div class="section_w180_content">      
                <ul class="footer_menu_list">
                    <li><a href="signup.php">Sign Up</a></li>
                </ul>
			</div>
        </div>
        
        <div class="margin_bottom_20"></div>
        Copyright © 2013 <a href="#"><? echo "$yourdomain" ;?></a>
    </div> <!-- end of footer -->
</div>
</body>
</html>
