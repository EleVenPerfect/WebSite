<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><? echo "$yourdomain" ;?>web hosting</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
</head>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<body>
<div id="header_wrapper">

  <div id="header">
    
   	<div id="site_logo"></div>
        
		<div id="menu">
      		<div id="menu_left"></div>
            <ul>
                  <li><a href="index.php">Home</a></li>
                  <li><a href="signup.php">Sign Up</a></li>
                  <li><a href="news.php" class="current">Product News</a></li>
                  <li><a href="about.php">About Us</a></li>
                  <li><a href="contact.php" class="last">Contact Us</a></li>
            </ul>    	
		</div> <!-- end of menu -->
    
    </div>  <!-- end of header -->
</div> <!-- end of header wrapper -->

<div id="banner_wrapper">
	<div id="banner">
    
    	<div id="banner_image">
        	<div id="banner_image_wrapper">
            	<img src="images/image_01.jpg" alt="image 1" />
            </div>
        </div>
        
        <div id="banner_content">
        	<div class="header_01"><? echo "$yourdomain" ;?></div>
            <p>Free and Premium web hosting</p>
            <div class="button_01"><a href="news.php">Read more</a></div>
        </div>	
    
    	<div class="cleaner"></div>
    </div> <!-- end of banner -->
</div> <!-- end of banner wrapper -->

<div id="content_wrapper">
	<div id="content">
    
    	<div id="column_w530">
        	
            <div class="header_02">Welcome to <? echo "$yourdomain" ;?></div>
            
  <p>We proudly announce the following new features on all free hosting accounts!..<br></br>
<strong>1. cPanel x3 theme</strong> - The popular and professional x3 theme is now available for all free hosting accounts.<br>
<strong>2. 80 SEO tools</strong> - From keyword checkers to page optimization utilities, this huge selection of completely free tools helps you grow a successful website.<br>
<strong>3. Search Engine Submitter</strong> - All free hosting customers can now submit their websites for free to over 100 search engines from one location in your control panel.  Every free hosting control panel now has the cPanel x3 theme provided as the default theme.

You can find our Automatic Script Installer in the Vistapanel. We provide free FTP, PHP 5.3, MySQL and our very popular feature: The Automatic Script Installer (Like Fantastico) You can install many popular scripts such as PHPbb2 and PHPbb3, Wordpress, Zen-Cart, osCommerce, MyBB, UseBB, MyLittle Forum, 4images, Coppermine, SMF, Joomla, e107, XOOPS, PHP Wind, CuteNews, Mambo, WikiWig and many more! No need to wait a long time uploading files, Our Automatic Script Installer deploys your files in seconds! You can find our Automatic Script Installer in the Vistapanel.


            <div class="content_section_01">
You can sign up here for fast free PHP & MySQL hosting including a free sub domain. A powerful Vista Panel control panel is provided to manage your website, packed with hundreds of great features including Email, FTP add-on domain and much more.
            	
            </div>


            
            <div class="cleaner"></div>
        </div>
        
        <div id="column_w300">
        
        	<div class="header_03">Latest Plans</div>
            
            <div class="column_w300_section_01">
            	<div class="news_image_wrapper">
                	<img src="images/image_02.jpg" alt="image" />
                </div>
                
                <div class="news_content">
                	<div class="news_date">Click here for</div>
                    <div class="header_04"><a href="signup.php">Free accounts</a></div>
                    <p>Accounts are activated instantly.</p>
				</div>
                                
                <div class="cleaner"></div>
            </div>
            
            <div class="column_w300_section_01 even_color">
            	<div class="news_image_wrapper">
                	<img src="images/image_03.jpg" alt="image" />
                </div>
                
                <div class="news_content">
                	<div class="news_date">Click here for</div>
                    <div class="header_04"><a href="https://ifastnet.com/portal/sharedhosting.php">Premium plans</a></div>
                    <p>we have a variety of premium plans to choose from.</p>
				</div>
                                
                <div class="cleaner"></div>
            </div>
            
            <div class="column_w300_section_01">
            	<div class="news_image_wrapper">
                	<img src="images/image_04.jpg" alt="image" />
                </div>
                
                <div class="news_content">
                	<div class="news_date">Click here for</div>
                    <div class="header_04"><a href="https://ifastnet.com/portal/vpshosting.php">VPS Servers</a></div>
                    <p>For the more advanced websites and webmasters.</p>
				</div>
                                
                <div class="cleaner"></div>
            </div>
            
            <div class="cleaner"></div>
        </div>
    
    	<div class="cleaner"></div>
    </div> <!-- end of content wrapper -->
</div> <!-- end of content wrapper -->

<div id="footer_wrapper">

	<div id="footer">
    	
        <div class="section_w180">
        	<div class="header_05">Product News</div>
            <div class="section_w180_content"> 
            	<ul class="footer_menu_list">
                    <li><a href="news.php">Our latest news</a></li>             
                </ul>
			</div>
        </div>
        
        <div class="section_w180">
        	<div class="header_05">About Us</div>
            <div class="section_w180_content">
                <ul class="footer_menu_list">
                    <li><a href="about.php">All about us</a></li>
                </ul>
            </div>
        </div>
          
        <div class="section_w180">
        	<div class="header_05">Premium Plans</div>
            <div class="section_w180_content"> 
                <ul class="footer_menu_list">
                    <li><a href="https://ifastnet.com/portal/sharedhosting.php">Our premium account plans</a></li>
                </ul>
			</div>
        </div>
        
        <div class="section_w180">
	        <div class="header_05">Contact us</div>
            
            <div class="section_w180_content">
            
                <ul class="footer_menu_list">
                    <li><a href="contact.php">How to contact us</a></li>
                </ul>
			</div>
        </div>
        
        <div class="section_w180">
			<div class="header_05">Free Hosting</div>  
            <div class="section_w180_content">      
                <ul class="footer_menu_list">
                    <li><a href="signup.php">Sign Up</a></li>
                </ul>
			</div>
        </div>
        
        <div class="margin_bottom_20"></div>
        Copyright © 2013 <a href="#"><? echo "$yourdomain" ;?></a>
    </div> <!-- end of footer -->
</div>
</body>
</html>
