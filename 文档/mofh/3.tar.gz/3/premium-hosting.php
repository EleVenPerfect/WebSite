﻿<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
<head>
<title>Premium Hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel='stylesheet' id='google_fonts_style-css'  href='http://fonts.googleapis.com/css?family=Armata&amp;ver=3.5' type='text/css' media='all' />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="js/go-top.js"></script>
</head>
<body>
<div id="top">
<div class="page">
  <div class="head">
    <div class="header">
      <div class="logo"><a href="index.php"><?echo $yourdomain;?></a></div>
        <? include ('navigation.php'); ?>
    </div>
  </div>
  <div class="spacer"></div>
  <div class="header_text_bg">
    <div class="header_text2">
      <h2>Premium Hosting</h2>
      <p>In partnership with iFastNet, we also provide reliable premium hosting, with no daily hit limits, unlimited disk space, no maximum file size...</p>
      <div class="spacer"></div>
    </div>
  </div>
  <div class="spacer"></div>
  <div class="bloga_resize">
    <div class="bloga_resize_use">
      <h3>Our premium hosting features</h3>
      <div class="spacer"></div>
    </div>
    <div class="spacer"></div>
  </div>
  <div class="body">
    <div class="body_resize">
      <div class="body_big">
        <h2>Reliable premium hosting</h2>
		<table class="features-table">
			<tr>
				<td>Monthly Bandwidth</td>
				<td align="center"><span>Up to Unlimited</span></td>
			</tr>
			<tr>
				<td>Web Disk Space</td>
				<td align="center"><span>Up to Unlimited</span></td>
			</tr>
			<tr>
				<td>Price</td>
				<td align="center"><span>Starting from $0.99/Month</span></td>
			</tr>
			<tr>
				<td>Addon Domains</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>Parked Domains</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>Sub Domains</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>Email Accounts</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>MySQL Databases</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>FTP Accounts</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>Free Domain</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>SiteBuilder</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Site Statistics</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Softaculous Script Installer</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Custom Error Pages</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Cron Jobs</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>PHP Flags Manager</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>IP Address Deny</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>File Size Limit</td>
				<td align="center">Unlimited</td>
			</tr>
			<tr>
				<td>Custom CNAME Records</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Unmetered MySQL space</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td><h4>SCRIPTING FEATURES</h4></td>
				<td align="center"></td>
			</tr>
			<tr>
				<td>PHP</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>MySQL</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>PhpMyAdmin</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Ruby On Rails</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Custom CRON Jobs</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Full .htaccess Control</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td><h4>ECOMMERCE FEATURES</h4></td>
				<td align="center"></td>
			</tr>
			<tr>
				<td>PHP cart scripts install ability</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Password Protected Folders</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Bandwidth</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td><h4>SECURITY MECHANISM</h4></td>
				<td align="center"></td>
			</tr>
			<tr>
				<td>24/7 Monitoring</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Firewall Protection</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>UPS Power Back-up/Back-up</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Spam Filter Spam Assassin</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>			
			<tr>
				<td>File Backup & Restore</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Generator</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>			
			<tr>
				<td>Hotlink Protection</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td><h4>OUR TECHNOLOGY</h4></td>
				<td align="center"></td>
			</tr>
			<tr>
				<td>Cisco Powered Network</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Linux Clustered Server Network</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Intel Processors</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Apache Web Servers</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Cloud Servers</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>	
			<tr>
				<td><h4>OUR GUARANTEES</h4></td>
				<td align="center"></td>
			</tr>
			<tr>
				<td>5 Day Money Back</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>Price Freeze for the next year</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>99.9% Uptime Guarantee</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>No Hidden Charges</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>
			<tr>
				<td>24/ 7 Technical Support</td>
				<td align="center"><div class="check"><img src="images/check.png"></div></td>
			</tr>		
		</table>
      </div>
      <div class="body_small">
        <h2>And even more!</h2>
        <p><span>Free website builder</span></p>
        <img src="images/feature-1.png">
        <p>An easy-to-use drag & drop free website builder tool that will help you create professional looking websites!</p>
        
        <p><span>Softaculous script installer!</span></p>
        <img src="images/feature-2.png">
        <p>From Softaculous you'll get free access to over 250 free applications with an automatic update system!</p>
        
        <p><span>Professional support!</span></p>
        <img src="images/feature-3.png">
        <p>Fast response ticket support system, with a team standing by to respond to your queries around the clock!</p>
      </div>
      <br />
  	<div class="spacer"></div>
  	<div class="sbcontainer"><a class="signbtn" href="https://ifastnet.com/portal/sharedhosting.php">Find out more!</a></div>
    </div> 
    <hr />  
    <div class="whyus">
	<h2>Whys us?</h2>
	<p>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run normally using the working servers!</p>
  	</div>
  </div>
  <div class="spacer"></div>
	  <div class="logo-footer"><a href="index.php"><?echo $yourdomain;?></a></div>
	  <div class="social">
	  <a href=""><img class="social bw" src="images/social/facebook.png"></a>
	  <a href=""><img class="social bw" src="images/social/twitter.png"></a>
	  <a href=""><img class="social bw" src="images/social/google.png"></a>
	  </div>
	</div>
	<div class="footer"> 
	    <p class="links"><a href="">Terms of service</a> | <a href="">Privacy policy</a> | <a href="http://cpanel.<? echo "$yourdomain" ;?>">Login</a></p>
	    <p class="copyright">© HostName, Powered By <a href="https://ifastnet.com">iFastNet</a>.</p>
	    <div class="spacer"></div>
	  </div>
	  <div class="spacer"></div>
	</div>
<a href="#" class="go-top">Go Top</a>
</body>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
</html>