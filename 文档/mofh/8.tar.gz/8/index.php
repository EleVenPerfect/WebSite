<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
<head>
<title>Professional Free Hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Roboto+Slab:400,700,300' rel='stylesheet' type='text/css'>
</head>
<body>
  <div class="main">
      <div class="header">
        <div class="block_header">
          <div class="logo"><a href="index.php"><?echo $yourdomain;?></a></div>
          <div class="header_text"><a href="http://cpanel.<? echo "$yourdomain" ;?>">Login</a></div>
          <div class="spacer"></div>
          <div class="menu">
            <? include ('navigation.php'); ?>
      </div>
      <div class="spacer"></div>
    </div>
  </div>
  <div class="headcontainer">
  <div class="head">
  <div class="text">
		<h2>Welcome to our free hosting!</h2>
		<p>Sign up and get benefit of these features & more!</p>
		<ul>
		<li>10GB Cloud Storage & 100GB Bandwidth</li>
		<li>Host Up To 10 Websites On Each Account</li>
		<li>10 MySQL Databases, FTP & Email accounts</li>
		<li>24/7 Monitoring & Firewall Protection</li>
		<li>Free Website Builder & Softaculous</li>
		<li>vPanel Easy-To-Use Control Panel</li>
		</ul>
		<a href="signup.php" class="signup">Sign up now</a><a href="free-hosting.php" class="signup">Learn more</a>
		</div>
		<div class="server"><img src="images/server.png"></div>
  </div>
  </div>
  <div class="spacer"></div>
  <div class="body">
    <div class="body_resize">
        <h2>Welcome to our hosting</h2>
		    <p>We are specialists in free hosting services using clustered technology powered by one of the largest hosting organizations on the internet. Sign up here for fast free PHP & MySQL hosting including a free sub domain. A powerful, easy-to-use control panel provided to manage your website, packed with hundreds of great features including website building tools, Email, FTP add-on domain <br>Our hosting platform is the only one in the world to automatically enable SSL HTTPS protection on every domain name.  This means all websites on our servers have https protection for added security and better Search Engine rankings!</p>
      <hr />
      <div class="port">
        <h3>Free Hosting</h3>
        <img src="images/sv-1.jpg" alt="img" width="286" height="101" />
        <p>We provide quality free hosting powered by one of the largest hosting organizations on the internet!</p>
        <a class="btn" href="free-hosting.php">Read more »</a>
      </div>
      <div class="port">
        <h3>Premium Hosting</h3>
        <img src="images/sv-2.jpg" alt="img" width="286" height="101" />
        <p>Powerful premium cPanel hosting powered by iFastNet with multiple plans to match your needs!</p>
        <a class="btn" href="premium-hosting.php">Read more »</a>
      </div>
      <div class="port">
        <h3>Domain Names</h3>
        <img src="images/sv-3.jpg" alt="img" width="286" height="101" />
        <p>Register your own premium domain name within few minutes, we support many extensions.</p>
        <a class="btn" href="domains.php">Read more »</a>
      </div>
      <h2>Domain Registration</h2> 
      <div class="domains">  
      <p>Enter the domain with the extension (ex: yourname.com) tld you wish to use in the box below and click search to see whether the domain is available for purchase.</p>      
      <form method="post" action="https://ifastnet.com/portal/domainchecker.php" target="_blank" class="form-wrapper">
      	<input type="text" placeholder="Enter your domain here" name="domain" value="" id="search">
      	<input type="submit" value="go" id="submit">
      </form>
      <p><br />This service is powered by iFastNet</p>     
      </div>
      <hr />
        <h2>Why us</h2>
		    <p>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run normally using the working servers!</p>
      </div>
      <div class="spacer"></div>
    </div>
  </div>
<div class="footer">
  <div class="footer_resize">
  <div class="leftt">
  	  <a class="facebook" href="#"></a>
  	  <a class="google" href="#"></a>
  	  <a class="twitter" href="#"></a>
  </div>
    <p class="rightt">© <?echo $yourdomain;?>, Powered By <a href="https://ifastnet.com">iFastNet</a>.</p>
    <div class="spacer"></div>
  </div>
  <div class="spacer"></div>
</div>
</body>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
</html>