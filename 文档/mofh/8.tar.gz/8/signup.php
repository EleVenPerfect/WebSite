<?PHP
// This is used to geneate a unique number for catchpa 
$id = md5(rand(6000,99999999999999991000));
?>
<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
<head>
<title>Free Hosting Sign Up</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Roboto+Slab:400,700,300' rel='stylesheet' type='text/css'>
</head>
<body>
  <div class="main">
	  <div class="header">
	    <div class="block_header">
          <div class="logo"><a href="index.php"><?echo $yourdomain;?></a></div>
          <div class="header_text"><a href="http://cpanel.<? echo "$yourdomain" ;?>">Login</a></div>
	      <div class="spacer"></div>
	      <div class="menu">
            <? include ('navigation.php'); ?>
      </div>
      <div class="spacer"></div>
    </div>
  </div>
  <div class="headcontainer2">
  <div class="head">
  <div class="text2">
		<h2>Thank You!</h2>
		<p>That was a good decision! Thank you for trusting us!</p>
		</div>
		<div class="img"><img src="images/free-hosting.png"></div>
  </div>
  </div>
  <div class="spacer"></div>
  <div class="body">
    <div class="body_resize">
        <h2>Please fill out the form below</h2>
		<div class="body-left">
				<form class="signupform" method=post action="http://order.<?echo $yourdomain;?>/register2.php">
					<table>
						<tr><th>Username<td><input class="signupipt" type=text name=username size=30 value=""  maxlength="16" onkeyup="return ismaxlength(this)"><td>
						<tr><th>Password<td><input class="signupipt" type=password name=password size=30 maxlength="8" onkeyup="return ismaxlength(this)"><td>
						<tr><th>Email Address<td><input class="signupipt" type=text name=email size=30 value=""><td>
						                                 </td>
						<tr><th>Site Category<td><select  class="signupiptsl" size="1" name="website_category">
						<option>Personal</option>
						<option>Business</option>
						<option>Hobby</option>
						<option>Forum</option>
						<option>Adult</option>
						<option>Dating</option>
						<option>Software / Download</option>
						</select>
						</td>
						<tr><th>Site Language<td>
						<select  class="signupiptsl"size="1" name="website_language">
						<option>English</option>
						<option>Non-English</option>
						</select>
						</td>
						<input type="hidden" name="id" value="<?PHP echo $id; ?>">
						<tr><th>Security Code<td><div class="captcha"><img width=200px; height=90px; src="http://order.<? echo "$yourdomain" ;?>/image.php?id=<?PHP echo $id; ?>"></div><td>
						<tr><th>Enter Security Code<td><input class="signupipt" type=text name=number size=30><td>
						<tr><th colspan=2><input type=submit class="signupbtn" value="Register" name=submit><td>
					</table>
				</form>
			</div>
		      <div class="body-right">
		        <h2>Remember</h2>
		        <p>You may not find the email confirmation, so please check your Spam inbox.</p>
				<h2>To use your own domain</h2>
		        <p>If you want to use your own domain name from third parties (free or premium), please remember to set your domain nameservers to ours:<br /><span>ns1.<?echo $yourdomain;?></span><br /><span>ns2.<?echo $yourdomain;?></span></p>
		      </div>
		  <div class="spacer"></div>
      <hr />
        <h2>Why us</h2>
		    <p>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run normally using the working servers!</p>
      </div>
      <div class="spacer"></div>
    </div>
  </div>
<div class="footer">
  <div class="footer_resize">
  <div class="leftt">
  	  <a class="facebook" href="#"></a>
  	  <a class="google" href="#"></a>
  	  <a class="twitter" href="#"></a>
  </div>
    <p class="rightt">© <?echo $yourdomain;?>, Powered By <a href="https://ifastnet.com">iFastNet</a>.</p>
    <div class="spacer"></div>
  </div>
  <div class="spacer"></div>
</div>
</body>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
</html>
