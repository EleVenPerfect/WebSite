<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><? echo "$yourdomain" ;?>web hosting</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="default.css" rel="stylesheet" type="text/css" />
</head>
<body>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<div id="header">
  <h1><? echo "$yourdomain" ;?></h1>
  <h2>Free and Premium Hosting</h2>
  <ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="signup.php">Sign Up</a></li>
    <li><a href="news.php">News</a></li>
    <li><a href="about.php" class="current">About Us</a></li>
    <li><a href="contact.php">Contact</a></li>
  </ul>
</div>
<div id="content">

  <div id="colOne">
        <li><a href="signup.php">Sign up for Free Hosting</a></li>
        <li><a href="https://ifastnet.com/portal/sharedhosting.php">Sign up for Premium Hosting</a></li>
        <li><a href="https://ifastnet.com/portal/vpshosting.php">Sign up for a VPS Server</a></li>

<img src="images/img8.jpg" alt="servers" width="186" height="400"  />
<p></p>


  </div>

  <div id="colTwo">
    <div class="bg2">
      <h2>About Us</h2>
      <p><img src="images/img5.jpg" alt="" width="180" height="137" class="image" /></p>
      <p><strong>We are specialists</strong> in free hosting services using clustered technology powered by a one of the largest hosting orgainisations on the internet. We have a friendly, accessible team of engineers, support professionals, business developers and more based all around the world focused on the continued market and technological success of our company while adding value to our services to benefit our users, clients and customers.
<br></br>
Our cluster-based GRID network features hundreds of server nodes using the right software for the right job powered by Linux and Unix operating systems. Our hardware throughout the network mainly consists of Quad-CPU Intel Xeon processors which stand up to the most demanding requests of the network such as processing end user requests.
    </div>
    <h3>Hosting Plans</h3>
    <div class="bg1">
      <p>You can sign up here for fast free PHP & MySQL hosting including a free sub domain. A powerful Vista Panel control panel is provided to manage your website, packed with hundreds of great features including Email, FTP add-on domain and much more.</p>
      <ul>
        <li><a href="signup.php">Sign up for Free Hosting</a></li>
        <li><a href="https://ifastnet.com/portal/sharedhosting.php">Sign up for Premium Hosting</a></li>
        <li><a href="https://ifastnet.com/portal/vpshosting.php">Sign up for a VPS Server</a></li>
      </ul>
    </div>
  </div>
</div>
<div id="footer">
  <p>Copyright (c) 2013 <? echo "$yourdomain" ;?> All Rights Reserved.</p>
</div>
</body>
</html>
