<div id="menu">
  <ul>
    <li class="first"><a href="index.php"><b>H</b>omepage</a></li>
    <li><a href="signup.php" accesskey="A"><b>S</b>ignup</a></li>
    <li><a href="news.php" accesskey="P"><b>P</b>roduct new</a></li>
    <li><a href="https://ifastnet.com/portal/" accesskey="S"><b>P</b>aid services</a></li>
    <li><a href="contact.php" accesskey="U">Contact <b>U</b>s</a></li>
    <li><a href="https://ifastnet.com/portal/terms.php" accesskey="S"><b>T</b>erms of service</a></li>
  </ul>
</div>
<div id="logo">
  <h1><a href="/index.php"><? echo "$yourdomain" ;?></a></h1>
  <h2><a href="/index.php">Free and premium hosting</a></h2>
</div>
