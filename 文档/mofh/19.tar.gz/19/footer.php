<div id="footer">
<div class="wrapper">
<p class="links">
<a href="/index.php">Home</a> &#183; 
<a href="https://ifastnet.com/portal/terms.php">Terms of service</a> &#183; 
<a href="/contact.php">Contact us</a> &#183; 
<a href="/news.php">Hosting news</a> &#183; 
<a href="https://ifastnet.com/portal/">Paid services</a> &#183; 
<a href="signup.php">Signup</a>

</p>
    
<p class="legal">&copy; 2013 <? echo "$yourdomain" ;?></p>
  </div>
</div>
