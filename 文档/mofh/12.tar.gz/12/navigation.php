        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="index.php">Home</a></li>
            <li><a href="free-hosting.php">Free Hosting</a></li>
            <li><a href="premium-hosting.php">Premium Hosting</a></li>
            <li><a href="domains.php">Domain Names</a></li>
            <li><a href="whyus.php">Why Us</a></li>
            <li><a href="support.php">Support</a></li>
            <a href="http://cpanel.<? echo "$yourdomain" ;?>">Login</a></li>
          </ul>
        </div>