<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html>
<html lang="en">
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Professional Free Hosting</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <div class="navbar navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.html"><?echo $yourdomain;?></a>
        </div>
        <? include ('navigation.php'); ?>
      </div>
    </div>
	<div id="ww">
	    <div class="container">
		  <div class="header_text_bg">
		    <div class="header_text">
		      <div class="div">
		        <div class="left1">
		          <h2>Professional Free Web Hosting</h2>
		          	<p><strong>Sign up and get benefit of all these features & even more!</strong></p>
		          	<ul>
						<li>10GB Cloud Storage & 100GB Bandwidth</li>
						<li>Host up to 10 Websites on Each Account</li>
						<li>10 MySQL Databases, FTP & Email accounts</li>
						<li>24/7 Monitoring & Firewall Protection</li>
						<li>Free Website Builder & Softaculous</li>
						<li>vPanel Easy-To-Use Control Panel</li>
		          	</ul>
		          <div class="spacer"></div>
		         <p><a href="free-hosting.php" class="headbtn">Learn more</a><a href="signup.php" class="headbtn">Sign up</a></p>
		       </div>
		      </div>
		     <div class="spacer"></div>
		    </div>
		   </div>
	    </div> 
	</div>
	<div class="container pt">
		<h1>Welcome to <?echo $yourdomain;?> Hosting</h1>
		<p>We are specialists in free hosting services using clustered technology powered by one of the largest hosting organizations on the internet. Sign up here for fast free PHP & MySQL hosting including a free sub domain. A powerful, easy-to-use control panel provided to manage your website, packed with hundreds of great features including website building tools, Email, FTP add-on domain <br>Our hosting platform is the only one in the world to automatically enable SSL HTTPS protection on every domain name.  This means all websites on our servers have https protection for added security and better Search Engine rankings!</p>
		<hr />
		<div class="row mt centered">	
			<div class="col-lg-3">
				<h3>Free Hosting</h3>
				<img class="spaced" src="img/srv1.jpg"/>
				<p>We provide quality free hosting powered by one of the largest hosting organizations on the web!</p>
				<a href="free-hosting.php">Find out more</a>
			</div>
			<div class="col-lg-3">
				<h3>Premium Hosting</h3>
				<img class="spaced" src="img/srv2.jpg"/>
				<p>Premium hosting powered by iFastNet with multiple plans to match your needs!</p>
				<a href="premium-hosting.php">Find out more</a>
			</div>
			<div class="col-lg-3">
				<h3>Domain Names</h3>
				<img class="spaced" src="img/srv3.jpg"/>
				<p>Register your own domain name within few minutes, we support many extensions.</p>
				<a href="domains.php">Find out more</a>
			</div>
			<div class="col-lg-3">
				<h3>24/7 Support</h3>
				<img class="spaced" src="img/srv4.jpg"/>
				<p>We are providing fast response email support, you'll never need to look arround for answers!</p>
				<a href="support.php">Find out more</a>
			</div>
		</div>
		<hr />
		<h3>Whys us?</h3>
		<p>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run normally using the working servers!</p>
	</div>
	<div id="footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-4">
					<h4>Services</h4>
					<p>
						<a href="free-hosting.php">Free Hosting</a><br/>
						<a href="premium-hosting.php">Premium Hosting</a><br/>
						<a href="domains.php">Domain Names</a>
					</p>
				</div>
				<div class="col-lg-4">
					<h4>Find Us</h4>
					<p>
						<a href="#">Facebook</a><br/>
						<a href="#">Google Plus</a><br/>
						<a href="#">Twitter</a><br/>
					</p>
				</div>
				<div class="col-lg-4">
					<h4>Other Links</h4>
					<p>
						<a href="#">Terms Of Services</a><br/>
						<a href="#">Privacy Policy</a><br/>
						<a href="http://cpanel.<? echo "$yourdomain" ;?>">Login to cPanel</a><br/>
					</p>
				</div>
			</div>
			<div class="copyright"><p>© <?echo $yourdomain;?>, Powered By <a href="https://ifastnet.com">iFastNet</a>.</p></div>
		</div>
	</div>
    <script src="js/bootstrap.min.js"></script>
  </body>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
</html>
