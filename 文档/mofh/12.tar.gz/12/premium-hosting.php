<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html>
<html lang="en">
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Premium Hosting</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <div class="navbar navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.html"><?echo $yourdomain;?></a>
        </div>
        <? include ('navigation.php'); ?>
      </div>
    </div>
	<div id="ww">
	    <div class="container">
		  <div class="header_text_bg">
		    <div class="header_text_premiumhost">
		      <div class="div">
		        <div class="left1">
		          <h2>Premium Hosting</h2>
		          	<p>We provide completely free hosting, includes a powerful control panel, FTP, site builder.<br />
		          	automatic script installer and many more features..</p>
		       </div>
		      </div>
		     <div class="spacer"></div>
		    </div>
		   </div>
	    </div>
	</div>
	<div class="container pt">
		<h3>Our premium hosting features</h3>
		<hr />		<table class="features-table">
			<tr>
				<td>Monthly Bandwidth</td>
				<td align="center"><span>Up to Unlimited</span></td>
			</tr>
			<tr>
				<td>Web Disk Space</td>
				<td align="center"><span>Up to Unlimited</span></td>
			</tr>
			<tr>
				<td>Price</td>
				<td align="center"><span>Starting from $0.99/Month</span></td>
			</tr>
			<tr>
				<td>Addon Domains</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>Parked Domains</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>Sub Domains</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>Email Accounts</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>MySQL Databases</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>FTP Accounts</td>
				<td align="center">Up to Unlimited</td>
			</tr>
			<tr>
				<td>Free Domain</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>SiteBuilder</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Site Statistics</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Softaculous Script Installer</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Custom Error Pages</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Cron Jobs</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>PHP Flags Manager</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>IP Address Deny</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>File Size Limit</td>
				<td align="center">Unlimited</td>
			</tr>
			<tr>
				<td>Custom CNAME Records</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Unmetered MySQL space</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td><h4>SCRIPTING FEATURES</h4></td>
				<td align="center"></td>
			</tr>
			<tr>
				<td>PHP</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>MySQL</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>PhpMyAdmin</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Ruby On Rails</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Custom CRON Jobs</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Full .htaccess Control</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td><h4>ECOMMERCE FEATURES</h4></td>
				<td align="center"></td>
			</tr>
			<tr>
				<td>PHP cart scripts install ability</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Password Protected Folders</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Bandwidth</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td><h4>SECURITY MECHANISM</h4></td>
				<td align="center"></td>
			</tr>
			<tr>
				<td>24/7 Monitoring</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Firewall Protection</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>UPS Power Back-up/Back-up</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Spam Filter Spam Assassin</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>			
			<tr>
				<td>File Backup & Restore</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Generator</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>			
			<tr>
				<td>Hotlink Protection</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td><h4>OUR TECHNOLOGY</h4></td>
				<td align="center"></td>
			</tr>
			<tr>
				<td>Cisco Powered Network</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Linux Clustered Server Network</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Intel Processors</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Apache Web Servers</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Cloud Servers</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>	
			<tr>
				<td><h4>OUR GUARANTEES</h4></td>
				<td align="center"></td>
			</tr>
			<tr>
				<td>5 Day Money Back</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>Price Freeze for the next year</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>99.9% Uptime Guarantee</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>No Hidden Charges</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>
			<tr>
				<td>24/ 7 Technical Support</td>
				<td align="center"><div class="check"><img src="img/check.png"></div></td>
			</tr>		
		</table>
	<div class="col-lg-8 col-lg-offset-2 centered">
					<h1>And Even More!</h1>
					<p>Sign up now and get your premium quality free hosting account!</p>
				</div>
	<div class="signup"><a class="btn" href="https://ifastnet.com/portal/sharedhosting.php">Sign up now!</a></div>
    <hr />
		<div class="row mt centered">	
			<div class="col-lg-3">
				<h3>Free Websit Builder</h3>
				<img class="spaced" src="img/hf1.jpg"/>
				<p>An easy-to-use drag & drop free website builder tool that will help you create professional looking websites!</p>
			</div>
			
			<div class="col-lg-3">
				<h3>Softaculous!</h3>
				<img class="spaced" src="img/hf2.jpg"/>
				<p>From Softaculous you'll get free access to over 250 free applications with an automatic update system!</p>
			</div>

			<div class="col-lg-3">
				<h3>Free SEO Tools!</h3>
				<img class="spaced" src="img/hf3.jpg"/>
				<p>We will also offer you free SEO tools to submit and help your websites get better ranking in the social networks!</p>
			</div>

			<div class="col-lg-3">
				<h3>Professional support!</h3>
				<img class="spaced" src="img/srv4.jpg"/>
				<p>Fast response ticket support system, with a team standing by to respond to your queries around the clock!</p>
			</div>
		</div>
		<hr />
		<h3>Whys us?</h3>
		<p>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run normally using the working servers!</p>
	</div>	
	<div id="footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-4">
					<h4>Services</h4>
					<p>
						<a href="free-hosting.php">Free Hosting</a><br/>
						<a href="premium-hosting.php">Premium Hosting</a><br/>
						<a href="domains.php">Domain Names</a>
					</p>
				</div>
				<div class="col-lg-4">
					<h4>Find Us</h4>
					<p>
						<a href="#">Facebook</a><br/>
						<a href="#">Google Plus</a><br/>
						<a href="#">Twitter</a><br/>
					</p>
				</div>
				<div class="col-lg-4">
					<h4>Other Links</h4>
					<p>
						<a href="#">Terms Of Services</a><br/>
						<a href="#">Privacy Policy</a><br/>
						<a href="http://cpanel.<? echo "$yourdomain" ;?>">Login to cPanel</a><br/>
					</p>
				</div>
			</div>
				<div class="copyright"><p>© <?echo $yourdomain;?>, Powered By <a href="https://ifastnet.com">iFastNet</a>.</p></div>
		</div>
	</div>
    <script src="js/bootstrap.min.js"></script>
  </body>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
</html>
