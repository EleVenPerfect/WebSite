<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html>
<html lang="en">
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Why Us?</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <div class="navbar navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.html"><?echo $yourdomain;?></a>
        </div>
        <? include ('navigation.php'); ?>
      </div>
    </div>
	<div id="ww">
	    <div class="container">
		  <div class="header_text_bg">
		    <div class="header_text_whyus">
		      <div class="div">
		        <div class="left1">
		          <h2>Why Us</h2>
		          	<p>We no that it's hard to find a good free hosting provider.<br />Here are some things you must know before making your decision!</p>
		       </div>
		      </div>
		     <div class="spacer"></div>
		    </div>
		   </div>
	    </div>
	</div>
	<div class="container pt">
      <p>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run normally using the working servers!</p>
  <hr />
  <div id="links">
    <ul>
      <li>
      <a>1. Instant activation
        <em>You will get your account up and running within 3 minutes right after you submit your account information.</em></a></li> 
      <li>
      <a>2. Cloud Hosting
        <em>Our free hosting plan is based on Cloud, which means, our servers are integrated to share all resources providing high resource availability.</em></a></li> 
      <li>
      <a>3. Security
        <em>100% secure hosting with 24/7 monitoring, firewal & hotlink protection.</em></a></li> 
      <li>
      <a>4. Complete Solution
        <em>We provide a complete free hosting solution, easy-to-use tools for building, managing and tracking powered by quality technical support!</em></a></li> 
      <li>
      <a>5. Professional
        <em>You'll have access to VistaPanel, a control panel packed with all the features you'll ever need! Website builder, SEO tools, Script installer...</em></a></li> 
      <li>
      <a>6. Low-cost upgrades
        <em>After you're website becomes popular, and when you're ready to upgrade, we got the best shared, vps & dedicated plans for the lower prices!</em></a></li> 
      <li>
      <a>7. Professional Support
        <em>You hate waiting hours and maybe days to get an answer? So do we! That's why we provide 24/7 fast response support service.</em></a></li> 
    </ul>
    </div>
	</div>
	<div id="footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-4">
					<h4>Services</h4>
					<p>
            <a href="free-hosting.php">Free Hosting</a><br/>
            <a href="premium-hosting.php">Premium Hosting</a><br/>
            <a href="domains.php">Domain Names</a>
          </p>
        </div>
        <div class="col-lg-4">
          <h4>Find Us</h4>
          <p>
            <a href="#">Facebook</a><br/>
            <a href="#">Google Plus</a><br/>
            <a href="#">Twitter</a><br/>
          </p>
        </div>
        <div class="col-lg-4">
          <h4>Other Links</h4>
          <p>
            <a href="#">Terms Of Services</a><br/>
            <a href="#">Privacy Policy</a><br/>
            <a href="http://cpanel.<? echo "$yourdomain" ;?>">Login to cPanel</a><br/>
					</p>
				</div>
			  </div>
				<div class="copyright"><p>© <?echo $yourdomain;?>, Powered By <a href="https://ifastnet.com">iFastNet</a>.</p></div>
		</div>
	</div>
    <script src="js/bootstrap.min.js"></script>
  </body>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
</html>
