<?PHP
// This is used to geneate a unique number for catchpa 
$id = md5(rand(6000,99999999999999991000));
?>
<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html>
<html lang="en">
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Free Hosting Sign Up</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <div class="navbar navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.html"><?echo $yourdomain;?></a>
        </div>
        <? include ('navigation.php'); ?>
      </div>
    </div>
	<div id="ww">
	    <div class="container">
		  <div class="header_text_bg">
		    <div class="header_text_signup">
		      <div class="div">
		        <div class="left1">
		          <h2>Thank You!</h2>
		          	<p>That was a good decision! Thank you for trusting us!</p>
		       </div>
		      </div>
		     <div class="spacer"></div>
		    </div>
		   </div>
	    </div>
	</div>
	<div class="container pt">
		<h3>Our free hosting features</h3>
		<hr />
		<div class=".col-lg-pull-6">
		<div class="body-left">
				<form class="signupform" method=post action="http://order.<?echo $yourdomain;?>/register2.php">
					<table>
						<tr><th>Username<td><input class="signupipt" type=text name=username size=30 value=""  maxlength="16" onkeyup="return ismaxlength(this)"><td>
						<tr><th>Password<td><input class="signupipt" type=password name=password size=30 maxlength="8" onkeyup="return ismaxlength(this)"><td>
						<tr><th>Email Address<td><input class="signupipt" type=text name=email size=30 value=""><td>
						                                 </td>
						<tr><th>Site Category<td><select  class="signupiptsl" size="1" name="website_category">
						<option>Personal</option>
						<option>Business</option>
						<option>Hobby</option>
						<option>Forum</option>
						<option>Adult</option>
						<option>Dating</option>
						<option>Software / Download</option>
						</select>
						</td>
						<tr><th>Site Language<td>
						<select  class="signupiptsl"size="1" name="website_language">
						<option>English</option>
						<option>Non-English</option>
						</select>
						</td>
						<input type="hidden" name="id" value="<?PHP echo $id; ?>">
						<tr><th>Security Code<td><div class="captcha"><img width=200px; height=40px; src="http://order.<? echo "$yourdomain" ;?>/image.php?id=<?PHP echo $id; ?>"></div><td>
						<tr><th>Enter Security Code<td><input class="signupipt" type=text name=number size=30><td>
						<tr><th colspan=2><input type=submit class="signupbtn" value="Register" name=submit><td>
					</table>
				</form>
			</div>
		</div>  
		<hr />
		<h3>Whys us?</h3>
		<p>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run normally using the working servers!</p>
	</div>
	<div id="footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-4">
					<h4>Services</h4>
					<p>
						<a href="free-hosting.php">Free Hosting</a><br/>
						<a href="premium-hosting.php">Premium Hosting</a><br/>
						<a href="domains.php">Domain Names</a>
					</p>
				</div>
				<div class="col-lg-4">
					<h4>Find Us</h4>
					<p>
						<a href="#">Facebook</a><br/>
						<a href="#">Google Plus</a><br/>
						<a href="#">Twitter</a><br/>
					</p>
				</div>
				<div class="col-lg-4">
					<h4>Other Links</h4>
					<p>
						<a href="#">Terms Of Services</a><br/>
						<a href="#">Privacy Policy</a><br/>
						<a href="http://cpanel.<? echo "$yourdomain" ;?>">Login to cPanel</a><br/>
					</p>
				</div>
			</div>
				<div class="copyright"><p>© <?echo $yourdomain;?>, Powered By <a href="https://ifastnet.com">iFastNet</a>.</p></div>
		</div>
	</div>
    <script src="js/bootstrap.min.js"></script>
  </body>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
</html>
