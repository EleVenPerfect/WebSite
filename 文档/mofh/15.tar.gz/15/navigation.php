<div class="menu">
        <ul>
          <li><a href="index.php" class="active"><span data-title="Home">Home</span></a></li>
          <li><a href="free-hosting.php"><span data-title="Free Hosting">Free Hosting</span></a></li>
          <li><a href="premium-hosting.php"><span data-title="Premium Hosting">Premium Hosting</span></a></li>
          <li><a href="domains.php"><span data-title="Domain Names">Domain Names</span></a></li>
          <li><a href="why-us.php"><span data-title="Why Us">Why Us</span></a></li>
          <li><a href="support.php"><span data-title="Support">Support</span></a></li>
        </ul>
</div>