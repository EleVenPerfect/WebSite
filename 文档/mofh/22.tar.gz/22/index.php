<!DOCTYPE html>
<html lang="en">
<head>
<title>Web Hosting</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script src="js/jquery-1.6.js" ></script>
<script src="js/cufon-yui.js"></script>
<script src="js/cufon-replace.js"></script>
<script src="js/Shanti_400.font.js"></script>
<script src="js/Didact_Gothic_400.font.js"></script>
<script src="js/jquery.jqtransform.js"></script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<style type="text/css">.button1{behavior:url("js/PIE.htc");}</style>
<![endif]-->
</head>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<body id="page1">
<div class="body1">
  <div class="body2">
    <div class="main">
      <!-- header -->
      <header>
<div class="wrapper">
<h3><strong><? echo "$yourdomain" ;?></strong> Web Hosting Service</h3>
</div>
        <div class="wrapper">
          <h1><a href="index.php" id="logo">Web Hosting</a></h1>
          <nav>
            <ul id="menu">
              <li class="first" id="menu_active"><a href="index.php">Home</a></li>
              <li><a href="signup.php">Sign up</a></li>
              <li><a href="hostingnews.php">Hosting News</a></li>
              <li><a href="about.php">About</a></li>
              <li><a href="contacts.php">Contacts</a></li>
            </ul>
          </nav>
        </div>
        <span id="slogan1">Simple<span>Clever</span><span>Effective</span></span> <span id="slogan2"><a href="#">providing all you need</a> <span>Free and premium hosting</span></span> </header>
      <!-- / header -->
    </div>
  </div>
</div>
<div class="main">
  <!-- content -->
  <section id="content">
    <div class="line1">
      <div class="line2 wrapper">
        <article class="col1 pad_right1">
          <h2><strong class="color1">Free</strong><span>$0.00/month</span></h2>
          <ul class="list1">
<li>1000 MB Disk Space</li>
<li>FTP account and File Manager</li>
<li>Control Panel</li>
<li>MySQL databases &amp; PHP Support</li>
<li>Free tech support</li>
<li>Addon domain, Parked Domains, Sub-Domains</li>
<li>Free Community Access (Forums)</li>
<li>Clustered Servers</li>
<li>Webmail email Accounts</li>
<li>Softaculous</li>
<li>Cron Jobs</li>
<li>SPF Records</li>
<li> Automatic Self Signed SSL</li>
          </ul>
          <div class="button_details"> <a href="/signup.php" class="color1">Details</a> </div>
        </article>
        <article class="col1 pad_right1">
          <h2><strong class="color2">Premium</strong><span>$3.99/month</span></h2>
          <ul class="list1">
            <li><span>unlimited</span>Disk space</li>
            <li><span>250 GB</span>Monthly data transfer</li>
            <li><span>20</span>FTP accounts</li>
            <li><span>100</span>Email boxes</li>
            <li class="end"><span>6</span>Free domains</li>
          </ul>
          <div class="button_details"> <a href="https://ifastnet.com/portal/sharedhosting.php" class="color2">Details</a> </div>
        </article>
        <article class="col1">
          <h2><strong>VPS</strong><span>$9.99/month</span></h2>
          <ul class="list1">
            <li><span>20 GB</span>Disk space</li>
            <li><span>125 GB</span>Monthly data transfer</li>
            <li><span>see plans</span>FTP accounts</li>
            <li><span>see plans</span>Email boxes</li>
            <li class="end"><span>0</span>Free domains</li>
          </ul>
          <div class="button_details"> <a href="https://ifastnet.com/portal/vpshosting.php">Details</a> </div>
        </article>
      </div>
    </div>
  </section>
</div>
<div class="body3">
  <div class="main">
    <section id="content2">
      <div class="line2 wrapper">
        <article class="col2 pad_right1">
          <h3>Register Domain Name</h3>
          <form id="form_1" action="#" method="post">
            <div>
              <div class="wrapper">
                <div class="col1">
                  <input type="text" class="input" value="Type domain name here" onBlur="if(this.value=='') this.value='Type domain name here'" onFocus="if(this.value =='Type domain name here' ) this.value=''">
                </div>
                <div class="col2">
                  <div class="row">
                    <input type="checkbox">
                    .net </div>
                  <div class="row">
                    <input type="checkbox">
                    .info </div>
                  <div class="row">
                    <input type="checkbox">
                    .co.uk </div>
                  <div class="row">
                    <input type="checkbox">
                    .mx </div>
                </div>
                <div class="col2">
                  <div class="row">
                    <input type="checkbox">
                    .com </div>
                  <div class="row">
                    <input type="checkbox">
                    .mobi </div>
                  <div class="row">
                    <input type="checkbox">
                    .eu </div>
                  <div class="row">
                    <input type="checkbox">
                    .us </div>
                </div>
                <div class="col2">
                  <div class="row">
                    <input type="checkbox">
                    .net </div>
                  <div class="row">
                    <input type="checkbox">
                    .info </div>
                  <div class="row">
                    <input type="checkbox">
                    .co.uk </div>
                  <div class="row">
                    <input type="checkbox">
                    .mx </div>
                </div>
                <div class="col2">
                  <div class="row">
                    <input type="checkbox">
                    .com </div>
                  <div class="row">
                    <input type="checkbox">
                    .mobi </div>
                  <div class="row">
                    <input type="checkbox">
                    .eu </div>
                  <div class="row">
                    <input type="checkbox">
                    .us </div>
                </div>
              </div>
              <div class="wrapper"> <span class="links"><a href="#">Renew a domain</a> &nbsp; l &nbsp; <a href="#">Transfer a domain</a> &nbsp;l&nbsp; <a href="#">WHOIS</a></span> <a href="#" class="button1">Check Domain</a> </div>
            </div>
          </form>
        </article>
        <article class="col1">
          <h3>Get Started!</h3>
          <p class="pad_bot1"> <strong class="color3">Don't have hosting website yet?</strong><br>
            Let us help you get started - with one of free accounts.  We provide free FTP, PHP 5.3, MySQL and our very popular feature: The Automatic Script Installer (Like Fantastico) You can install many popular scripts such as PHPbb2 and PHPbb3, Wordpress, Zen-Cart, osCommerce, MyBB, UseBB, MyLittle Forum, 4images, Coppermine, SMF, Joomla, e107, XOOPS, PHP Wind, CuteNews, Mambo, WikiWig and many more! </p>
        </article>
      </div>
    </section>
    <!-- / content  -->
  </div>
</div>
<div class="main">
  <!-- / footer -->
  <footer>Copyright &copy; <a href="#"><? echo "$yourdomain" ;?></a> All Rights Reserved</footer>
  <!-- / footer -->
</div>
<script>Cufon.now();</script>
<script>
jQuery(document).ready(function ($) {
    $('#form_1').jqTransform({
        imgPath: 'jqtransformplugin/img/'
    });
});
</script>
</body>
</html>