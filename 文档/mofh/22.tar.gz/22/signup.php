<!DOCTYPE html>
<html lang="en">
<head>
<title>Web Hosting | Contacts</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script src="js/jquery-1.6.js" ></script>
<script src="js/cufon-yui.js"></script>
<script src="js/cufon-replace.js"></script>
<script src="js/Shanti_400.font.js"></script>
<script src="js/Didact_Gothic_400.font.js"></script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<style type="text/css">.button1{behavior:url("js/PIE.htc");}</style>
<![endif]-->
</head>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<body id="page1">
<div class="body1">
  <div class="body2">
    <div class="main">
      <!-- header -->
      <header>
<div class="wrapper">
<h3><strong><? echo "$yourdomain" ;?></strong> Web Hosting Service</h3>
</div>
        <div class="wrapper">
          <h1><a href="index.php" id="logo">Web Hosting</a></h1>
          <nav>
            <ul id="menu">
              <li class="first"><a href="index.php">Home</a></li>
              <li id="menu_active"><a href="signup.php">Sign up</a></li>
              <li><a href="hostingnews.php">Hosting News</a></li>
              <li><a href="about.php">About</a></li>
              <li ><a href="contacts.php">Contacts</a></li>
            </ul>
          </nav>
        </div>
        <span id="slogan1">Simple<span>Clever</span><span>Effective</span></span> </header>
      <!-- / header -->
    </div>
  </div>
</div>
<!-- content -->
<div class="body3">
  <div class="main">
    <section id="content2">
      <div class="line2 wrapper">

        <article class="col2 pad_right1">
  <h3>Sign Up For Free Hosting</h3>
          <div class="clr"></div>
          <p class="post-data">Fill out the form below and your free hosting account will be created.</p>
          

<td style="text-align: left;" colspan="21">
<font size="-1"><span style="font-family: Helvetica,Arial,sans-serif;">
<form method=post action="http://order.<? echo "$yourdomain" ;?>/register.php">
<table>
<tr><th style="text-align: left;">Username<td><input type=text name=username size=20 value="<?PHP if (isset($_GET['username'])) { echo $_GET['username']; }?>">
<tr><th>&nbsp;<td>&nbsp;
<tr><th style="text-align: left;">Password<td><input type=password name=password size=20>
<tr><th>&nbsp;<td>&nbsp;
<tr><th style="text-align: left;">Email Address<td><input type=text name=email size=20 value="<?PHP if (isset($_GET['email'])) { echo $_GET['email']; }?>">

<tr><th style="text-align: left;">Site Category<td><select size="1" name="website_category">
<option>Choose from Below</option>
<option>Personal</option>
<option>Business</option>
<option>Hobby</option>
<option>Forum</option>
<option>Adult</option>
<option>Dating</option>
<option>Software / Download</option>
</select>
</td>

<tr><th style="text-align: left;"><td>
</td>

<tr><th style="text-align: left;">Site Language<td>
<select size="1" name="website_language">
<option>Choose from Below</option>
<option>English</option>
<option>Non-English</option>
</select>
</td>

<tr><th>&nbsp;<td>&nbsp;
<?PHP 
$id = md5(rand(6000,99999999999999991000));
?>
<input type=hidden name=id value="<?PHP echo $id; ?>">
<tr><th style="text-align: left;">Security Code<td><img width="250px" height="90px" src="http://order.<? echo "$yourdomain" ;?>/image.php?id=<?PHP echo $id; ?>">
<tr><th>&nbsp;<td>&nbsp;
<tr><th style="text-align: left;">Enter Security Code<td><input type=text name=number size=20>
<tr><th>&nbsp;<td>&nbsp;

<tr><th colspan=2><input type=submit value="Register" name=submit>
</table>
</form>		
</span>
<br style="font-family: Helvetica,Arial,sans-serif;">
      </font>
      <br style="font-family: Helvetica,Arial,sans-serif;">
      </span></font>
By signing up for our free hosting, you accept and agree to our <a href="https://ifastnet.com/portal/terms.php">Terms of Service</a>
</td>



        </article>

        <article class="col1">
          <h3></h3>
          <div class="wrapper">
            <p></p>
          </div>
          <h3 class="pad_top1">Instant activation</h3>
          <p class="miscellaneous">Free hosting accounts are activated instantly, no need to wait for manual approval, you can start building your pages immediately!</p>
<p>
You can find our Automatic Script Installer in the Vistapanel. We provide free FTP, PHP 5.3, MySQL and our very popular feature: The Automatic Script Installer (Like Fantastico) You can install many popular scripts such as PHPbb2 and PHPbb3, Wordpress, Zen-Cart, osCommerce, MyBB, UseBB, MyLittle Forum, 4images, Coppermine, SMF, Joomla, e107, XOOPS, PHP Wind, CuteNews, Mambo, WikiWig and many more!</p>
        </article>
      </div>
    </section>
    <!-- / content  -->
  </div>
</div>
<div class="main">
  <!-- / footer -->
  <footer>Copyright &copy; <a href="#"><? echo "$yourdomain" ;?></a> All Rights Reserved</footer>
  <!-- / footer -->
</div>
<script>Cufon.now();</script>
</body>
</html>
