<!DOCTYPE html>
<html lang="en">
<head>
<title>Web Hosting | Contacts</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script src="js/jquery-1.6.js" ></script>
<script src="js/cufon-yui.js"></script>
<script src="js/cufon-replace.js"></script>
<script src="js/Shanti_400.font.js"></script>
<script src="js/Didact_Gothic_400.font.js"></script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<style type="text/css">.button1{behavior:url("js/PIE.htc");}</style>
<![endif]-->
</head>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<body id="page6">
<div class="body1">
  <div class="body2">
    <div class="main">
      <!-- header -->
      <header>
<div class="wrapper">
<h3><strong><? echo "$yourdomain" ;?></strong> Web Hosting Service</h3>
</div>
        <div class="wrapper">
          <h1><a href="index.php" id="logo">Web Hosting</a></h1>
          <nav>
            <ul id="menu">
              <li class="first"><a href="index.php">Home</a></li>
              <li><a href="signup.php">Sign up</a></li>
              <li><a href="hostingnews.php">Hosting News</a></li>
              <li><a href="about.php">About</a></li>
              <li id="menu_active"><a href="contacts.php">Contacts</a></li>
            </ul>
          </nav>
        </div>
        <span id="slogan1">Simple<span>Clever</span><span>Effective</span></span> </header>
      <!-- / header -->
    </div>
  </div>
</div>
<!-- content -->
<div class="body3">
  <div class="main">
    <section id="content2">
      <div class="line2 wrapper">
        <article class="col2 pad_right1">

  <h3>Contact Us</h3>
  <p>for free hosting accounts, if you have any problems or have the need to contact us to ask a question,
      you can use the <span>integrated support system</span> in your control panel to create a support ticket.<br />
   
      We will reply to your question as soon as possible.<br><br />
      For technical support please look at the knowledge base at:<br />
      <a href="http://byet.net/forumdisplay.php?f=28">Knowledge Base</a></p>



        </article>
        <article class="col1">
          <div class="wrapper">
          </div>
          <h3 class="pad_top1">Support for Premium, VPS & Dedicated Servers</h3>
          <p class="miscellaneous">
<a href="http://order.<? echo "$yourdomain" ;?>/premiumsupport/register.php"> Please register here</a> for technical support, sales and billing inquires.</p>


        </article>
      </div>
    </section>
    <!-- / content  -->
  </div>
</div>
<div class="main">
  <!-- / footer -->
  <footer>Copyright &copy; <a href="#"><? echo "$yourdomain" ;?></a> All Rights Reserved</footer>
  <!-- / footer -->
</div>
<script>Cufon.now();</script>
</body>
</html>
