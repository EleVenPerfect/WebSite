<!DOCTYPE html>
<html lang="en">
<head>
<title>Web Hosting | About</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script src="js/jquery-1.6.js" ></script>
<script src="js/cufon-yui.js"></script>
<script src="js/cufon-replace.js"></script>
<script src="js/Shanti_400.font.js"></script>
<script src="js/Didact_Gothic_400.font.js"></script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<style type="text/css">.button1{behavior:url("js/PIE.htc");}</style>
<![endif]-->
</head>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<body id="page4">
<div class="body1">
  <div class="body2">
    <div class="main">
      <!-- header -->
      <header>
<div class="wrapper">
<h3><strong><? echo "$yourdomain" ;?></strong> Web Hosting Service</h3>
</div>
        <div class="wrapper">
          <h1><a href="index.php" id="logo">Web Hosting</a></h1>
          <nav>
            <ul id="menu">
              <li class="first"><a href="index.php">Home</a></li>
              <li><a href="signup.php">Sign up</a></li>
              <li><a href="hostingnews.php">Hosting News</a></li>
              <li id="menu_active"><a href="about.php">About</a></li>
              <li><a href="contacts.php">Contacts</a></li>
            </ul>
          </nav>
        </div>
        <span id="slogan1">Simple<span>Clever</span><span>Effective</span></span> </header>
      <!-- / header -->
    </div>
  </div>
</div>
<div class="main">
  <!-- content -->
  <section id="content">
    <div class="wrapper">
      <article class="col3">
        <h3>A Few Words About Us and our servers</h3>
        <figure class="left marg_right1"><img src="images/page4_img1.jpg" alt=""></figure>
        <p>We have a friendly, accessible team of engineers, support professionals, business developers and more based all around the world focused on the continued market and technological success of our company while adding value to our services to benefit our users, clients and customers.
</p>
        <p>Our cluster-based GRID network features hundreds of server nodes using the right software for the right job powered by Linux and Unix operating systems. Our hardware throughout the network mainly consists of Quad-CPU Intel Xeon processors which stand up to the most demanding requests of the network such as processing end user requests.</p>


      </article>
    </div>
  </section>
</div>
<div class="body3">
  <div class="main">
    <section id="content2">
      <div class="line2 wrapper">
        <article class="col2 pad_right1">
          <h3>Why Us</h3>
        <p>Our platform also consists of separate sub-GRID networks dedicated to such functions such as MySQL databases, FTP management and numerous other functions normally hosted on a handful of machines in other hosting services.
</p>

          <ul class="list4 pad_bot2">
            <li><a href="#">Nam non lacus dui, gravida condimentum tortor</a></li>
            <li><a href="#">Maecenas ultrices volutpat euismod</a></li>
            <li><a href="#">Nam pellentesque imperdiet urna, quis adipiscing nunc blandit non</a></li>
            <li><a href="#">Maecenas imperdiet ultricies dolor cursus accumsan</a></li>
            <li><a href="#">In at sem non lacus euismod aliquet in nec nisl</a></li>
          </ul>
<p>This doesn't of course go to mention the fact that our platform includes multiple redundancy protections such as power protection, backup systems, load balancing hardware, and a very large and expansive Storage Area Network (SAN) with interconnecting fiber optic change distribution servers.</p>
        </article>
        <article class="col1">
          <h3>Testimonials</h3>
          <p class="pad_bot1"><strong class="color3">your name</strong><br>
            <a href="#">Managing Director</a><br>
            Company Name</p>
          <p>Nam libero tempore, cum soluta nohbis esteligendi optio cumque nihil impedit quo minusid quod maxime placeat facere possimus.</p>
          <p class="pad_bot1"><strong class="color3">your name</strong><br>
            <a href="#">Managing Director</a><br>
            Company Name</p>
          <p class="pad_bot1"></p>
        </article>
      </div>
    </section>
    <!-- / content  -->
  </div>
</div>
<div class="main">
  <!-- / footer -->
  <footer>Copyright &copy; <a href="#"><? echo "$yourdomain" ;?></a> All Rights Reserved</footer>
  <!-- / footer -->
</div>
<script>Cufon.now();</script>
</body>
</html>
