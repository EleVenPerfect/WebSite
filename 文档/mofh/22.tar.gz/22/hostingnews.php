<!DOCTYPE html>
<html lang="en">
<head>
<title>Web Hosting | Hosting</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script src="js/jquery-1.6.js" ></script>
<script src="js/cufon-yui.js"></script>
<script src="js/cufon-replace.js"></script>
<script src="js/Shanti_400.font.js"></script>
<script src="js/Didact_Gothic_400.font.js"></script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<style type="text/css">.button1{behavior:url("js/PIE.htc");}</style>
<![endif]-->
</head>
  <? 
    $yourdomain = $_SERVER['HTTP_HOST'];
    $yourdomain = preg_replace('/^www\./' , '' , $yourdomain);
    ?>
<body id="page2">
<div class="body1">
  <div class="body2">
    <div class="main">
      <!-- header -->
      <header>
<div class="wrapper">
<h3><strong><? echo "$yourdomain" ;?></strong> Web Hosting Service</h3>
</div>
        <div class="wrapper">
          <h1><a href="index.php" id="logo">Web Hosting</a></h1>
          <nav>
            <ul id="menu">
              <li class="first"><a href="index.php">Home</a></li>
              <li><a href="signup.php">Sign up</a></li>
              <li id="menu_active"><a href="hostingnews.php">Hosting News</a></li>
              <li><a href="about.php">About</a></li>
              <li><a href="contacts.php">Contacts</a></li>
            </ul>
          </nav>
        </div>
        <span id="slogan1">Simple<span>Clever</span><span>Effective</span></span> </header>
      <!-- / header -->
    </div>
  </div>
</div>
<div class="main">
  <!-- content -->
  <section id="content">
    <div class="line1">
      <div class="line2">
        <div class="line3 wrapper">
  <h3>Free hosting news</h3>
  <p>We proudly announce the following new features on all free hosting accounts!..<br>
<strong>1. cPanel x3 theme</strong> - The popular and professional x3 theme is now available for all free hosting accounts.<br>
<strong>2. Automatic HTTP/SSL</strong> - We are the only webhost's in the world to offer automatic free SSL/HTTP's encryption on all free hosted domain names.  You can instantly browse any domain on our network on a https:// url.<br>
<strong>3. Softaculous 1 click script installer</strong> - Softaculous is an auto installer for cPanel.
Unlike other auto installers Softaculous is much faster, well designed and it installs all scripts in just ONE STEP. 

</p>

          <article class="col1">
            <article class="col2">


              <h3>Paid Hosting Plans</h3>
              <ul class="list2">
                <li><img src="images/icon_1.png" alt="">Disk Space</li>
                <li><img src="images/icon_2.png" alt="">Monthly Data Transfer</li>
                <li><img src="images/icon_3.png" alt="">FTP Accounts</li>
                <li><img src="images/icon_4.png" alt="">Email Boxes</li>
                <li><img src="images/icon_5.png" alt="">Bandwidth Allowance</li>
              </ul>
            </article>
            <article class="col3">
              <h3 class="color1">Premium</h3>
              <ul class="list2">
                <li>unlimited</li>
                <li>250 GB</li>
                <li>25</li>
                <li>1000</li>
                <li>see plans</li>

              </ul>
            </article>
            <article class="col3">
              <h3 class="color2">VPS Server</h3>
              <ul class="list2">
                <li>20 GB</li>
                <li>125 GB</li>
                <li>n/a</li>
                <li>n/a</li>
                <li>see plans</li>

              </ul>
            </article>
            <article class="col3">
              <h3 class="color4">Dedicated</h3>
              <ul class="list2">
                <li>2x 1TB SATA</li>
                <li>5 TB @ 100MB/s</li>
                <li>see plans</li>
                <li>see plans</li>
                <li>see plans</li>

              </ul>
            </article>
          </article>
        </div>
      </div>
    </div>
  </section>
</div>
<div class="body3">
  <div class="main">
    <section id="content2">
      <div class="wrapper">
        <article class="col1">
          <article class="col2">
            <ul class="list3">
              <li><a href="#">Free Setup</a></li>
              <li><a href="#">No Hidden Fees</a></li>
              <li><a href="https://ifastnet.com/portal/index.php">Click here for details</a></li>
            </ul>
          </article>
          <article class="col3"> <img src="images/price1.gif" alt="" class="pad_bot1"> <a href="https://ifastnet.com/portal/sharedhosting.php" class="button1 color1">Sign Up Now</a> </article>
          <article class="col3">  <img src="images/price2.gif" alt="" class="pad_bot2"> <a href="https://ifastnet.com/portal/vpshosting.php" class="button1 color2">Sign Up Now</a> </article>
          <article class="col3"> <img src="images/price3.gif" alt="" class="pad_bot1"> <a href="https://ifastnet.com/portal/dedicatedserver.php" class="button1">Sign Up Now</a> </article>
        </article>
      </div>
    </section>
    <!-- / content  -->
  </div>
</div>
<div class="main">
  <!-- / footer -->
  <footer>Copyright &copy; <a href="#"><? echo "$yourdomain" ;?></a> All Rights Reserved</footer>
  <!-- / footer -->
</div>
<script>Cufon.now();</script>
</body>
</html>
