<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
	</body>
</html>
<?php 
/** 触发一个初始化插件admin/footer */
//$this->plugin->trigger('admin/footer');
?>