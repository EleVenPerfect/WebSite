=== STBLOG ver 0.1.x 帮助文档 ====

**** 版权声明 **** 

Copyright (c) 2008, EllisLab, Inc.
Copyright (c) 2010, cnsaturn.com.

STBLOG基于GNU General Public License, version 2.0 发布(http://www.gnu.org/licenses/gpl-2.0.html).

**** 安装与配置文档 **** 

1. 服务器环境
    > PHP version 5 or newer
    > MySQL version 4.1 or newer
    
2. 介绍STBlog 0.1.x的安装过程和注意事项以及默认账号
	> http://code.google.com/p/stblog/wiki/install
	
3. 本文讲述如何去除博客路径中的index.php.
	> http://code.google.com/p/stblog/wiki/remove_index_dot_php


**** 使用技巧 **** 

1. 如何开启stblog后台的ckeditor可视化编辑器：
	> http://code.google.com/p/stblog/wiki/ckeditor
	
2. 如何开启stblog后台的默认垃圾留言和引用防治插件
	> http://code.google.com/p/stblog/wiki/antispam


**** 开发者指南 ****

1.	如何编写并发布一个STblog插件
	> http://code.google.com/p/stblog/wiki/plugins

2.	如何编写并发布一个STblog主题/皮肤
	> http://code.google.com/p/stblog/wiki/themes
	
**** 程序开发与支持 ****

项目主页：http://code.google.com/p/stblog/
程序下载：http://code.google.com/p/stblog/downloads/list
Wiki:	http://code.google.com/p/stblog/w/list
Bug提交: http://code.google.com/p/stblog/issues/list
论坛:	http://groups.google.com/group/stblog
作者博客：http://www.cnsaturn.com/

程序所用框架Codeigniter开发者社区：http://www.codeigniter.org.cn/

**** 感谢 ****

当前版本的后台UI修改自Typecho，著作版权归typecho.org及其作者所有，在此对他们表示感谢

===============================

document by Saturn @ Melbourne